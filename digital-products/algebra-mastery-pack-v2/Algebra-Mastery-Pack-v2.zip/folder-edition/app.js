/**
 * Algebra Mastery Pack (grade 11 algebra, functions & data analysis) — paid
 * single-page study pack. Loads content from content.json (or from an inlined
 * window.ALGEBRA_CONTENT in the single-file edition), renders topics +
 * questions, and persists progress in localStorage. No backend, no API keys.
 *
 * Reuses the 8P2 electrical app architecture (which itself reused OChem).
 * Math "diagrams" are coordinate planes / graphs as original SVG, plus
 * monospace formula/method blocks and tables — NOT molecules (no SmilesDrawer).
 */

const STORAGE_KEY = 'algebra-practice-progress-v1';

let content = null;
let currentTopicId = null;


// ─── State / localStorage ──────────────────────────────────────
function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // ignore corrupted storage
  }
  return { topics: {} };
}

function saveProgress(progress) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    // ignore (private mode / quota)
  }
}

// Normalize a short answer for loose matching (case/whitespace/underscore).
function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .trim()
    .replace(/[\s_]+/g, '')
    .replace(/[^a-z0-9]/g, '');
}

// ─── Mastery helpers ───────────────────────────────────────────
function topicStats(progress, topicId, topic) {
  const total = topic.questions.length;
  const record = progress.topics[topicId];
  if (!record) {
    return { attempted: 0, correct: 0, total };
  }
  const attempted = Object.keys(record.answers).length;
  const correct = Object.values(record.answers).filter(isRecordedCorrect).length;
  return { attempted, correct, total };
}

// A stored answer is { value, correct }. Older saves stored a bare boolean.
function isRecordedCorrect(entry) {
  if (entry && typeof entry === 'object') return !!entry.correct;
  return !!entry;
}

function recordedValue(entry) {
  if (entry && typeof entry === 'object') return entry.value;
  return entry;
}

function masteryBadge(percentCorrect, attempted) {
  if (!attempted) return '—';
  if (percentCorrect >= 90) return '🏆 Master';
  if (percentCorrect >= 75) return '💪 Solid';
  if (percentCorrect >= 50) return '📈 Progressing';
  return '🌱 Starting';
}

function percent(correct, attempted) {
  if (!attempted) return 0;
  return Math.round((correct / attempted) * 100);
}

// ─── Rendering: topic list ─────────────────────────────────────
function renderTopicList() {
  const progress = loadProgress();
  const grid = document.getElementById('topic-grid');
  grid.innerHTML = '';

  content.topics.forEach((topic) => {
    const stats = topicStats(progress, topic.id, topic);
    const pct = percent(stats.correct, stats.attempted);
    const badge = masteryBadge(pct, stats.attempted);

    const card = document.createElement('div');
    card.className = 'topic-card';
    card.setAttribute('role', 'button');
    card.tabIndex = 0;
    card.innerHTML = `
      <div class="topic-card-icon">${escapeHtml(topic.icon)}</div>
      <div class="topic-card-title">${escapeHtml(topic.title)}</div>
      <div class="topic-card-meta">
        <span>${stats.attempted}/${stats.total} attempted</span>
        <span class="topic-mastery-badge" title="Topic mastery">${badge}</span>
      </div>
      <div class="topic-progress-track" style="margin-top:10px">
        <div class="topic-progress-fill" style="width:${pct}%"></div>
      </div>
    `;
    card.addEventListener('click', () => openTopic(topic.id));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openTopic(topic.id);
      }
    });
    grid.appendChild(card);
  });

  updateOverallMastery();
}

function updateOverallMastery() {
  const progress = loadProgress();
  let correct = 0;
  let attempted = 0;
  content.topics.forEach((topic) => {
    const stats = topicStats(progress, topic.id, topic);
    correct += stats.correct;
    attempted += stats.attempted;
  });
  const pct = percent(correct, attempted);
  const badge = masteryBadge(pct, attempted);
  document.getElementById('overall-badge').textContent = badge;
  document.getElementById('overall-percent').textContent = pct + '%';
}

// ─── Rendering: diagrams (SVG / table / text) ──────────────────
// Unlike the OChem app (which rendered molecules from SMILES via
// SmilesDrawer), this app renders author-supplied diagrams directly:
//   { type: "svg",   svg: "<svg …>", caption? }  → inline SVG (original art)
//   { type: "table", headers?, rows, caption? }  → HTML table
//   { type: "text",  code: "…", caption? }       → monospace block (formulas)
// `svg` is trusted author content from our own content.json (not user input).
function diagramBox(diagram) {
  if (!diagram || !diagram.type) return '';
  let body = '';
  if (diagram.type === 'svg' && diagram.svg) {
    body = `<div class="diagram-svg">${diagram.svg}</div>`;
  } else if (diagram.type === 'table' && Array.isArray(diagram.rows)) {
    const headers = Array.isArray(diagram.headers) && diagram.headers.length
      ? `<thead><tr>${diagram.headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>`
      : '';
    const rows = diagram.rows
      .map((r) => `<tr>${r.map((c) => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`)
      .join('');
    body = `<div class="diagram-table"><table>${headers}<tbody>${rows}</tbody></table></div>`;
  } else if ((diagram.type === 'text' || diagram.type === 'formula') && diagram.code) {
    body = `<pre class="diagram-text">${escapeHtml(diagram.code)}</pre>`;
  } else {
    return '';
  }
  const caption = diagram.caption ? `<div class="diagram-caption">${escapeHtml(diagram.caption)}</div>` : '';
  return `<div class="diagram-box">${body}${caption}</div>`;
}

// Curated free tutorial links (target=_blank, rel="noopener nofollow").
function resourcesList(resources) {
  if (!Array.isArray(resources) || resources.length === 0) return '';
  return `
    <div class="resources-box">
      <div class="resources-heading">📚 Learn more (free)</div>
      <ul class="resources-list">
        ${resources
          .map((res) => `<li><a href="${escapeHtml(res.url)}" target="_blank" rel="noopener nofollow">${escapeHtml(res.title)}</a></li>`)
          .join('')}
      </ul>
    </div>`;
}

// ─── Rendering: topic detail ───────────────────────────────────
function openTopic(topicId) {
  currentTopicId = topicId;
  const topic = content.topics.find((t) => t.id === topicId);
  if (!topic) return;

  document.getElementById('topic-list-view').classList.add('hidden');
  document.getElementById('topic-detail-view').classList.remove('hidden');

  const container = document.getElementById('topic-detail');
  container.innerHTML = `
    <div class="topic-detail-header">
      <span class="topic-detail-icon">${escapeHtml(topic.icon)}</span>
      <h2>${escapeHtml(topic.title)}</h2>
    </div>
    <div class="concept-box">
      <h3>Concept</h3>
      <p>${escapeHtml(topic.concept)}</p>
      ${diagramBox(topic.diagram)}
    </div>
    ${resourcesList(topic.resources)}
    <h3 class="questions-heading">Practice Questions</h3>
    <div id="questions-container"></div>
  `;

  const qc = document.getElementById('questions-container');
  const progress = loadProgress();

  topic.questions.forEach((q) => {
    qc.appendChild(renderQuestion(q, topic.id, progress));
  });
}

function renderQuestion(q, topicId, progress) {
  const card = document.createElement('div');
  card.className = 'question-card';
  card.dataset.questionId = q.id;

  const storedAnswer = progress.topics[topicId]?.answers?.[q.id];
  const answered = storedAnswer !== undefined;
  const prevAnswer = answered ? recordedValue(storedAnswer) : undefined;
  const prevCorrect = answered ? isRecordedCorrect(storedAnswer) : false;

  const typeLabel = q.type === 'multiple-choice' ? 'Multiple choice' : 'Short answer';

  let body = '';
  if (q.type === 'multiple-choice') {
    body = `<div class="options-list">${q.options
      .map((opt, i) => {
        return `
          <label class="option" data-index="${i}">
            <input type="radio" name="${q.id}" value="${i}" ${answered && Number(prevAnswer) === i ? 'checked' : ''} ${answered ? 'disabled' : ''} />
            <span>${escapeHtml(opt)}</span>
          </label>`;
      })
      .join('')}</div>`;
  } else {
    body = `<input type="text" class="short-answer-input" placeholder="Type your answer…" autocomplete="off" ${answered ? 'value="' + escapeHtml(String(prevAnswer ?? '')) + '" disabled' : ''} />`;
  }

  card.innerHTML = `
    <p class="question-prompt">${escapeHtml(q.prompt)}</p>
    <div class="question-type">${typeLabel}</div>
    ${diagramBox(q.diagram)}
    ${body}
    <button class="check-btn" type="button" ${answered ? 'disabled' : ''}>Check answer</button>
    <div class="feedback" id="feedback-${q.id}"></div>
  `;

  // If already answered, show the stored result immediately.
  if (answered) {
    showFeedback(q, prevCorrect, true, card);
  } else {
    card.querySelector('.check-btn').addEventListener('click', () => {
      handleAnswer(card, q, topicId);
    });
    card.querySelector('.check-btn').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleAnswer(card, q, topicId);
    });
  }

  return card;
}

function getSelectedOption(card) {
  const checked = card.querySelector('input[type="radio"]:checked');
  return checked ? Number(checked.value) : null;
}

function handleAnswer(card, q, topicId) {
  let userAnswer;
  let isCorrect;

  if (q.type === 'multiple-choice') {
    const selected = getSelectedOption(card);
    if (selected === null) {
      // No option selected — gently nudge, don't count an attempt.
      const fb = card.querySelector('.feedback');
      fb.className = 'feedback visible wrong';
      fb.innerHTML = `<div class="feedback-head wrong">Please select an answer.</div>`;
      return;
    }
    userAnswer = selected;
    isCorrect = selected === q.answer;
  } else {
    const input = card.querySelector('.short-answer-input');
    userAnswer = input.value;
    isCorrect = normalize(input.value) === normalize(q.answer);
  }

  // Mark the correct option(s) visually.
  if (q.type === 'multiple-choice') {
    card.querySelectorAll('.option').forEach((optEl) => {
      const idx = Number(optEl.dataset.index);
      optEl.classList.remove('selected');
      if (idx === q.answer) optEl.classList.add('correct');
      if (idx === userAnswer && !isCorrect) optEl.classList.add('wrong');
      optEl.querySelector('input').disabled = true;
    });
  } else {
    card.querySelector('.short-answer-input').disabled = true;
  }

  card.querySelector('.check-btn').disabled = true;
  showFeedback(q, isCorrect, false, card);

  // Persist progress. Store the learner's actual answer plus whether it was
  // correct, so returning to the topic shows what they typed, not a boolean.
  const progress = loadProgress();
  if (!progress.topics[topicId]) progress.topics[topicId] = { answers: {} };
  if (!progress.topics[topicId].answers) progress.topics[topicId].answers = {};
  progress.topics[topicId].answers[q.id] = { value: userAnswer, correct: isCorrect };
  saveProgress(progress);

  updateOverallMastery();
}

function showFeedback(q, isCorrect, alreadyAnswered, cardEl) {
  const fb =
    (cardEl && cardEl.querySelector('.feedback')) ||
    document.getElementById('feedback-' + q.id);
  if (!fb) return;
  fb.className = 'feedback visible ' + (isCorrect ? 'correct' : 'wrong');
  const head = isCorrect ? '✓ Correct' : '✗ Not quite';
  fb.innerHTML = `
    <div class="feedback-head ${isCorrect ? 'correct' : 'wrong'}">${head}</div>
    <p class="worked"><strong>Worked solution:</strong> ${escapeHtml(q.explanation)}</p>
    ${!isCorrect ? `<p class="worked"><strong>Correct answer:</strong> ${q.type === 'multiple-choice' ? escapeHtml(q.options[q.answer]) : escapeHtml(q.answer)}</p>` : ''}
    ${resourcesList(q.resources)}
  `;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── Init ───────────────────────────────────────────────────────
function loadContent() {
  // The standalone edition inlines the content as window.ALGEBRA_CONTENT so the
  // pack also works when opened straight from the file system.
  if (window.ALGEBRA_CONTENT) return Promise.resolve(window.ALGEBRA_CONTENT);
  return fetch('content.json').then((res) => {
    if (!res.ok) throw new Error('content.json failed to load');
    return res.json();
  });
}

function init() {
  loadContent()
    .then((data) => {
      content = data;
      document.getElementById('app-title').textContent = data.app.title;
      document.getElementById('app-subtitle').textContent = data.app.subtitle;
      document.getElementById('app-disclaimer').textContent = data.app.disclaimer;
      renderTopicList();
    })
    .catch((err) => {
      document.getElementById('topic-grid').innerHTML =
        '<p style="color:#b23a48">Could not load study content. Please refresh or try again.</p>';
      console.error(err);
    });

  document.getElementById('back-btn').addEventListener('click', () => {
    document.getElementById('topic-detail-view').classList.add('hidden');
    document.getElementById('topic-list-view').classList.remove('hidden');
    renderTopicList();
    window.scrollTo(0, 0);
  });
}

document.addEventListener('DOMContentLoaded', init);
