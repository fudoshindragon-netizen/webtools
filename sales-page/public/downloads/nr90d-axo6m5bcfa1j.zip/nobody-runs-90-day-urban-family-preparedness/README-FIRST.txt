NOBODY RUNS — The 90-Day Urban Family Preparedness Program
Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States

READ THIS FIRST
===============

Open CUSTOMER_README.pdf, in this folder, before you open anything else. It tells you:

  * the load — about 82 hours for the full program, about 59 hours on the core path
  * the refund policy — 30 days, through the channel you bought it on
  * what this program refuses to cover, and why

CUSTOMER_README.md is the same document as plain text, if you would rather read it
that way.

WHAT IS IN THIS ARCHIVE
=======================

  CUSTOMER_README.pdf / .md   Start here. Load, refund policy, errata.
  print-ready/                All 16 documents as A4 PDFs — selectable text, ready
                              to print or read on a screen.
  large-print/                The same 16 documents, larger type and wider spacing.
  markdown/                   The same 16 documents as plain Markdown.

WHERE TO GO NEXT
================

print-ready/00-START-HERE.pdf is the orientation chapter. Read 00, 01 and 09 first:
the orientation, the decision, and the map. The twelve-week calendar is doc 09.

Nothing in this program completes by reading. Every module closes on a demonstration,
with another adult watching.

This is preparedness education only — not medical, legal or tactical advice. In an
emergency call your local emergency number.
