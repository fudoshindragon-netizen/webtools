# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## CUSTOMER README — read this first

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

Thank you for buying this. This page tells you what is in the download, where to start, how long the
program actually takes, what the refund policy is, and what the program deliberately does not cover —
before you spend an evening discovering any of it yourself.

---

## 1. What this is

A **training program and study guide** for a household of four to five people in a city or inner suburb
 a flat, a rowhouse, a small lot — where at least one member is elderly, very young, or otherwise
unable to run, walk far, carry weight, or evacuate quickly.

It is built on one inversion of the usual advice. Nearly all free preparedness material assumes a fit
adult who can lift forty pounds and leave on foot. **Your household is only as mobile as its slowest
member.** So the default here is not to leave. The default is to harden where you are, and to move only
on a pre-planned, assisted basis, decided in advance rather than in a panic. That is why the book is
called *Nobody Runs*.

**Every chapter closes with modules, not with reading.** Thirty-nine of them, each closing on a
demonstration or a written check that somebody else watches. Reading a chapter is not finishing a
module; that is the design, and it is stated in doc 00 §0.1 before you begin.

---

## 2. What is in the box

Fourteen numbered chapters, plus the source list and this README. Every chapter ships as **Markdown**
(searchable, and readable by a screen reader) and as a **print-ready PDF** for a three-ring binder. The
section numbers are identical in both, so "doc 04 §4.2.2" means the same place in either one.

| # | Chapter | What it is for |
|---|---|---|
| **00** | **START HERE** | The calendar, the readiness scorecard, the "First 60 Minutes" card, and the day 1 → 90 timeline. **Read this first, and read it twice.** |
| 01 | Threat model and decision | The urban hazard matrix, the three-branch decision tree, and why staying is a legitimate plan. |
| 02 | Water | Store → harvest → treat → ration. Containers, rotation, boiling, bleach, filters, SODIS. |
| 03 | Food | 90-day calorie maths by person type, the no-fuel plan, shelf life, food safety with no fridge. |
| 04 | Heat, shelter, sanitation and clothing | One warm room, carbon monoxide and fire, cooling, the shelter chapter, clothing, the emergency toilet. |
| 05 | First aid | Kit, bleeding, choking, anaphylaxis, stroke, falls, burns, wounds, triage and red flags. |
| 06 | Medicine when the pharmacy is shut | The OTC core list, rehydration by sachet only, evidence-graded remedies, the dangerous-myths list, prescription continuity. |
| 07 | Security and community | Layered security as an assessment, door and visitor protocol, mutual aid, CERT, knowing your local law. |
| 08 | Slow movers and bug-out | The assisted move, per-person bags, rally points, communications, destination tiers. |
| 09 | Training matrix and curriculum | The 39-module spine: every module's drill, pass criteria, rating and hours. |
| 10 | Forms and checklists | Inventory, water log, medication list, ICE card, decision card, drill logs — **plus the large-print medication list and decision card.** |
| 11 | **Sourcing, budget and fuel** | Where to buy and in what order, the three budget phases, the unit-cost method, and fuel storage and safety. |
| 12 | Assessments and answer keys | Ten questions per module, practical rubrics, and the full answer key with the reason each answer is the answer. |
| 13 | Competency passport and certificate | The printable passport, the Stage 1/2/3 award record, and the certificate. |
| — | **SOURCES.md** | Every source the figures came from, with live URLs, by topic — and what could not be verified. |
| — | **CUSTOMER_README.md** | This page. |

---

## 3. Where to start

**1. Read doc 00 in full.** It contains the calendar, the scorecard, and the card you use in the first
hour of a blackout. Nothing else in the box makes sense before it.

**2. Do Week 0 — Tier 0.** Four modules: the household roster, the medical and device inventory, the
documents and cash, and the decision card and household meeting. These are the facts about your own
household that nobody else can write down for you, and every later module is built on them.

**3. Then follow the calendar in doc 00 §0.4.** Weeks are the unit. Modules marked **●** are the
**core path**; modules marked **○** are the full path. If you only ever do the ● path, you still reach
**Stage 2**, and that is a real stopping point, not a failure to finish.

**4. Buy in the order doc 11 gives you**, not in the order that feels urgent. Phase 1 is the hazards
that kill first — a CO alarm, water containers, bleach, light, the first-aid gaps, a week of no-cook
food, and a bucket. It costs about a hundred dollars and it is deliberately unexciting.

**If you are short of time, do this and stop:** doc 00, Week 0, and the CO alarm. That is a weekend, and
it is worth more than a shelf of gear.

---

## 4. The load statement — the honest number, before you start

**The full program is about 82 hours of work across twelve weeks.** That is the honest figure:
thirty-nine modules, each closing on a demonstration rather than a read, in a house that also contains a
four-year-old and a carer.

**There is a core path of about 59 hours — roughly five hours a week — that still reaches Stage 2 by the
end of the twelve weeks.** The core path is the modules marked ● in doc 00 §0.4 and doc 09. The
remaining modules can be done afterwards, or not at all, without undoing what the core path built.

Two things that are also true and are not in the number above:

- **The tier is the gate; the week is the schedule.** The week numbers are a suggested pace, not a
  deadline. A household that takes twenty weeks still earns the stage, provided the competencies are
  demonstrated.
- **There are 144 hours of elapsed drill time on top** — two 72-hour events that are lived rather than
  worked. Those are not study hours and are not counted as such.

If eighty-two hours is not realistic for your household this quarter, take the core path — and say so
out loud. A plan you can execute beats a plan you abandon in week three.

---

## 5. Refund policy

**If this program is not what you expected, ask for a refund through the channel you bought it on, and
you will get it.** No interrogation, no form to fill in, and no requirement to prove you did not read
it. A digital product cannot be handed back, and we would rather refund a household that is
disappointed than keep money from one that is.

Two requests, both of which help the next buyer:

- **Tell us what was wrong**, if you are willing. "It was too long", "I wanted gear lists", "the fuel
  chapter had no numbers" are all useful — the last one especially, because it is deliberate and this
  README explains why below.
- **Ask within 30 days of purchase.** That is the window the payment processors give us to reverse a
  charge cleanly.

If you bought on Gumroad, use the refund link on your receipt or reply to the receipt email. If you
bought through the storefront's own checkout, reply to the receipt email from the payment processor.

---

## 6. Errata — what changed, and when

This is **version 1.0**, errata date **2026-11-02**. Corrections are recorded here, dated, and any
corrected figure in a chapter is marked with the date it changed. Two corrections are already in this
version, and both are the kind of thing you should know about:

1. **The load statement changed, and the new number is the real one.** Earlier drafts of this program
   advertised roughly **60–75 hours** for the full programme and about **three hours a week** on the
   core path. When the per-module hours were actually added up from the chapters themselves, that was
   wrong: the true figure is **about 82 hours**, with a core path of **about 59 hours at roughly five
   hours a week**. **No modules were cut to make the number smaller.** The figure that ships is the one
   the program actually costs, because a buyer who discovers the real load after paying is a refund, and
   that would be our fault for not printing the number.
2. **Fuel figures were removed, not added.** An earlier draft of doc 11 printed storage quantities, a
   heater clearance and a kerosene grade that the research behind this program had never verified. They
   are gone. **No gallon figure appears anywhere in this book**, because the standards that govern
   residential fuel storage are paywalled and the number that circulates online is edition-dependent and
   misapplied to dwellings. What replaced them is a procedure: **call your fire marshal, then your
   landlord, and write both answers down.** The chapter prints the reasoning in full, and doc 11 §11.15
   lists every figure it refuses to print and where to get each one instead.

If you find something wrong that is not on this list — a figure that does not match its source, a
section reference that goes nowhere, a step that cannot be done in the room it describes — please report
it. Errata are corrected in the next version and the corrected version is sent to every previous buyer
free, at the address the purchase came from.

---

## 7. Support

**Reply to your purchase receipt.** Both Gumroad and the storefront's checkout send one, and a reply to
it reaches us with your order attached — that is the fastest route and it needs no account, no login and
no form. You can also use the contact link on the product page you bought from.

What we can help with: a file that will not open, a missing chapter, a page that did not print
correctly, a broken link, a section reference that is wrong, a refund, or a question about what a
chapter means.

What we cannot do, and will not pretend to: give medical, legal or tactical advice for your situation,
tell you what your local fire code allows, or assess your building. Those questions belong to your
doctor, your lawyer, your fire marshal, your landlord and your local emergency management office — and
the book tells you which one to call at each point rather than guessing for you.

---

## 8. Written for households in the United States

**Every source in this program is US.** Water treatment, sanitation, fire, building, rental, employment
and evacuation rules are local, and **local rules beat anything printed here.** Where this guide and a
local advisory differ, the local advisory wins.

If you are reading this outside the United States, the procedures may still be sound, but the numbers,
the agencies and the law are not yours. Do not use it as your plan.

---

## 9. What this program does not cover — the weapons statement

**This program does not cover weapons use, weapons handling, or weapons construction.** It covers home
security, deterrence, door and visitor protocol, neighborhood mutual aid, and knowing your local law —
the parts that a family in an apartment can actually use and that we can source honestly.

There is no weapons chapter, no weapons appendix, and no weapons material in any bonus file. If you
bought this expecting weapons instruction, this paragraph is telling you plainly that it is not here,
and the refund policy in §5 applies.

The same is true of three other things, so that nobody is surprised later:

- **No recipes for medicine.** No antibiotics, no chemical synthesis, no improvised formulations.
  Medical content is recognition and stabilisation-until-help only, never diagnosis and never dosing
  beyond "follow the label".
- **No numbers invented to fill a gap.** Every figure traces to a published US federal, university or
  national source. Where no source exists, the book says so and gives you the procedure for finding your
  local answer. `SOURCES.md` lists all of it, including what could not be verified.
- **No claim that anything here is tested, field-proven, or endorsed by any agency.** It is not.

**What this is not:** not medical advice, not legal advice, not tactical advice. Not an accredited
qualification, and not a substitute for professional training. The certificate in doc 13 is a
**self-assessed household record** of what your household demonstrated to itself — it is not a
certification, it confers no status, and no employer, agency or instructor has assessed it. Please do
not describe it as "certified" to anyone, because it is not, and we would rather say so here than have
you find out at the wrong moment.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
