# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 00 — START HERE

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This manual is the first of sixteen files. Read this one before anything else, and read it
twice. It contains the calendar, the scorecard, the card you use in the first hour of a
blackout, and the timeline of what actually changes between day 1 and day 90.

---

## 0.1 What this is, and what it is not

This is a **training program and a study guide** for a household of four to five people
living in a city or an inner suburb — an apartment, a rowhouse, a small lot — where at least
one member is elderly, very young, or otherwise unable to run, walk far, carry weight, or
evacuate quickly.

It is built on one inversion of the usual advice. Nearly all free preparedness material
assumes a fit adult who can lift forty pounds and leave on foot. Your household is only as
mobile as its slowest member. So the default here is **not** to leave. The default is to
**harden where you are**, and to move only on a pre-planned, assisted basis, decided in
advance rather than in a panic. That is why the book is called *Nobody Runs*.

Three things this manual deliberately does **not** contain, and will not:

1. **No weapons content.** Not use, not handling, not construction, not tactics. The product
   covers layered home security as an *assessment*, deterrence, door and visitor protocol,
   neighborhood mutual aid, CERT, and knowing your local law — the parts a family in an
   apartment can actually use and that can be sourced honestly. If you bought this expecting
   weapons instruction, this is the paragraph that tells you plainly that it is not here.
2. **No recipes for medicine.** No antibiotics, no chemical synthesis, no improvised
   formulations. Medical content is recognition and stabilisation-until-help. Where a
   household remedy is genuinely well evidenced, it appears with its evidence grade and its
   limits. Where a widely-repeated recipe is dangerous, it appears on the "do not do this"
   list instead.
3. **No numbers invented to fill a gap.** Every figure in this manual traces to a published
   US federal or national source — Ready.gov, EPA, CDC, FDA, FEMA, NWS, USDA/HHS, WHO/UNICEF.
   Where the sources disagree, both figures are printed and the conservative planning number
   is named. Where no source exists, the manual says so and gives you the *procedure* for
   finding your local answer instead of a confident guess. You will meet two examples of that
   early: the oral rehydration ratio (never printed here — store sachets, never improvise the
   ratio, and §06 explains why), and fuel quantities (no gallon figure appears anywhere in
   this manual, because the standards that govern them are paywalled and the number that gets
   quoted online is edition-dependent and misapplied to dwellings — §11 tells you to call
   your fire marshal instead).

**Jurisdiction.** Every source is US. Water treatment, sanitation, fire, building, rental and
evacuation rules are local, and local rules beat anything printed here. If you are reading
this outside the United States, the procedures may still be sound but the numbers, the
agencies and the law are not yours — do not use it as your plan.

### The load statement — read before you start

The full program is **about 82 hours of work across twelve weeks**. That is the honest number:
thirty-nine modules, each closing on a demonstration rather than a read, in a house that also
contains a four-year-old and a carer.

There is a **core path of about 59 hours — roughly five hours a week** — that still reaches
**Stage 2 by the end of the twelve weeks**. The core path is marked in §0.4. The remaining
modules can be done afterwards, or not at all, without undoing what the core path built.

If eighty-two hours is not realistic for your household this quarter, take the core path — and
say so out loud. A plan you can execute beats a plan you abandon in week three.

---

## 0.2 Who this program is written around

The program assumes a household of four to five, and it assumes the hard case:

- at least one adult who is the person responsible, and who has realised it;
- at least one member over 65, or with a mobility, cardiac, respiratory, cognitive or
  sensory limitation;
- at least one child, possibly very young;
- no land, no bunker, no military background, no vehicle you can rely on;
- a lease, a landlord, shared walls, and neighbors you may not know yet.

If your household is two fit adults in a house with a garden, this still works, but you are
not the hardest case and some of the assistance planning will feel like overkill. Do it anyway;
the assistance plan is the part that transfers when someone breaks an ankle.

**The slowest member sets the standard.** Every timing, every route, every decision point in
this manual is calibrated to the person who takes longest — not averaged across the household.
A plan timed to the fastest adult is a plan that fails on the day it is used.

---

## 0.3 How the sixteen files fit together

| File | What it is for |
|---|---|
| **00 START HERE** | Orientation, calendar, scorecard, First 60 Minutes card, day 1→90 timeline |
| **01 THREAT MODEL AND DECISION** | The hazard matrix, the three-branch decision tree, module BAS-4 |
| **02 WATER** | Store → harvest → treat → ration by activity |
| **03 FOOD** | 90-day calorie math, no-fuel cooking, no-fridge food safety, special diets |
| **04 HEAT, SHELTER, SANITATION, CLOTHING** | Warmth, CO and fire, cooling, board-up, the emergency toilet, hygiene, clothing |
| **05 FIRST AID** | Kit, bleeding, choking, anaphylaxis, stroke, falls, burns, wounds, heat and cold |
| **06 MEDICINE WHEN THE PHARMACY IS SHUT** | OTC core list, rehydration, evidence-graded remedies, the dangerous-myths list |
| **07 SECURITY AND COMMUNITY** | Layered security as assessment, door protocol, mutual aid, CERT, legal awareness |
| **08 SLOW MOVERS AND BUG-OUT** | Per-person bags, mobility plan, assisted move, rally points, comms |
| **09 TRAINING MATRIX AND CURRICULUM** | The 39 modules — the spine of the whole program |
| **10 FORMS AND CHECKLISTS** | Inventory, water log, med list, ICE card, decision card, drill log, pantry calculator |
| **11 SOURCING, BUDGET AND FUEL** | Where to buy, in what order, unit cost, fuel safety |
| **12 ASSESSMENTS AND ANSWER KEYS** | Knowledge checks and practical rubrics per module |
| **13 COMPETENCY PASSPORT AND CERTIFICATE** | The signed record, Stage 1/2/3 award |
| **SOURCES** | Every citation, with access dates |
| **README / LISTING** | What you bought, refund policy, errata |

**Reading order is not the same as doing order.** Read 00, 01, 09 first — the orientation, the
decision, and the map. Then work the calendar in §0.4, dipping into the chapter a module
points at, doing the drill, and getting it signed off.

**Section numbering.** Every heading in every document is numbered, so a module that points to
`02 §2.6` resolves to exactly one paragraph — document 02, section 2.6. The convention is that
document NN numbers its sections N.x: this document uses `0.x`, document 01 uses `1.x`, document
02 uses `2.x`, and so on to document 13.

---

## 0.4 The twelve-week calendar

Weeks are the unit. A week is **about five hours on the core path** (marked ●) and up to seven on the
full path (● plus ○). The heavier weeks are marked, and the week numbers are a suggested
pace, not a deadline — **the tier is the gate, the week is the schedule.** If a week goes badly, repeat it — the calendar is a sequence, not a
deadline.

| Week | Tier | Modules | Path |
|---|---|---|---|
| **0** | Baseline | `BAS-1` roster and vulnerability map · `BAS-2` medical and device inventory · `BAS-3` documents, contact card, cash · `BAS-4` decision card and household meeting | ● core |
| **1** | Life support | `WTR-1` 14-day water buffer · `CO-1` CO alarms installed and tested | ● core |
| **2** | Life support | `WTR-2` boil safely · `WTR-3` disinfect, clear and cloudy | ● core |
| **3** | Life support | `FOD-1` build the pantry · `FOD-2` cook with no power, outdoors or ventilated balcony only | ● core |
| **4** | Life support | `FOD-3` food safety with no fridge · `SAN-1` emergency toilet **with a named disposal route** · `SAN-2` handwash and dish station | ● core |
| **5** | Health and warmth | `MED-1` medical kit · `MED-2` medication and device continuity · `WTR-4` water inside the building | ● core |
| **6** | Health and warmth | `MED-3` rehydration (sachets only) · `MED-4` wound care and infection signs · `MED-5` the "do not do this" list — 10/10, no partial pass | ● core |
| **7** | Health and warmth | `MED-6` first aid that matters here · `WTH-1` one warm room · `FUE-1` fuel safety — 10/10, no partial pass | ● core |
| **7 end** | **Gate** | **`DRILL-1` — the 72-hour no-utilities drill.** Runs only after Tier 0 and Tier 2 are closed. Abandoned, never pushed through, if any exclusion in §09 applies | ● core |
| **8** | Shelter and security | `WTH-2` heat illness and the heat-wave plan · `FIR-1` fire and CO · `CLO-1` dress the slowest member for 0 °C in five minutes | ● core |
| **9** | Shelter and security | `SHE-1` board-up and building heat loss · `SHE-2` upper-floor reality · `SEC-1` security assessment · `SEC-2` door protocol | ● core |
| **10** | Shelter and security | `SEC-3` mutual aid — three neighbors, one real conversation · `SEC-4` legal reality | ● core (Stage 2 lands here) |
| **11** | Mobility | `MOV-1` per-person bags · `MOV-2` mobility plan for the slowest member · `MOV-3` timed assisted evacuation drill · `MOV-4` rally points and comms | ○ full |
| **12** | Integration | `INT-1` full 72-hour simulation · `INT-2` debrief, every failure logged · `MOR-1` morale and mental health | ○ full |

**Why the drill moved to week 7.** An earlier version of this program ran the 72-hour drill
in week 4 — before the medication list existed and before a single CO alarm was on the wall.
For an elder on cardiac, seizure or insulin medication, or a household with oxygen in it, that
is the most foreseeable harm in the entire program. It now sits behind Tier 0 and Tier 2 as
a hard gate.

**Two weeks are not the calendar.** Nothing in this program is a race against a clock you
control. If your household needs fourteen weeks, take fourteen.

---

## 0.5 The readiness scorecard

Score once at the start of week 0 and again at the end of week 10. Score honestly; this
document is for you, and an inflated score is the one score that cannot help you.

Each line is scored **0, 1 or 2**:

- **0 — not in place.** Nothing exists, or it exists only in your head.
- **1 — partially in place.** It exists but has never been tested, or depends on one person,
  or has a gap you already know about.
- **2 — in place and demonstrated.** It exists, it has been used or drilled, and a second
  person in the household could find it or do it.

| # | Line | 0 | 1 | 2 |
|---|---|---|---|---|
| 1 | **Water** — 14-day buffer stored, dated, logged | nothing stored | some stored, unlogged | buffer filled, dated, logged, rotated |
| 2 | **Water treatment** — you can make water safe | no method | method known, never done | boiled and dosed clear *and* cloudy, unassisted |
| 3 | **Food** — calories and no-cook plan | no plan | pantry started | calculator filled, per-person calories verified, no-cook meals planned |
| 4 | **Food safety without a fridge** | no plan | rules read | FDA discard times recited and applied; coolers and thermometers in place |
| 5 | **Warmth** — one warm room | no plan | blankets only | one warm room identified, safe heating sited, CO alarm tested |
| 6 | **Sanitation** — toilet, handwash, disposal | no plan | supplies bought | toilet built and used 24 h, **named disposal route**, handwash station run a week |
| 7 | **Medical** — kit and medication continuity | no list | list started | every medication, dose, prescriber and refill date recorded; every powered or refrigerated device identified |
| 8 | **First aid** — the household can act | no kit | kit bought | bleeding, choking, anaphylaxis and stroke recognition drilled; falls plan written |
| 9 | **Security and neighbors** — the cheap wins | door unanswered | three names written | three neighbors spoken to; door protocol role-played including the child's and the elder's script |
| 10 | **Decision card** — the three branches signed | not written | discussed | signed by every adult, dated, posted where it is used |

**Total out of 20.** The bands are a rough guide to where to spend the next month, not a grade:

- **0–7** — start at week 0 and do not skip the roster.
- **8–13** — you have a store, not a plan. The gaps are almost always sanitation, medication
  continuity and the decision card.
- **14–17** — you are close to **Stage 1 — FOUNDATION**. Close Tier 0 and Tier 1 and get them
  demonstrated.
- **18–20** — you are in **Stage 2 — OPERATIONAL** territory. The remaining work is mobility
  and integration.

**A score is not a certificate.** It is a household self-assessment by someone with no
independent qualification, and it certifies nothing to anyone outside your front door. The
value is the signed competency log in doc 13, not the number.

**Who scores.** By default, an adult who did not perform the task — a partner, an older child,
a carer. In a single-adult household, a neighbor or a CERT contact may witness and initial.
If nobody else is available, score yourself, date it, and write *self-assessed* next to your
initials. Do not leave the line blank.

**The three ratings**, used on every module in this program:

- **NOT YET** — not done, or done once with help.
- **DEMONSTRATED** — done unassisted, to the module's pass criteria, observed.
- **CAN TEACH IT** — done unassisted *and* taught to another household member who then did it
  themselves. Life-critical skills need this level, because a skill that lives in one head
  dies if that head is injured.

Children aged eight and over are rated on age-appropriate competencies — fetching help,
the door script, the rally point, the water station. Capability, never fear.

---

## 0.6 THE FIRST 60 MINUTES — the card

> **Print this page. Put it on the inside of a kitchen cabinet door, and one copy in the
> go-bag.** This is the hour that decides how the next three days go. It is written for a
> power cut, and it holds for most other "no utilities" starts as well.

### Do these in this order

**1. People before property (first 5 minutes).**
Go to the person who depends on power or refrigeration **before** you touch anything else:
oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair, insulin in the fridge.
Ask: *how long does this device have, and what is the plan when it stops?* If the answer is
"it stops now and that is dangerous," you are not in a blackout problem any more — you are in
a medical-continuity problem. Call the equipment supplier or the clinical team on the number
in `BAS-2`, and start the branch 2 conversation in doc 01 immediately.

**2. Check the lift (next 2 minutes).**
If your building has one, establish whether anyone is inside it. A stopped lift with a person
in it is a call to the fire service, not a wait-and-see. Do this before you go looking for
torches.

**3. Note the time, out loud, and write it down (minute 7).**
"Power lost at ___." Everything below is timed from that number. If you skip it, you will
guess, and you will guess wrong in the direction of keeping food you should have thrown out.

**4. Shut the fridge and freezer and leave them shut (minute 8).**
The federal figures, so you know what clock you are on: a **refrigerator holds cold for about
4 hours** if it stays unopened. A **full freezer holds about 48 hours**; a **half-full freezer
about 24 hours**. Have coolers ready if the outage will pass **4 hours**. If the doors stayed
shut and the outage was **4 hours or less**, refrigerated food is generally safe — but check
the temperature and **discard anything above 40 °F**. A half-empty freezer is a liability;
freeze water bottles to fill the space, and if the power is already out, fill the gaps with
anything frozen or with ice.

**5. Do not add a new hazard (minute 10 — and for the rest of the outage).**
This is the step people get wrong, and it kills more people in outages than the outage does.

- **LED lights only. No candles.** A candle in a dark apartment with a sleeping elder and a
  four-year-old is a house fire waiting for a draught.
- **A generator goes outdoors, more than 20 feet from windows, doors and vents.** Never
  indoors. Never in a garage, not even with the doors open.
- **Never charcoal indoors.** **Never a gas oven or gas hob for heat.** **Never a camp stove
  or a flameless chemical heater indoors.**
- **If anything in the household burns fuel** — furnace, boiler, water heater, gas range,
  fireplace, wood stove, kerosene heater, or a generator running outside — **the CO alarm is
  the first thing you check**, and it is not optional. Sleeping people die of CO without
  symptoms.
- **No fuel stored in the dwelling.** Default for an apartment, not a maybe. §11 explains why
  the honest answer on quantities is to call your fire marshal.

**6. Capture water while pressure lasts (minute 15).**
Fill every clean container you own, the bath, and the pots, while the taps still run. If the
taps are already dry, the water heater tank is a **one-time draw of roughly 30–50 gallons in a
typical house** — but **shut the power or gas to the heater before draining it**, and treat
that water before drinking. Never drain a shared building system. Toilet **tank** water is
usable only if it is clear and has no colored cleaner tablet in it; **the bowl is never a
drinking source**.

**7. Take the medication inventory (minute 25).**
Which prescriptions run out first, which ones must stay cold, which devices need mains power.
This is the single most common way a short outage becomes an emergency in a household with an
elder in it.

**8. Tell one person outside the building (minute 40).**
One text to the out-of-area contact from `BAS-3`: *"Power out since ___. Everyone fine. Will
message at ___."* Set the next check-in time. If phones are down, that is what the paper
contact card in the go-bag is for.

**9. Open the decision card and read the branches out loud (minute 50).**
You are almost certainly on **branch 1 — STAY AND HARDEN**. On day one, in most outages, that
is correct. The point of reading the card now, while nothing is on fire, is that you will
recognize the trigger when it fires. Doc 01 §1.9 lists them; the ones that can end a day-one
blackout early are medical device failure, an unheated home in freezing weather, a heat wave
with an elder in the house, and any fire or flood.

**10. Write the first log line (minute 60).**
Time, water on hand, food that needs eating first, who was contacted, what you decided. Doc 10
has the form. One line a day from here is enough, and it is the difference between a plan and
an anecdote.

### What NOT to do in the first hour

- Do not drive to a shop to buy water. Traffic signals are out and you are adding a road
  casualty to a power cut.
- Do not call the emergency number to report an outage. Call your utility; call the emergency
  number for a life at risk.
- Do not open the freezer "just to check." Every opening spends hours.
- Do not start a generator in a garage, a basement, a stairwell or on a balcony that vents
  back into the flat.
- Do not give a dehydrated child a homemade salt-and-sugar mix. Store sachets; never improvise
  the ratio. Doc 06 explains why in one page.

---

## 0.7 The day 1 → 90 timeline

This is what actually changes over ninety days without utilities, and when the decision tree
in doc 01 is allowed to fire. The days are planning markers, not dates on a calendar — a water
main break and a winter storm do not fail on the same schedule.

### Day 1 — the first hour, then the first night

Nothing has failed yet except the utility. The fridge clock is running (4 h / 48 h / 24 h).
Water is still in the pipes and the heater. **The tree does not fire today** unless a life
safety trigger is already present: a powered medical device that has stopped, fire, flood, or
a home you cannot keep above freezing. Tonight's job is light, warmth without combustion
indoors, and one adult awake long enough to know the CO alarm is working.

### Day 3 — the first real check

The fridge food is eaten, cooked or discarded. Freezer food is being cooked off if the outage
looked long. Sanitation has stopped being theoretical — you now know whether your disposal
route actually exists. **First tree check at 72 hours:** water consumed against the plan, waste
contained, temperature inside the home, and whether anyone has started to look unwell.

### Day 7 — the arithmetic gets real

A household of five at the conservative planning figure of **2 gallons per person per day** is
using **10 gallons a day**. By day 7 you have spent roughly 70. If your stored buffer is a
14-day buffer, you are halfway through it and you now know your true daily burn. This is the
week to **ration by activity** rather than by thirst — Ready.gov is explicit that you should
**never ration drinking water unless authorities order it**; you reduce activity instead. This
is also when a heat wave or a cold snap forces the branch 2 conversation, because temperature
is the trigger most likely to move an elder out of the building.

### Day 14 — the sharpest decision point in the program

If there has been no resupply, the **14-day buffer is gone**. This is the day the plan stops
being about storage and starts being about harvest, treatment and rationing — and the day
**branch 2 (go somewhere staffed) or branch 3 (slow exit) stops being hypothetical**. It is
also the day a household that never wrote a decision card makes its worst decisions, which is
the entire reason the card exists.

### Day 30 — the new normal

The acute phase is over. What is left is rhythm: water production, food rotation, waste,
laundry, schooling, and the morale of the person who has been carrying it. Two things are now
the real risks — **the elder's medication running out** and **the adult burning out**. Doc 06
covers the first, `MOR-1` the second. Re-score the readiness scorecard in §0.5; it will have
moved.

### Day 60 — the long tail

Prescription refills are long exhausted. The waste question that doc 01 flagged as the plan's
real failure point has either been solved locally or is now the reason to move. Mutual aid has
either become a working arrangement with three neighbors or it never will. If the household
is still in place at day 60 and stable, that is a genuine achievement and it should be said out
loud to the people doing it.

### Day 90 — the honest accounting

Either the utilities are back, or the household has executed a branch, or the household has
decided to stay and has written down what it is accepting. All three are legitimate outcomes.
The failure outcome is the one nobody planned: drifting from day 14 to day 90 without ever
making a decision, on the assumption that something would change.

**What never changes across all ninety days:** water is stored, harvested, treated and rationed;
waste has a route; warmth comes from something that is not poisoning the air; medication and
devices have a plan; and the person who cannot run is never the last thing anyone thought
about.

---

## 0.8 Before you turn the page

You have three things to do this week, and they are all in the next document:

1. Read **01** and fill in the hazard matrix for your own building — not the generic one.
2. Run the **household meeting** in `BAS-4` and get the decision card signed by every adult.
3. Score the §0.5 scorecard once, honestly, and date it.

Everything else in this manual is downstream of those three.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it
on; we would rather refund than have you carry a plan you do not trust. This is version 1.0,
errata date 2026-11-02. Corrections and version history are recorded in the README, and any
corrected figure is dated.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call
your local emergency number. Follow your local health authority's guidance over anything in
this guide. Written for US households.*
