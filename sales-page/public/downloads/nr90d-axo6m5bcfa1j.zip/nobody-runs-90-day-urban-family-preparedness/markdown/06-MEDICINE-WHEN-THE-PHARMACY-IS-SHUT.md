# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 06 — MEDICINE WHEN THE PHARMACY IS SHUT

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

For half of American households, a 90-day outage is not primarily a food problem or a water problem. It is a
**medication-supply problem** with a food and water problem attached. Ready.gov's own framing is blunt about the
scale — roughly half of all Americans take a prescription medicine every day — and about the mechanism: an
emergency makes it hard to refill a prescription or find an open pharmacy. A cardiac patient, a diabetic, a person
on seizure medication, a person on an oxygen concentrator: for all of them, day four is the day the plan is
tested, and no amount of stored rice helps.

This chapter covers the medicine kit, medication and device continuity, rehydration, the evidence-graded home
remedies, and the "do not do this" list that this program considers its most important page. It closes with
modules **`MED-1`**, **`MED-2`**, **`MED-3`** and **`MED-5`**. Nothing here is finished by reading it.

> **The two rules this whole chapter is built on.**
> **First: this program prints no dose.** Not milligrams, not tablets, not "adult versus child," not "every four
> hours." Every medicine in this chapter is handled by one instruction — **follow the label**, or follow the
> prescription, and ask a pharmacist or clinician when the two seem to disagree. A dose printed in a book written
> eighteen months ago, for a person the book has never met, is not medicine; it is a guess with a number on it.
> **Second: this program prints no rehydration recipe.** The reason is in §6.3 and it is the most important
> paragraph in the chapter.

---

## 6.1 The medicine kit — module `MED-1`'s list

### 6.1.1 What the sources actually give us

Ready.gov's emergency-kit guidance names the categories, and that is the level of granularity the sources support:
**"Non-prescription medications such as pain relievers, anti-diarrhea medication, antacids or laxatives"** and
**"Prescription medications."** Nothing in the retrieved sources gives a household a shelf life, a dose, or a
"stock these twelve things" list, and the writer's instruction was explicit: **do not fill rows from general
knowledge.**

So this section does two things. It gives the **categories** with what each one is for and the one warning that
attaches to it, and it gives the **principle** — rotation, storage, the label — which is what actually keeps a
medicine kit usable. What it does not give is a shopping list with doses, and any product that does is guessing.

### 6.1.2 The categories, and what each is for

**Pain reliever / fever reducer.** The most-used item in any kit and the one most likely to be double-dosed,
because it is in three different products at once — the headache tablets, the cold-and-flu sachet, the night-time
formula. **The only instruction this program prints is the label's own: follow the label, and do not combine
products that contain the same active ingredient.** Read the active-ingredient panel on every box, every time,
because packaging changes and the household's stock will be a mixture of brands bought in different years.

**Anti-diarrhoeal.** For diarrhoea that is inconvenient. **Not for diarrhoea with fever or blood in it**, which is
a different illness and a "get seen" illness — and this program will not print a home rule about which
anti-diarrhoeal to use in which case, because that judgement needs a clinician and the sources retrieved did not
cover it. The rehydration plan (§6.3) matters far more than the anti-diarrhoeal does.

**Antacid.** Symptom relief for indigestion. In an outage this is a morale item as much as a medical one: a week
of unfamiliar food, eaten cold, out of cans, produces heartburn in people who never get it.

**Laxative.** The other half of the same problem. Unfamiliar food, less water, less movement and a disrupted
routine produce constipation, and in an older person that is a genuine medical event rather than a discomfort.

**Rehydration sachets (ORS).** Their own module — §6.3. Store them; never improvise the mixture.

**Antihistamine.** For allergic symptoms. **It is not anaphylaxis treatment** — doc 05 §5.4 — and the household
must be able to say that sentence out loud, because the tablets are in the cupboard and the auto-injector is in a
drawer and the tablets are faster to reach.

**Hydrocortisone cream and antibiotic ointment.** For skin. **This program prints no wound-care dressing or
ointment protocol** (doc 05 §5.8): wash with soap and clean water, cover, and watch for redness, swelling or
oozing.

**Adhesive bandages and antiseptic.** Doc 05 §5.1 covers the trauma half of the kit; this is the overlap, and it
should not be bought twice.

**Thermometer.** The single most useful diagnostic object a household owns, and the one that is most often dead or
missing when it is needed. A thermometer turns "she feels warm" into a fact the household can report to a
clinician on the phone.

**Glucose meter and supplies**, for a diabetic member — with the caveat in §6.2 that the meter itself is a
battery-powered device and the strips expire.

**Saline nasal spray.** Comfort for dry air and congestion, and a low-cost item in a winter outage with the heat
off.

**Children's formulation of a fever reducer.** A separate bottle, in the children's strength, because the adult
tablet is not a child's dose cut in half. **Follow the label, and use the dosing device that came with the
bottle** — a kitchen spoon is not a measuring device.

**Anything prescribed to a member of this household.** The prescription list is `MED-2`'s business and it is the
most important page in the kit.

### 6.1.3 Expiry, storage and rotation — the principle

**What "expired" means, per the FDA:** expired medical products "can be less effective or risky due to a change
in chemical composition or a decrease in strength," and "certain expired medications are at risk of bacterial
growth." The FDA also stresses storing medicines properly so that they "remain safe and effective up to their
expiration date" — in other words, the date is only meaningful if the storage was right.

That gives this household three rules, and they are the whole of the expiry section:

1. **Rotate; do not gamble.** The kit is a stock that gets used and replaced, oldest first, with the date written
   on the box in marker when it goes in. **Using expired medicine as a planned strategy is not a plan** — it is
   the household deciding that a weaker or degraded medicine is good enough for the person who needs it most.
2. **Store it like medicine, not like camping gear.** Cool, dry, out of the light, out of the bathroom cabinet
   (humid), out of the car, out of the kitchen above the stove, and **out of the fridge unless the label says
   refrigerate** — a fridge is a damp place with a defrost cycle, and it stops working in an outage (§6.2).
3. **Check it when the clocks change**, at the same time as the CO alarm batteries (`CO-1`) and the first-aid kit
   (doc 05 §5.1.3). Two dates a year, one walk round the flat, one list of what to replace. **Every item that
   expires is replaced, not kept "for the real thing."**

**The child-safety point that an outage creates:** a household that has moved its stores into a warm room, a
hallway or a bag has moved its medicines into reach. **One lockable box, high, out of the toddler's reach, and the
household's adults all know which box it is.** Poisoning is a far more likely injury in a disrupted household than
in a settled one.

### 6.1.4 The list on paper beats the box

The kit is worth nothing if nobody knows what is in it. **Doc 10's medication list is the real `MED-1` deliverable**
— every medicine, every dose, every prescriber, every refill date, written by hand, kept with the kit, and copied
for the go-bag and the ICE card. In an outage the list is what you hand a paramedic, what you read to a pharmacist
on the phone, and what a neighbour takes to the pharmacy if you cannot go yourself.

---

## 6.2 Medication and device continuity — module `MED-2`

### 6.2.1 The framing: this is a power and refrigeration problem

**Most preparedness writing treats medication continuity as a matter of "having enough pills."** That is the
smaller half. Ready.gov's guidance is about the bigger half, and it is worth quoting because it names the two
things households forget: *"Talk to your medical provider about a power outage plan for medical devices powered by
electricity and refrigerated medicines. Find out how long medication can be stored at higher temperatures"* — and
*"Have alternate plans for refrigerating medicines or using power-dependent medical devices."*

**The device list, from `BAS-2`, and each one is a person for whom day one of an outage is an emergency:**

- **Oxygen concentrator** — runs on mains power, delivers continuously, and has no stored reserve. A concentrator
  household is on bottled oxygen or on the move, and there is no third option. **And oxygen plus any open flame is
  a fire death**, which is why doc 04 §4.1.3's never-indoors list is a hard rule in that house and why the 72-hour
  drill (§3.0) excludes these households entirely.
- **Home dialysis** — a mains-powered machine with a water supply requirement, and a schedule that does not
  negotiate.
- **Infusion pump** — battery for hours, not days.
- **CPAP or BiPAP** — battery for a night or two at best, and the person who cannot use it does not sleep, which
  degrades everything else in the plan within 48 hours.
- **Powered wheelchair or scooter** — the mobility plan in doc 08 depends on the charge, so the chair is charged
  whenever the power is on, always, without discussion.
- **Insulin** — refrigerated in normal use, and the one medicine where heat degrades the product quietly and the
  person finds out by feeling ill.

### 6.2.2 The three conversations, which are the whole module

This program cannot tell you how long your insulin keeps at 80 °F, because the answer is product-specific and it
is printed on your own label and in your own prescriber's answer. What it can do is make sure the conversation
happens, three times, and gets written down:

1. **The provider conversation.** *"If the power is out for three days, what do I do about this medicine and this
   device?"* Ask for the answer in writing, ask what the alternative is, and ask what the warning signs are that
   mean "go to an emergency department now." **How long the medicine can be stored at a higher temperature is a
   question for the prescriber or the pharmacist, not a number this book invents.**
2. **The pharmacy conversation.** *"Can I have a refill a week early so I am never below a few days' supply?"* Many
   insurers and pharmacies will work with a household that asks in advance, and almost none will work with one that
   asks on day three of a blackout. Ask about the emergency-refill rules in your state, and ask what the pharmacy
   does when its own power is out.
3. **The equipment supplier conversation.** For an oxygen concentrator or a dialysis machine, the supplier — not
   the household — is the one who knows the backup plan, the loaner policy and the priority-restoration route.
   **Get the supplier's emergency number written on the ICE card.** Do not assume that a utility or a city knows
   this address has a medical device in it; ask whether there is a registry and get on it if there is.

### 6.2.3 The refrigeration plan, without inventing temperatures

**The honest position: this program prints no "your insulin is good for X hours at Y degrees" figure.** It is
product-specific, the label carries it, and the provider's answer is the one that counts. What the household can
do without any figure at all:

- **Keep the fridge shut.** Doc 03 carries the FDA food clock and the four-hour rule; the same discipline protects
  the medicine in the fridge, and every door opening shortens both clocks.
- **Move the medicine out of the fridge only when the plan says so** — a cooler with ice packs, or the provider's
  stated alternative — and **never freeze it**: a fridge that stops in winter, or a cooler with too much ice, can
  freeze a liquid medicine, and a frozen medicine is a spoiled medicine.
- **Label the cooler, and label the ice.** A cooler that also holds food is a cooler that gets opened.
- **Write down the time the power went off.** That single fact is what every subsequent conversation needs — with
  the provider, the pharmacist, the supplier, and the emergency department.
- **A thermometer in the fridge** turns the guess into a reading. It costs a few dollars and it is the only way to
  know what happened while the doors were shut.

### 6.2.4 The rules that do not bend

- **Nothing is stopped, halved or skipped because the supply looks short.** CDC's wording is unambiguous:
  **"Don't stop or change your medicines until you talk to your doctor."** Stretching a cardiac or seizure
  medication to make it last is the most common way a supply problem becomes a death, and it is done with the best
  intentions by the most careful person in the house.
- **Heat is a medicine problem too.** CDC notes that some medicines make a person more prone to dehydration or
  overheating, and some "need to be kept out of hot places." In a heat wave (doc 04 §4.3) the medicine box moves to
  the coolest room, and the at-risk member is checked, not asked.
- **The list travels.** A photograph of the medication list on every adult's phone, plus the paper copy in the kit,
  plus a copy in the go-bag (doc 08).
- **A new confusion in an older person on multiple medicines is a medical event**, not a bad night. It is also the
  presentation of an infection (doc 05 §5.8.2), of dehydration (§6.3), of heat, and of a drug interaction — and
  only a clinician can tell them apart.

---

## 6.3 Rehydration — module `MED-3`, and the hard rule

### 6.3.1 The rule, first, because everything else is explanation

> **Store rehydration sachets. Use them as the packet says. Never improvise the mixture.**
>
> **There is no salt-and-sugar rehydration recipe in this program, and there never will be.** No spoon measures, no
> home ratio, no "recipe from a website" — not even one printed as a warning, because a printed ratio is a ratio a
> frightened person will use. If you run out of sachets and someone is dehydrated, **that is a medical emergency: get
> to a health facility.** Do not mix your own.

### 6.3.2 Why the rule is absolute

**Oral rehydration salts are a medicine, not a kitchen preparation.** That is not this program's opinion; it is
the World Health Organization's own regulatory framing. WHO states that ORS "is considered as a medicine, like the
old formulation, and has been included in the **WHO model list of Essential Medicines**" and that "it should be
manufactured as a pharmaceutical product, following all the requirements of the Good Manufacturing Practices."

A medicine on the essential-medicines list is a medicine with a **narrow therapeutic margin**, and the two ways a
home mixture fails are both dangerous in opposite directions:

- **Too much salt** causes hypernatremia — brain injury and seizures. A dehydrated child given a too-strong
  solution is worse off than a dehydrated child given plain water.
- **Too little salt and too little glucose** produces a solution that does not drive water absorption at all, and
  can worsen the diarrhoea it was meant to treat.

The margin between "helps" and "harms" is small enough that the organisation which manufactures ORS for the whole
world treats the ratio as a manufacturing specification rather than a household instruction. **A preparedness book
printing its own ratio would be printing a guess in the one place a guess causes a seizure.** That is why this
page is short.

### 6.3.3 What the household actually does

**Buy sachets, and buy them now.** They are cheap, light, and store for years in a cupboard — which makes them the
single best value item in the whole medical store, and the one most often left out because it is not dramatic.
Store them with the medicine kit, dated, in a quantity that matches the household: **the toddler and the elder are
the two people most likely to need them and the two least able to tolerate a mistake.** A box of sachets costs
less than a takeaway meal and covers the household's most likely medical emergency.

**Use them as the packet says.** The packet states the volume of clean water and how to mix it, and that
instruction is the authority — it is the manufacturer's, it is on the sachet, and it varies by product. **Clean
water means doc 02's treated water, not stored water of unknown age.** Mix it fresh, and do not keep a mixed
solution for later; the packet says what it says about that too, and the packet wins over any habit.

**Understand what ORS is for.** WHO draws the distinction that matters and it is worth printing plainly: oral
rehydration therapy begins at home with available fluids or a home-prepared solution **to prevent** dehydration —
but **"once a child becomes dehydrated, however, ORT should be provided in the form of a balanced and complete
standard mixture of glucose and salts (ORS)."** In other words: **prevention is drinking; treatment is a medicine.**
A household that has sachets can treat. A household that has run out cannot, and must move.

**Why this matters at all:** WHO's own item page says it in six words — **"In most cases, death is caused by
dehydration."** Diarrhoeal illness after a disaster is the sanitation-linked risk in a household whose water and
toilets have failed (doc 04 §4.6), and CDC's instruction to households is to stay hydrated with safe water or ORS
**and to visit the nearest health facility.**

### 6.3.4 Who must not be given sachets, and who must go now

- **An infant under six months** is not a sachet case. That is a clinician's call, always.
- **A lethargic or floppy child** — one who is hard to wake, or who will not respond normally — is not a home
  treatment case, sachets or no sachets. Go.
- **A child vomiting everything back** cannot be rehydrated by mouth at home. Go.
- **Bloody diarrhoea** is a different illness. Go.
- **No urine for many hours, sunken eyes, a sunken fontanelle in a baby, skin that stays pinched when released,
  or a rapid weak pulse** — these are dehydration signs, and they are the point at which the household's job is
  transport, not treatment.
- **An adult who is confused, very weak, or has not passed urine** — same answer.

**And the sentence that goes with all of them:** the household's plan for a dehydrated person is **sachets plus a
route to care**, not sachets instead of care. Write the route down before you need it (doc 08).

---

## 6.4 Evidence-graded home remedies

### 6.4.1 How this section is graded, and why the grading matters

Every rating below is the **National Center for Complementary and Integrative Health's** own, paraphrased. NCCIH
is a federal institute and it is the reason this section exists in this shape: instead of a list of grandmother's
remedies presented as treatment, the household gets **the federal evidence grade** — LIMITED, INSUFFICIENT, or
**not rated at all** — attached to each one.

**The three grades, in plain words:**

- **LIMITED** — some research suggests it may help for a specific thing, and the research is not strong.
- **INSUFFICIENT** — the studies have not produced enough reliable evidence to say whether it works.
- **NOT RATED / FOLKLORE** — nobody has graded it. **This program prints it as folklore, labelled as folklore, and
  never as a recommendation.** A remedy with no grade is not a weak remedy; it is an unknown one.

**And the rule that sits above all of them:** **no remedy in this section replaces a prescription, and none of
them replaces getting care.** A household that treats a pneumonia with a tea has not treated a pneumonia.

### 6.4.2 The graded list

**Ginger — LIMITED, for nausea.** NCCIH's wording is careful: there have been many studies, but "some of them have
not been of high quality." Research shows ginger "may be helpful for nausea and vomiting associated with
pregnancy," and it "might be helpful for reducing the severity of menstrual cramps." Two useful negatives: **"Most
studies of ginger for motion sickness haven't shown it to be helpful,"** and it is uncertain whether ginger helps
as an addition to standard treatment for chemotherapy- or surgery-related nausea. Safety: ginger "has been used
safely in many research studies" as a dietary supplement, with side effects including abdominal discomfort,
heartburn, diarrhoea and mouth irritation. **In pregnancy, NCCIH says to consult your health care provider.**

**Chamomile — INSUFFICIENT.** NCCIH: studies of chamomile for specific conditions **"have not produced sufficient
reliable evidence to rate clinical usefulness."** It is "likely safe when used orally in amounts commonly found in
teas and other foods," side effects are uncommon but include nausea and dizziness — **and allergic reactions,
including severe hypersensitivity reactions and anaphylaxis.** That last clause is why chamomile tea is not a
"harmless" item to hand a person with a pollen allergy in a house with no ambulance nearby.

**Peppermint leaf / tea — INSUFFICIENT.** "Very little research has been done on peppermint leaf. There is not
enough evidence to definitely determine whether peppermint leaf is useful for any health condition." Follow product
labels, and **do not use peppermint preparations around the face of an infant or young child** — that caution is
standard, and this program states it as a caution rather than a sourced rule.

**Peppermint oil, enteric-coated, for IBS — LIMITED.** "A small amount of research suggests that peppermint oil in
enteric-coated capsules may improve IBS symptoms in adults," and a 2021 American College of Gastroenterology
clinical guideline recommended peppermint oil for overall IBS symptom relief. **The enteric coating is the point**
— that is the formulation the research is about, not peppermint sweets or a bottle of essential oil. Follow the
label.

**Honey — NOT RATED. Folklore, not evidence.**

> **⛔ The infant warning, which is the most important line in this section.** CDC: **"Honey is not safe for
> infants. Honey can contain the bacteria that cause botulism."** CDC's instruction is plain: **"Do not feed honey
> to a child who is younger than 1 year old."** CDC also records that several babies in Texas became ill with
> infant botulism after using honey pacifiers, and says: **"Do not give honey or products made with it, including
> honey pacifiers, to infants."**

Honey for a cough, or honey on a wound, is a traditional remedy with **no NCCIH rating retrieved** — which means it
is **unrated, not endorsed**. It appears here so that a household that has heard of it knows what the federal
position is: ungraded, and **absolutely barred for any child under one year.** In a household with a baby, that
warning belongs on the fridge, not in a book.

**Saline nasal rinse, steam, willow bark, colloidal silver as remedies — NOT VERIFIED / DO NOT USE.** NCCIH's
willow-bark page could not be retrieved, and saline and steam were not retrieved either, so none of them gets a
grade here. Two specific warnings: **willow bark is a salicylate and is not a substitute for aspirin or any
medicine** — the aspirin-substitute idea is dangerous in a child and in anyone with a salicylate sensitivity; and
**colloidal silver is in the "do not do this" list below** (§6.5).

### 6.4.3 The folklore label, and the honest use of it

**Any remedy not graded above carries the label "FOLKLORE — not evidence-rated."** That includes honey for
wounds, steam for congestion, saline rinses, willow bark tea, and every "my grandmother swore by it" that a
household brings into an outage. **The label is not an insult to the grandmother.** It is the difference between a
household that knows it is using a comfort measure and one that thinks it is using a treatment — because the
second household waits two more days before seeking care.

**A comfort measure used knowingly is legitimate.** A cup of chamomile tea in a cold flat with no power is a good
thing to have. It is not a treatment for an infection, and the household that can say both sentences is the one
that stays safe.

---

## 6.5 The "do not do this" list

### 6.5.1 Why this is the most important page in the program

Every item below is something a frightened, sensible person does in a real outage, having read it somewhere, or
having half-remembered it, or having been told it by someone confident. **None of them looks stupid at the time.**
That is exactly why the list is printed, why it is memorised, and why the module's written check is **10 out of 10,
with no partial pass**: a household that gets nine of these right and one wrong has a fifty-fifty chance of the
wrong one being the one it does.

### 6.5.2 The ten

**1. Drink bleach, or "purify" yourself with bleach.**
Bleach is a corrosive poison. In water treatment it is a **measured dose for water** — EPA and CDC give it only as
a water-disinfection dose, with a contact time, for water — and **neither source countenances ingestion.** A
household that has bleach for water treatment (doc 02) and a person who is ill is a household one bad idea away
from a poisoning.

**2. Colloidal silver as an antibiotic.**
NCCIH: "Colloidal silver can cause serious side effects. The most common is **argyria**, a build-up of silver in
the body's tissues causing a bluish-gray discoloration of the skin," which is usually permanent. Studies of
colloidal silver nasal spray for chronic sinus infections **"did not demonstrate meaningful improvements."** It is
not an antibiotic, it does not treat an infection, and it turns people grey.

**3. Fish-tank antibiotics, mail-order antibiotics, or "making your own."**
No quality control, wrong drug, wrong dose, resistance, poisoning — and the household has no way to tell which of
those it has bought. **This program contains no antibiotic synthesis, dosing or sourcing guidance and never will.**
Antibiotics are prescription medicines used under a clinician's direction. Full stop.

**4. Unverified tinctures and "natural antibiotics"** — oregano oil, grapefruit seed extract, and the long tail of
the same.
Unknown concentration, liver and kidney harm, interaction with the prescriptions the person is already taking, and
the delay of real treatment while the household waits to see whether it works. **No NCCIH rating was retrieved for
these: they are not evidence-rated, and they are never a substitute for a prescription.**

**5. Potassium iodide when there is no radiological release.**
KI protects the thyroid against radioactive iodine and nothing else. CDC: **"Do not take KI unless instructed by
public health or emergency response officials or a healthcare provider."** It is recommended **only for people
under 40 and women who are pregnant or breastfeeding**; it "protects **only** against radioactive iodine"; it
"protects **only the thyroid**"; and — the myth inside the myth — **"Do not use table salt or foods that contain
iodine as a substitute for KI. They do not help prevent internal contamination, and eating large amounts could be
harmful."** Only FDA-approved KI products, and not by anyone with a known iodine sensitivity without a clinician's
word.

**6. Stopping or stretching prescribed medicines because the pharmacy is shut or the supply looks short.**
CDC: **"Don't stop or change your medicines until you talk to your doctor."** Halving a dose to make it last is the
most understandable mistake on this list and the most lethal. If the supply is short, the answer is a phone call, a
pharmacy, an emergency refill rule, or a move — not arithmetic done at the kitchen table.

**7. Diluting infant formula to stretch it.**
Watery formula starves an infant of calories and electrolytes. The household instruction is Ready.gov's, and it is
printed instead of the dilution rule: **"Use ready-to-feed formula. If you must mix infant formula use bottled
water or boiled water as a last resort."** A stretched tin is a malnourished baby, and in an outage that is a
hospital admission in a week.

**8. Using pool shock or calcium hypochlorite to disinfect drinking water.**
Uncontrolled concentration, caustic, and not authorised by EPA or CDC for drinking water. EPA's emergency
disinfection page specifies **household chlorine bleach** and nothing else; neither EPA nor CDC offers a
pool-chemical recipe, and a household mixing one is guessing at a concentration that can burn a throat. Doc 02 has
the sourced method.

**9. Drinking water from radiators or heating boilers.**
CDC: **"Never use water from radiators or boilers that are part of your home heating system for drinking, cooking,
or hygiene. This water could make you sick."** It is the most repeated urban myth in cold-weather preparedness and
it is a hard no. Heating-system water carries treatment chemicals and corrosion products.

**10. Boiling water to fix chemical contamination.**
CDC: **"You cannot make water containing fuel, toxic chemicals, or radioactive materials safe by boiling or
disinfecting it."** EPA: boiling and disinfection "will not destroy other contaminants, such as heavy metals,
salts, and most other chemicals." Boiling concentrates some of them. **Boiling is for germs** (doc 02); a fuel
smell or a chemical spill means a different source, not a longer boil.

## 6.6 Module `MED-1` — Build the medicine kit

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Pass level: DEMONSTRATED, and CAN TEACH IT on the rotation rule.
> Prerequisite: `BAS-2` (the medical and device inventory) is written.**

**Objective.** Assemble a medicine kit that matches the sourced categories, date and rotate it, and produce the
written medication list that makes the kit usable by someone else. **Chapters.** `06 §6.1` · `05 §5.1` · `10`.

**Drill — the box, the dates, the list.** One hour.

1. **Empty the household's existing medicines onto a table**, in daylight, and sort into three piles: in date, out
   of date, and unknown. The unknown pile is thrown away — an unlabelled bottle is not a medicine.
2. **Check the categories against §6.1.2** and write what is missing, in the household's own words, with the reason
   for each. **Do not write a dose anywhere.** Every line ends with "follow the label."
3. **Date every box in marker** as it goes into the kit, oldest at the front, and **lock the box** where a toddler
   cannot reach it.
4. **Write the medication list** (doc 10) for every member: medicine, dose as prescribed, prescriber, refill date,
   and the pharmacy's phone number. Photograph it onto every adult's phone and put a paper copy in the kit and the
   go-bag.
5. **Set the two check dates** in the calendar — the clock changes — with the CO alarm test (`CO-1`) and the
   first-aid kit check (doc 05 §5.1.3).

**Observable pass criteria — all five:** the kit contains the **sourced categories** and every missing item is
written down with a reason; **every box is dated** and the rotation order is visible; the **kit is locked** and out
of a child's reach; the **medication list is complete, photographed and copied** to kit and go-bag; and the
household states, unprompted, that **no dose is written in this program and the label is the authority.**

**Assessment.** By an adult who did not build the kit, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. **Hours.** 1, plus the list.

**Who must be able.** Every adult to DEMONSTRATED; **two adults to CAN TEACH IT** on the rotation rule. **Children
over eight must know the box is not theirs and must never open it.**

---

## 6.7 Module `MED-2` — Medication and device continuity

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical for any household with a mains-powered device or a
> refrigerated medicine. Pass level: CAN TEACH IT. Run before `DRILL-1` — §3.0 excludes these households from the
> drill until this module is complete.**

**Objective.** Produce a written continuity plan built around power and refrigeration, with the three conversations
had and their answers recorded. **Chapters.** `06 §6.2` · `04 §4.2` · `04 §4.3` · `08` · `10`.

**Drill — three calls and one written page.** Two hours, plus the calls.

1. **List every device and every refrigerated medicine** from `BAS-2`, and beside each one write **what happens at
   hour 4, hour 24 and hour 72** without mains power. If the answer is "I don't know," that is the question for
   call one.
2. **Make the provider call:** what to do about this medicine and this device in an outage, how long the medicine
   tolerates higher temperatures, what the warning signs are, and what the alternative is. **Write the answers
   down.**
3. **Make the pharmacy call:** early refill, emergency-refill rules, and what the pharmacy does when its own power
   is out. **Make the supplier call** for any concentrator, dialysis machine or pump, and put its emergency number
   on the ICE card.
4. **Write the one-page refrigeration plan:** where the cooler is, what cools it, who checks it, the fridge
   thermometer's place, and **the time the power went off written on the page the moment it goes off.**
5. **Recite the rule:** nothing is stopped, halved or skipped because the supply looks short — CDC: **"Don't stop
   or change your medicines until you talk to your doctor."**

**Observable pass criteria — all five:** a **written device and medicine list with hour 4 / 24 / 72 answers**
exists; the **provider answers are written down**, including how long the medicine tolerates heat; the **pharmacy
and supplier calls are made** and the supplier's emergency number is on the ICE card; the **one-page refrigeration
plan exists** with a named checker and the power-off time rule; and the **no-stopping, no-halving rule is recited
unprompted.**

**Assessment.** By an adult who did not run the drill, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; a household that cannot answer "what happens at hour 24" has not passed. **Hours.**
2, plus the calls.

**Who must be able.** Every adult to CAN TEACH IT on the rule and the plan's location; **the household's designated
carer to CAN TEACH IT on the whole page.**

---

## 6.8 Module `MED-3` — Rehydration by sachet

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical. Pass level: CAN TEACH IT. This module exists in the shape
> it does because the ratio is deliberately absent — §6.3.1.**

**Objective.** State the hard rule, mix a sachet exactly as the packet says, and name the signs that mean hospital
instead. **Chapters.** `06 §6.3` · `02` · `04 §4.6` · `10`.

**Drill — one sachet, one packet, one refusal.** One hour.

1. **Recite the rule, verbatim:** *"Store rehydration sachets. Use them as the packet says. Never improvise the
   mixture."*
2. **Mix one sachet in front of the assessor**, using clean water from the household's treated store, **following
   the packet's own instruction and nothing else** — read the packet aloud first, including the water volume it
   states. Say where the water came from and why it is not stored water of unknown age.
3. **State the prevention-versus-treatment distinction** (§6.3.3): home fluids to prevent dehydration; **ORS, a
   medicine, once someone is dehydrated.**
4. **Name the five go-now signs** (§6.3.4): an infant under six months, a lethargic or floppy child, a child
   vomiting everything, bloody diarrhoea, and the dehydration signs — and say the sentence *"sachets plus a route
   to care, not sachets instead of care."*
5. **Say what the household does when the sachets run out:** go. **Do not mix your own**, and state the reason —
   too much salt and too little salt are both dangerous, which is why WHO classifies ORS as a medicine.

**Observable pass criteria — all five:** the **rule is recited verbatim**; the sachet is **mixed exactly to the
packet's stated volume with named clean water**, not estimated; the **prevention-versus-treatment distinction is
stated correctly**; the **five go-now signs are named** and the "sachets plus a route to care" sentence is used;
and the household states, unprompted, that **running out means going, not improvising** — and that **this program
contains no home ratio, by design.**

**Assessment.** By an adult who did not run the drill, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; pass level **CAN TEACH IT** — the person who mixes the sachet may have to teach
someone else in the same hour. **Hours.** 1.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must know to fetch an adult and must never
mix or give a drink to a person who is confused or very sleepy.**

---

## 6.9 Module `MED-5` — The "do not do this" list

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical: written check, 10 out of 10, no partial pass. Every adult,
> closed book, every six months.**

**Objective.** Answer all ten statements correctly and give the one-line reason for each. **Chapters.** `06 §6.5` ·
`02` · `03` · `05 §5.8` · `10`.

**Drill.** Read §6.5.2 once, close the book, take the check below. **Nine out of ten is a fail and a re-teach.**

### 6.9.1 The written check — 10/10, no partial pass

> **The rule: every adult in the household takes this written check, closed book, and scores 10 out of 10. Nine is
> a fail and a re-teach. There is no partial pass, no "close enough," and no adult exempted because they "already
> know all this" — the check is not a test of intelligence, it is a test of whether the correct sentence is the one
> that comes to mind at 2 a.m.**

**The check.** Mark each statement **TRUE** or **FALSE**. Write the one-line reason beside each one.

1. If the pharmacy is shut and someone's tablets are running low, the safe move is to halve the dose so the supply
   lasts longer.
2. Colloidal silver is a reasonable antibiotic substitute when antibiotics cannot be obtained.
3. Bleach is safe to drink in a small amount if it has been diluted the way it is diluted for water treatment.
4. Honey is a good treatment for a coughing baby.
5. Potassium iodide protects the whole body against radiation, and iodised table salt is a substitute for it.
6. Pool shock can be used to disinfect drinking water if you measure it carefully.
7. Water from the radiators or the heating boiler is drinkable in an emergency.
8. Boiling water makes it safe even if it smells of fuel or has been contaminated with chemicals.
9. Fish-tank antibiotics are acceptable if the dose on the fish product is scaled to a person's weight.
10. Diluting infant formula with extra water is a sensible way to stretch a supply.

**The key, and the reason for each answer:**

1. **FALSE.** CDC: don't stop or change medicines until you talk to your doctor. Halving a dose is a change.
2. **FALSE.** NCCIH: serious side effects including permanent argyria; nasal-spray studies showed no meaningful
   improvement.
3. **FALSE.** Bleach is a measured dose for **water**, never for a person; EPA and CDC do not countenance
   ingestion.
4. **FALSE.** CDC: honey is not safe for infants — it can contain the bacteria that cause botulism; do not give
   honey or honey products to a child under one.
5. **FALSE.** KI protects only the thyroid, only against radioactive iodine, and only when officials say to take
   it; table salt is not a substitute and large amounts are harmful.
6. **FALSE.** Not authorised by EPA or CDC for drinking water; household chlorine bleach only.
7. **FALSE.** CDC: never — heating-system water can make you sick.
8. **FALSE.** CDC: you cannot make water containing fuel, chemicals or radioactive material safe by boiling.
9. **FALSE.** No antibiotic synthesis, dosing or sourcing is in this program and none will be; antibiotics are
   prescription medicines used under a clinician's direction.
10. **FALSE.** Ready.gov: use ready-to-feed formula; if you must mix, use bottled or boiled water as a last resort
    — never stretch the powder.

**A note for the assessor:** a household that answers all ten correctly has learned the shape of the problem — *the
dangerous answer is always the one that seems to make the shortage go away.* Re-run the check every six months with
the clock-change walk (doc 05 §5.1.3), and re-run it immediately after any new adult joins the household.

**Observable pass criteria:** **10 out of 10, closed book, by every adult, each with a one-line reason** — and the
reason must be the real one (a poisoning risk, a narrow margin, a permanent side effect), not a restatement of the
statement. **Nine is a fail.** No adult is exempted, and no adult may take it open-book "because they wrote it."

**Assessment.** By an adult who did not write the answers, or a neighbour/CERT witness, who marks it and re-teaches
any missed item out loud. Rated **NOT YET / DEMONSTRATED**; there is no CAN TEACH IT tier on this one, because the
demonstration is the ten correct answers. **Hours.** 1.

**Who must be able.** Every adult, to 10/10. **Children over eight must be able to say three sentences
unprompted:** *never drink bleach; honey is not for babies; never stop or change someone's medicine.*

---

## 6.10 Closing the chapter

**What this chapter gives you is a stock, a list, a route, and ten things you will not do.** You know the OTC
categories and that the label — not this book — carries the dose. You know expired medicine may be less effective
or risky, per the FDA, so the kit rotates and the dates are on the boxes. You know that half of American households
take a prescription daily, that a power outage plan for devices and refrigerated medicines is a conversation with a
provider rather than a purchase, and that CDC's rule is that nothing is stopped or changed without the doctor. You
know that rehydration salts are a WHO essential medicine with a narrow margin, that sachets are the answer and a
home mixture is not, and that a lethargic child or a bloody diarrhoea is a hospital, not a sachet. You know the
federal evidence grades on the common remedies, that honey is unrated and barred for infants, and that the ten
myths are the ten because each one is a thing a careful person does in a bad week.

**What this chapter deliberately does not give you is a number.** No dose, no rehydration ratio, no "how long
insulin lasts at room temperature," no shelf-life table beyond the label. Each of those belongs to the label, the
pharmacist, the prescriber, or the manufacturer's own instructions — and every one of them is a phone call the
household can make **this week**, while the phones work, and write down.

**And the summary sentence for the whole chapter, which is the one to teach a second adult:** *the pharmacy being
shut does not change what a medicine is, and the shortage does not make a dangerous answer safe.*

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version
1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a
source does not cover an item — per-drug dosing, OTC shelf lives, the oral rehydration ratio (deliberately absent,
§6.3), how long a specific medicine tolerates heat, anti-diarrhoeal selection rules, and the evidence grade of
several common remedies — this document says so rather than supplying a number, and sends you to the label, the
pharmacist, the prescriber, or the manufacturer.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
