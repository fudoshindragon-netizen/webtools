# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 12 — ASSESSMENTS AND ANSWER KEYS

**Version 1.0 · Errata date 2026-11-02 · Written for households in the United States**

This is the test bank. Every module in doc 09 has ten questions here, a practical rubric, and a
full answer key with the reason each answer is the answer. The questions are written to be
answerable **from that module's own chapters and nothing else** — if a question cannot be answered
from the chapter it points at, the question is wrong and should be reported as errata, not guessed
at.

The purpose is not to grade anybody. It is to find the one thing in each module that did not stick
while the finding is still cheap.

---

## 12.1 How to use this

**The knowledge check is not the module.** A household can score 10/10 and still be at NOT YET on
the module, because the module closes on a demonstration. The check exists to catch a household
that has done the drill while believing something dangerous about it — which is the failure mode
that hurts people, and the one a practical assessment misses.

**Run it closed book, out loud, with the assessor reading the questions.** An adult reading a
question silently and nodding is not a check. The assessor reads, the adult answers aloud, the
assessor writes down what was said.

**The pass mark is 8 out of 10 on every module except two.** A wrong answer on any question is a
re-teach of that item out loud, with the chapter open, before the module is signed off — including
at 10/10, because a lucky answer and a known answer look the same on paper.

**`MED-5` and `FUE-1` are 10 out of 10, no partial pass.** Nine is a fail. There is no exemption,
no open book, no "they wrote it themselves", and no household member who sits it out. Both are
ten-item checks where every item is a way to seriously harm somebody, and a household that knows
nine of the ten has not learned the list — it has learned most of the list, which is the same as
not having it. Retake after a re-teach; the retake is a different ordering of the same ten items.

**Two retakes then a re-teach.** A household that fails twice is not stupid; it is telling you the
module was taught badly, or on a bad day, or to somebody who was tired. Re-teach the module, wait a
week, and run it again.

**Life-critical items are marked ⚑** in the answer keys. A wrong answer on a ⚑ item is a re-teach
even if the score passes, because those are the items where being wrong is not a knowledge gap but
a hazard.

**Ratings, not percentages.** The check produces a score; the module produces a rating —
**NOT YET / DEMONSTRATED / CAN TEACH IT**. No percentage from this document appears on the
certificate in doc 13, because a percentage implies a standard of accuracy this program cannot
claim.

**Who assesses.** An adult who did not perform the task, or a neighbour or CERT contact in a
single-adult household. Self-assessment is permitted where nobody else is available, is marked
*self-assessed*, and is worth less.

---

## 12.2 Pass marks at a glance

| Module | Questions | Pass mark | Rating this check supports |
|---|---|---|---|
| All thirty-seven modules not listed below | 10 | 8/10 | DEMONSTRATED or CAN TEACH IT, per doc 09 |
| **`MED-5` — the "do not do this" list** | 10 | **10/10, no partial pass** | 10/10 is the rating; there is no CAN TEACH IT tier |
| **`FUE-1` — fuel safety** | 10 | **10/10, no partial pass** | 10/10 is the rating, plus the storage walk |

**A pass on the check never substitutes for the practical.** Both are required, in that order: do
the drill, take the check within the same week.

---

## 12.3 Practical rubrics

One line per module: what the assessor watches, and what fails it outright. The full criteria are
in each module's own box in doc 09; this table is the field version.

| Module | The assessor watches | Automatic fail |
|---|---|---|
| `BAS-1` | The roster being filled from the household's own knowledge, then corrected in the slowest member's hearing | The slowest member unnamed, or the page written without them present |
| `BAS-2` | Every label photographed, every device found and its power source written down | A device in the house that is not on the list |
| `BAS-3` | The ICE card being filled by hand, and two adults naming where the cash is | The card existing only on a phone |
| `BAS-4` | Every adult restating the three branches without the card | One adult who cannot restate them |
| `WTR-1` | Containers physically inspected, dates read off the bottles | A count that was estimated rather than counted |
| `WTR-2` | The rolling boil, timed, outdoors or on a ventilated balcony | Boiling indoors, or a simmer counted as a boil |
| `WTR-3` | Both batches dosed from the printed table, then the *other* concentration handed over | 8.25% bleach dosed at the 6% rate |
| `WTR-4` | The walkthrough, the labelling at the source, the unit valve demonstrated | Touching the building main or sprinkler riser |
| `FOD-1` | The arithmetic done in front of the assessor, then the pantry counted | A flat 2,000 kcal used for everybody |
| `FOD-2` | Where the stove is, and the meal produced for every member | Any indoor cooking |
| `FOD-3` | The five figures from memory, then the discard decision on a real item | Trusting smell or appearance over the thermometer |
| `SAN-1` | The kit laid out, the 20-second wash, the dated answer on the card | A blank card with no authority named |
| `SAN-2` | Seven days of log, and both stations still standing at the end | Stations packed away before the week ends |
| `CO-1` | Each alarm tested out loud, the log dated | No alarm audible from the sleeping area |
| `MED-1` | The kit dated, locked, and the list in two places | Loose medicine within a child's reach |
| `MED-2` | The written hour 4 / 24 / 72 answers | No answer to "what happens at hour 24" |
| `MED-3` | One sachet mixed to the packet's stated volume | Any improvised ratio, or any guess at volume |
| `MED-4` | The wound washed, the infection signs recited, the log owned by a name | The escalation sentence paraphrased into "keep an eye on it" |
| `MED-5` | A closed-book written check, reasons given aloud | 9/10, or any reason that restates the statement |
| `MED-6` | The four recognition sets, the dark search, the dark walk with the person at risk | Hesitation on anaphylaxis or stroke treated as a pass |
| `WTH-1` | The room chosen and the rejected room explained, drafts physically stopped | A room chosen without the CO alarm in it |
| `WTH-2` | The three sentences, the fan rule both ways, the written plan | The "no fluids" rule got wrong, or a fan plan above 90 °F |
| `FIR-1` | The extinguisher label read aloud, PASS, the two exits walked | Sweeping a live fire, or any plan to re-enter |
| `FUE-1` | The room-by-room storage walk, then the closed-book check | 9/10, or any fuel in a stairwell or common area |
| `CLO-1` | Five minutes, lights out, timer running, slowest member first | The time missed, treated as a partial pass |
| `DRILL-1` | The pre-drill screen signed, the protocol read aloud, the abort rule stated | Any exclusion overridden to run the drill anyway |
| `SHE-1` | The two-layer closure, the seal-a-room step timed, the abandon triggers | Sealing a room with no operable window left |
| `SHE-2` | The building audit on foot, the carrying plan, the landlord record | "We'd manage" in place of a named carrier |
| `SEC-1` | Both walks on different days, the score sheet, the named person at the police department | A sheet filled in from the armchair in one sitting |
| `SEC-2` | Four role-plays, through a closed door | An adult reading the protocol aloud instead of stating it |
| `SEC-3` | One conversation that produced something the household did not know | Three names with no conversation behind them |
| `SEC-4` | The dated written record from three authorities, read aloud to every adult | "I looked it up once" |
| `MOV-1` | Every bag lifted and carried to the door by its named carrier | A bag its carrier cannot lift, or "whoever is nearest" |
| `MOV-2` | The route walked slowly and narrated, then the plan page | A plan with no named lifters |
| `MOV-3` | Two daytime runs and one night run, the **last** person timed | Anyone hurried, or a fast time with a distressed slow mover |
| `MOV-4` | The separation drill, the contact called from paper | A tier-two destination nobody has asked |
| `INT-1` | The whole household for 72 hours, observed not coached | One indoor flame, or one touch of the building main |
| `INT-2` | Every failure named, each with a fix or a written acceptance | A debrief that lists no failures |
| `MOR-1` | The plan written at the table, the elder's job agreed with them | An elder given a job without being asked |

---

## 12.4 The knowledge checks

Ten questions per module. Read aloud, closed book, answers written down as spoken.

### `BAS-1` — Household roster and vulnerability map
1. Whose speed sets the household's plan?
2. Which four limits must be recorded for each person?
3. Who is on the roster besides the people who live there?
4. Why is the slowest member named, not described as "the elder"?
5. What must the roster say about being left alone?
6. Why does hearing belong on an evacuation roster?
7. What do you do when you are unsure of someone's limit?
8. What is the household's real speed, in one sentence?
9. What are children over eight told in this module?
10. Which module does the roster feed directly?

### `BAS-2` — Medical and device inventory
1. What four facts are recorded for every medication?
2. Name the six devices this module checks for.
3. In an outage, which is the emergency — the pills or the device?
4. Where does the list have to exist?
5. What does one of those devices in the house do to `DRILL-1`?
6. Why record a refill date rather than just a medicine name?
7. What do you write if a device is not in the house?
8. Who must reach CAN TEACH IT on this module?
9. What do children over eight know about the box and the list?
10. Which two modules must be closed before this inventory can be trusted?

### `BAS-3` — Documents, contact card, cash
1. Name the three things this module produces.
2. Why is the ICE card paper?
3. What is on every member's card?
4. Where are document copies stored?
5. Who must know where the cash is?
6. What is the cash actually for?
7. Who carries a card?
8. What does a child do with theirs?
9. Which section defines the out-of-area contact's job?
10. What must that contact be able to say back to you?

### `BAS-4` — Decision card and household meeting
1. Name the three branches.
2. Which branch is the default?
3. How many triggers per branch, minimum?
4. Who signs the card, and in what?
5. What must every adult do without reading the card?
6. Which two roles must be named?
7. Which branch covers a public shelter, and what is 2-1-1 for?
8. What is the shelter rule about pets?
9. How is the household rated on this module?
10. Why is the card signed before anything happens?

### `WTR-1` — Store a 14-day buffer
1. How much Grade A water per person per day?
2. How many days does the buffer cover?
3. What is Grade A for, and what is Grade B for?
4. What is written on every container?
5. How often is non-commercially-bottled water replaced?
6. What must the water card state, in what form?
7. How is the count verified?
8. Which water never touches a toilet?
9. Which trigger goes on the card?
10. What else must be in the calendar?

### `WTR-2` — Boil water safely
1. How long is a rolling boil at ordinary altitude?
2. How long above 5,000 feet?
3. What does a rolling boil look like?
4. What happens to cloudy water before it is boiled?
5. How is boiled water cooled and stored?
6. How is the flat taste corrected?
7. Name two things boiling does not remove.
8. Where may you boil?
9. Which chapter governs where the pot may be?
10. What overrides every time printed in doc 02?

### `WTR-3` — Disinfect water with bleach
1. How many drops per gallon at 6%?
2. How many drops per gallon at 8.25%?
3. What happens if 8.25% is dosed at the 6% rate?
4. What is the contact time?
5. What do you do if there is no chlorine smell after 30 minutes?
6. What if there is still no smell after the re-dose?
7. What do you do differently for cloudy or very cold water?
8. What is the container-sanitising dose, and is it drunk?
9. Name three bleaches that are disqualified outright.
10. What do you do with a bottle that states no percentage?

### `WTR-4` — Find water inside the building
1. Name the two sources inside the building.
2. Which part of a toilet is never a source?
3. What disqualifies a toilet tank?
4. Name two never-sources.
5. What must never be touched?
6. How is the harvest volume recorded?
7. Where are sources labelled?
8. What is recorded about the water heater?
9. What is confirmed with the landlord?
10. What must every adult be able to teach?

### `FOD-1` — Build the pantry
1. What planning figure per person per day?
2. What is that per adult over 90 days?
3. How many days of full calories does Layer 2 hold?
4. What must Layer 1 need?
5. How is Layer 2 counted?
6. Which food is the weak link on shelf life?
7. What date goes on every oil container, and what follows it?
8. What does the pantry card state?
9. Where does the card go?
10. Why not use a flat 2,000 for everyone?

### `FOD-2` — Cook with no power
1. Where may you cook with no mains power?
2. Name three places it is never done.
3. What is the generator rule?
4. What is an automatic fail of this module?
5. What must be installed and tested before the stove comes out?
6. Which method minimises fuel?
7. What is recited for the extinguisher?
8. What must never happen while the stove is lit?
9. Whose portion must be correct?
10. What is shown rather than stated?

### `FOD-3` — Keep food safe with no fridge
1. How long does a closed refrigerator hold?
2. A full freezer, door closed?
3. A half-full freezer, door closed?
4. At what temperature is refrigerated food discarded?
5. When do the coolers come out?
6. What is the bacterial danger range?
7. What do you cook first?
8. When may food be refrozen without a thermometer?
9. What may you not rely on?
10. How many thermometers, and where?

### `SAN-1` — The emergency toilet
1. Besides the kit, what three things must exist?
2. What alcohol strength must the sanitizer be?
3. How long is the handwash?
4. Why does this program print no disposal method?
5. Who does the household ask about disposal?
6. What makes the card a fail?
7. What must the trigger name?
8. Which branches does the trigger fire?
9. What must be decided about the station?
10. Where is the station sited?

### `SAN-2` — Handwash and dish station
1. How many consecutive days?
2. What is logged daily?
3. What is the last step of the dish rule?
4. What does the state of the stations at week's end prove?
5. Name one limit of hand sanitizer.
6. What number does this module hand to doc 02?
7. Why a week rather than an afternoon?
8. What happens on a day the station was not maintained?
9. Who must use the station unassisted, and for how long?
10. Which sections give the standard?

### `CO-1` — Install and test CO alarms
1. Where must an alarm be audible?
2. What does the "whole household has the flu" rule say?
3. What is the generator distance rule?
4. Name three places nothing that burns may run.
5. What is written on the log for each unit?
6. Which three modules depend on this one?
7. How is the alarm tested?
8. Why does this module come before any flame in the program?
9. What does a child over eight know about the alarm?
10. How many alarms, and where?

### `MED-1` — Build the medicine kit
1. What is written for every item the kit is missing?
2. What goes on every box?
3. Where is the kit kept?
4. What makes the kit usable by somebody else?
5. Where is the list copied to?
6. What does this program print about doses?
7. Who reaches CAN TEACH IT on the rotation rule?
8. Which section holds the sourced categories?
9. What must be visible about rotation?
10. What must children over eight know about the box?

### `MED-2` — Medication and device continuity
1. Name the three conversations.
2. Which three hours must be answered?
3. What is this module really about?
4. Who checks the refrigeration plan?
5. What number goes on the ICE card?
6. What may never be done to a prescribed dose?
7. Which provider answer gets written down?
8. What single missing answer fails the module?
9. Which section carries the device rules?
10. Who reaches CAN TEACH IT on the whole page?

### `MED-3` — Rehydration by sachet
1. What is the only rehydration product this program uses?
2. Is there a home recipe?
3. How is a sachet mixed?
4. Who is not a sachet case at all?
5. Name three go-now signs.
6. What does running out of sachets mean?
7. What is the plan, in one sentence?
8. What is the difference between prevention and treatment here?
9. What do children over eight never do?
10. Which section holds the rule?

### `MED-4` — Wound care and infection signs
1. What is a wound washed with?
2. Name two local infection signs.
3. Name two systemic "go now" signs.
4. Which sign in an elder is most often dismissed?
5. What does "immediate" mean in an outage?
6. Name two wounds that are not "just a cut".
7. Why is a wound on a hand or foot different?
8. What must exist for the wound after day one?
9. What do you name rather than invent?
10. Who owns the daily check?

### `MED-5` — The "do not do this" list
1. Why is drinking bleach never treatment?
2. What does colloidal silver do, and is it an antibiotic?
3. Why is a fish-tank antibiotic dangerous?
4. Why are unverified "natural antibiotics" a hazard?
5. When is potassium iodide taken?
6. What is the rule about stopping or halving a prescribed medicine?
7. What is the instruction about infant formula?
8. Why is pool shock not a water treatment?
9. Why is heating-system water never drunk?
10. What does boiling do to chemically contaminated water?

### `MED-6` — First aid that matters here
1. While you press on a bleeding wound, what else happens?
2. What single question decides whether someone is choking?
3. What do you do for a person who is coughing?
4. What does this program print about choking technique?
5. What does the infant method require?
6. What is the rule for anaphylaxis?
7. Why is an antihistamine not the treatment?
8. What is the four-part stroke screen?
9. Which fact decides whether a stroke can be treated?
10. What is the leading injury cause over 65, and what is the drill?

### `WTH-1` — Warmth without utilities
1. How many rooms do you heat?
2. Name three things that must be in the warm room for 72 hours.
3. How are drafts dealt with?
4. What is the never-indoors list for?
5. Where must the CO alarm be audible?
6. What must be explained about the room you rejected?
7. What does the household state about anything that burns?
8. What must be verified by walking?
9. What do children over eight know about the stove and generator?
10. Which module is the prerequisite?

### `WTH-2` — Heat illness and the heat-wave plan
1. What is the core-temperature threshold?
2. What does that threshold mean in practice?
3. What is the rule about fluids in suspected heat stroke?
4. What does hot-and-dry versus hot-and-sweaty tell you?
5. At what indoor temperature does a fan stop helping?
6. What does a fan do above that temperature?
7. What do you do instead of blowing air?
8. What must the written plan name?
9. What is the medication rule about?
10. Why is an elder's "I'm fine" not an assessment?

### `FIR-1` — Fire and CO
1. What is read aloud from the extinguisher?
2. What does PASS stand for, in order?
3. Where is the sweep demonstrated?
4. Name three of the never-list items.
5. What is the rule about re-entering a building?
6. What is the rule about water on a grease fire?
7. What two exits must be walked with every member?
8. What does this program refuse to print about fire?
9. Who does the household ask instead, and when?
10. What do children over eight know?

### `FUE-1` — Fuel safety
1. How much gasoline is stored in the dwelling, by default?
2. Where may fuel never be stored in a building?
3. What is the rule about containers?
4. What is the rule about propane cylinders indoors?
5. What is the rule about an unvented kerosene heater?
6. What must fuel never be stored near?
7. What is the generator distance and location rule?
8. What does this module refuse to print, and why?
9. What does the storage walk produce?
10. What score is required, and what happens at nine?

### `CLO-1` — Dress the slowest member for 0 °C
1. What is the standard, in one line?
2. How long do you have?
3. What does "in the dark" test?
4. What does "from what is in the house" rule out?
5. What are the three layering jobs?
6. What are the three layering rules?
7. Which fibre fails when damp, and why does it matter?
8. What must be by every bed?
9. How is clothing stored for each person?
10. What happens if the five minutes is missed?

### `DRILL-1` — The 72-hour no-utilities drill
1. Which two tiers must be closed before it runs?
2. Name three exclusions from the pre-drill screen.
3. What is the rule about oxygen and flame?
4. What must be tested on the day?
5. Which breaker may be used, and which may never be?
6. What is the rule about the water heater?
7. What must be done about the fridge before the power goes?
8. What replaces candles?
9. What is the abort rule, and who is named?
10. What happens if an exclusion applies?

### `SHE-1` — Shelter and building reality
1. How many layers close an opening?
2. What must remain operable in a sealed room?
3. What must be stated before the seal-a-room step?
4. Name the three abandon triggers.
5. What is the shelter rule about pets?
6. What must the pet answer name?
7. What does this program refuse to print about board-up?
8. Who does the household ask instead?
9. What does the building do to your heat plan?
10. What do children over eight know about the sealed room?

### `SHE-2` — Above the sixth floor
1. Above roughly how many floors do the taps die with the power?
2. Why do they die?
3. How long is the tap a source at best?
4. What happens to waste in a high-rise?
5. What happens to the slowest member's mobility?
6. What arrives before the neighbours do?
7. What must the audit record about the generator?
8. What carrying plan must exist?
9. What must the landlord conversation record?
10. What do children over eight know?

### `SEC-1` — The security assessment
1. How many lines are on the instrument?
2. What is the scoring scale?
3. What is the total out of?
4. Is there a pass mark?
5. How many walks, and when?
6. Why does the dark walk matter most?
7. Who must be spoken to at the police department?
8. What is recorded about that call?
9. What is submitted if the household rents?
10. What fails this module outright?

### `SEC-2` — The door protocol
1. How many lines does the child's script have?
2. What is line one?
3. What is line three, and what follows it?
4. Why does the script not say the child is alone?
5. What does the child never do in the script?
6. What is the elder's governing principle?
7. What is the elder's line two, in substance?
8. What is the household's standing rule about the utility company?
9. Where is the large-print card kept?
10. What are the adult's four parts?

### `SEC-3` — Mutual aid and CERT
1. How many neighbours, minimum?
2. What three things are recorded beside each name?
3. What evidence proves a conversation happened?
4. What is the third name's source in a detached house?
5. What course is named, and what is its local equivalent?
6. What is written if no local class exists?
7. What does CAN TEACH IT mean in this module?
8. Why is mutual aid the highest-return security action?
9. What is mutual aid not?
10. Which section of doc 05 tells you what a neighbour with medical training is useful for?

### `SEC-4` — Legal reality
1. What does this program print about weapons?
2. Why does the law vary, at the level this book can state it?
3. What comes before any discussion of tools?
4. Name the three authorities.
5. What is written for each answer?
6. What makes the record valid?
7. What happens to the record annually?
8. What is signed in the minutes?
9. What is the pass level, and why is there no CAN TEACH IT?
10. What is a child told about weapons by this program?

### `MOV-1` — Per-person bags
1. How many columns on the worksheet?
2. What proves a bag is real?
3. What is in the elder's bag that is not optional?
4. What is in the child's bag, and what is kept out of it?
5. What fails a bag outright?
6. What word in the carrier column fails the worksheet?
7. Who is not required to carry their own bag?
8. Who can pack any bag in the house?
9. What does a child over eight demonstrate?
10. Which federal baseline is used, and what does it not do?

### `MOV-2` — The mobility plan
1. How long is the plan?
2. How many lifters, and do they share a job?
3. What must the measured time carry?
4. What is the doubled time for?
5. What must the script be?
6. What must the stop rule be?
7. What happens if the household has no equipment?
8. What does this program refuse to print about equipment?
9. What sentence fails the module?
10. How many adults must reach CAN TEACH IT, and why?

### `MOV-3` — The timed assisted evacuation drill
1. How many runs, and in what light?
2. Whose time is recorded?
3. What is written about the time besides the number?
4. What happens between runs?
5. What invalidates a run?
6. What does a fast time with a distressed slow mover mean?
7. What rule set governs the drill before the clock starts?
8. What happens if a rule in §8.4.1 is broken?
9. What do children over eight do in the drill?
10. Why is the drill run at the slowest member's pace?

### `MOV-4` — Rendezvous and comms
1. How many rally points?
2. Where is rally point one, and where is it not?
3. Why are rally points named as places?
4. What is the rule that makes them work?
5. What must the out-of-area contact be able to say back?
6. Why text before voice?
7. Name the four ways phones fail.
8. What is the one comms method that never fails?
9. What are the three destination tiers?
10. What must be true of the tier-two destination?

### `INT-1` — The full 72-hour simulation
1. What is the difference between `DRILL-1` and `INT-1`?
2. What does the assessor do during it?
3. Which protocol governs the whole event?
4. Which water may not be used for the toilet?
5. What must be logged at hour 24?
6. What must be consulted at least once, and logged?
7. What single act fails the module?
8. How many contact hours, inside how many elapsed?
9. What does passing `INT-1` unlock?
10. What do children over eight do?

### `INT-2` — The debrief
1. What happens to every failure?
2. What two things may a failure carry?
3. What must the acceptance name?
4. What is re-scored, and against what?
5. How many changes are committed to?
6. Who signs the page?
7. Why is an unlogged failure a problem?
8. Which log is on the table?
9. What closes Stage 3?
10. What happens to a failure nobody will fix?

### `MOR-1` — Morale and mental health
1. What three people does the plan cover?
2. What must the children's activity store need?
3. How is the elder's job decided?
4. What does the adult rest rule name?
5. What must every adult have outside the household?
6. What signs are written in the household's own words?
7. What does the plan say this program is not?
8. What is the answer for a person in crisis?
9. What is a child told about their job?
10. Which chapter is missing, and what does that mean for this module?

---

## 12.5 The answer keys

⚑ marks a life-critical item: a wrong answer here is a re-teach even when the score passes.

### `BAS-1`
1. **The slowest member.** Doc 08 §8.1 — the household moves at their worst-day pace, so that person is the clock.
2. **Cannot walk far, cannot lift, cannot hear, cannot be left alone.** These four change the plan; age does not.
3. **Every person who visits daily.** A carer or a grandchild who is there every morning is part of the evacuation.
4. **Because a plan must name people.** "The elder" cannot be carried; a named person with a named limit can.
5. **Which member cannot be left alone, and for how long.** That single line decides whether the household can ever split up.
6. **They may not hear the alarm or a caller.** A hearing limit changes the door protocol and the night plan.
7. **Walk the flat with them and correct the page in their hearing.** A limit written about someone rather than with them is usually wrong.
8. **The slowest member's speed on their worst day.** Not the average day, and not the fastest adult's.
9. **Who needs help first, and whom to fetch.** Capability, not fear.
10. **`MOV-2`, the mobility plan** — the roster is the input to every lifting decision in doc 08.

### `BAS-2`
1. **Name, dose, prescriber, refill date.** Four facts, because a stranger may be reading it.
2. **Oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair, insulin.** Insulin counts because it is refrigerated.
3. **The device.** A missed pill is a bad day; a dead concentrator is an emergency in hours.
4. **In the kit and in the go-bag**, photographed and copied. Two places, because one gets left behind.
5. **It excludes the household from `DRILL-1`.** The pre-drill screen in §9.4 is not negotiable.
6. **Because supply, not knowledge, is what runs out.** The refill date tells you how many days you actually have.
7. **That it is absent.** A record of absence is how you prove the screen was done.
8. **The designated carer.** One person holds the whole page.
9. **The box is not theirs, and they never move it.** The list's location is fine to know; the medicine is not.
10. **`BAS-2` and `MED-2`.** The inventory and the continuity plan are the same fact written twice.

### `BAS-3`
1. **Document copies, an ICE card per person, and cash.** Three separate jobs.
2. **Because a dead battery has no contacts in it.** Paper is the only comms method that never fails.
3. **The out-of-area contact, the two rally points, and any medical need.** Enough for a stranger to help.
4. **Two separate places, one off-site or digital.** One copy is a copy you lose with the flat.
5. **Two adults.** One adult knowing is one adult being ill that day.
6. **The hours when cards do not work.** A card reader needs power and a network.
7. **Every member, including each child over eight.** A card in an adult's wallet is not the child's card.
8. **Shows it, and reads the contact's name aloud.** That is the whole test.
9. **Doc 08 §8.5.2.** One person, outside the area, with one job.
10. **The household's names and the two rally points.** If they cannot, they are not briefed.

### `BAS-4`
1. **STAY AND HARDEN, GO SOMEWHERE STAFFED, SLOW EXIT.** Doc 01 §1.5.
2. **STAY AND HARDEN.** It is the right answer for most urban households in most outages.
3. **Two per branch.** One trigger is a mood; two is a decision.
4. **Every adult, in ink, dated.** Pencil is a decision not made.
5. **Restate the three branches.** The household rating is the lowest individual rating, and the adult who cannot restate is the one who decides.
6. **A decider and an alternate decider.** The decider may be the person who is not there.
7. **Branch 2; 2-1-1 finds shelters and cooling or heating centres.** Shelters take **service animals only**.
8. **Service animals only.** Both pet answers must be written down, naming real people or places.
9. **As the lowest individual rating in the household.** No averaging.
10. **So the call is not made in a panic.** A pre-signed card is a decision made while everyone is calm.

### `WTR-1`
1. **¾ gallon (about 3 litres).** Ready.gov's drinking figure, and it doubles in heat.
2. **Fourteen days.** It is a buffer, not the 90-day plan; doc 02 §2.1 says why 90 days does not fit in an apartment.
3. **Grade A is drinking and cooking; Grade B is flushing, hygiene and laundry.** Grade A never touches a toilet.
4. **The fill date.** Written on the container, not in a notebook that gets moved.
5. **Every six months.** Ready.gov's rule for non-commercially-bottled water.
6. **The real days of supply, as a number.** "About two weeks" is a slogan; "11.5 days" is a plan.
7. **By physically inspecting the containers.** Not by asking the household how much they think they have.
8. **Grade A.** One flush can spend a day of somebody's drinking water.
9. **The branch-2 water trigger**, in the household's own words.
10. **A rotation date within six months.** Water that is never rotated is water you are afraid to drink.

### `WTR-2`
1. **One full minute at a rolling boil.** Ready.gov and EPA.
2. **Three minutes.** EPA says above 5,000 ft, CDC says 6,500; the program uses the conservative figure.
3. **Bubbles breaking the surface and not stopping when you stir.** Not a simmer, not steam.
4. **Settle and filter it** through cloth, paper towel or a coffee filter — sediment protects germs from the heat.
5. **Cooled naturally, covered; stored covered and dated.** Open cooled water is re-contaminated water.
6. **A pinch of salt per quart or litre, or pour between two containers.** Taste only, never scaled up.
7. **Heavy metals, salts and most chemicals** — and boiling concentrates some of them.
8. **Outdoors or on a ventilated balcony only.** Never indoors, a garage, or a flooded basement.
9. **Doc 04.** Its CO and fire rules govern where the pot may be, and they are not optional.
10. **A local boil-water advisory.** It knows something about your system that the book does not.

### `WTR-3`
1. **8 drops.** EPA's 6% column.
2. **6 drops.** The columns are not interchangeable.
3. **An overdose** — about a third too much chlorine. Automatic fail.
4. **30 minutes, timed.** Not estimated.
5. **Repeat the dose and wait 15 minutes.** Stir again and smell again.
6. **Discard the water and find another source.**
7. **Double the dose.** Cloudy or very cold water needs it.
8. **One teaspoon per quart, for containers, poured out — never drunk.** A different dose for a different job.
9. **Pool chlorine or calcium hypochlorite; scented; splashless or color-safe.** Also any bottle with no stated percentage.
10. **Do not use it for water.** If the label states no percentage, the bottle is disqualified.

### `WTR-4`
1. **The water heater and the toilet tanks.** Both with caveats.
2. **The bowl.** Tank only, always.
3. **A chemical tablet.** Any treated tank is struck off and labelled.
4. **Radiators and heating boilers.** Heating-system water carries treatment chemicals and corrosion products.
5. **The building main and the sprinkler riser.** Neither is ever a household valve.
6. **As a one-time draw on the water card**, separate from the stored buffer.
7. **Physically at the source**, with a sticker or card — not only on a list.
8. **Its fuel type, and whether it serves this unit or the whole building.**
9. **Which valve is the unit valve.** Then notify the landlord or super.
10. **The never-list, at CAN TEACH IT.** It is the part that prevents harm and must outlive the person who learned it.

### `FOD-1`
1. **2,000 kcal per person per day** — the federal planning figure, not a universal requirement.
2. **180,000 kcal.** 2,000 × 90.
3. **Thirty days.** Layer 2 is 30 days of full calories; the gap to 90 is stated, not hidden.
4. **No cooking, no water and no refrigeration.** Eaten straight from the packet.
5. **By counting packages and reading labels.** Estimated pantries are always wrong.
6. **Oil.** It is the weak link, not grain.
7. **The purchase date; the six-month rotation goes in the calendar.** Rancid oil is a nutrition failure.
8. **Total calories, days of supply, the gap to 90, and the trigger** in the household's own words.
9. **On the pantry door.** Where it is read, not filed.
10. **Children, elders and pregnancy differ, and a flat rule starves some of them.** Doc 03 §3.3 shows three households.

### `FOD-2`
1. **Outdoors, or on a ventilated balcony.**
2. **Indoors, a garage, a flooded basement.** Any indoor cooking is an automatic fail of the module.
3. **Twenty feet away, outdoors.** Never in a garage, even with the doors open.
4. **Any indoor cooking.** Not a deduction — a fail.
5. **CO alarms.** `CO-1` is a prerequisite for every flame in this program.
6. **One pot, one boil.** Fuel is a budget.
7. **PASS** — pull, aim, squeeze, sweep.
8. **Being left unattended.** Shown, not stated.
9. **Any member on a special diet.** Their portion is not an afterthought.
10. **Extinguishing, and the stove never being left.** The assessor watches, not listens.

### `FOD-3`
1. **About 4 hours**, door kept closed.
2. **About 48 hours**, door closed.
3. **About 24 hours**, door closed.
4. **Above 40 °F.** That is the discard line, not a suggestion.
5. **If the power will be out more than 4 hours.**
6. **40 °F to 140 °F.** Bacteria grow fastest in that band.
7. **The thawing food.** A freezer is a food supply being spent, not a loss to be mourned.
8. **If it still contains ice crystals or is 40 °F or below.**
9. **Appearance or odour.** FDA is explicit: the thermometer decides.
10. **Two: one in the fridge, one in the freezer**, both working before the event.

### `SAN-1`
1. **A named authority, a dated answer, and a written trigger.**
2. **60% alcohol or more.**
3. **20 seconds.** Soap and safe water, and the practice matters more than the volume.
4. **Because disposal is jurisdictional.** A printed rule would be wrong somewhere and dangerous there.
5. **The local health department.** Then write the answer and the date on the card.
6. **No date, or no named authority.** A blank card is a fail.
7. **An observable condition.** Not "if it gets bad".
8. **Branch 2 or branch 3.** It is an explicit trigger in doc 01 §1.9.3.
9. **Where the runoff goes.** A station with no runoff destination floods the room it is in.
10. **Where the hands are.** Convenience is the compliance mechanism.

### `SAN-2`
1. **Seven consecutive days.**
2. **Key-time handwashes (ticked), measured water use, and any day the station was not maintained — with the reason.**
3. **Let it dry completely before reuse.** That is the step people skip.
4. **That the behaviour survived a week** — they are still standing and in use, not packed away.
5. **It is not a full substitute for soap and water, does not remove chemicals, and is not for visibly dirty hands.**
6. **The household's measured hygiene water use per day** — the number doc 02's buffer has to cover.
7. **Because behaviour is what holds over 90 days.** An afternoon proves the equipment; a week proves the habit.
8. **It is logged with the reason.** A gap you wrote down is a gap you can fix.
9. **Children over eight, for the full week.** That is the point of a week.
10. **Doc 04 §4.6.2–§4.6.4.**

### `CO-1`
1. **From the sleeping area.** An alarm you cannot hear while asleep is decoration.
2. **Headache, nausea and drowsiness in more than one person at once means get out and call.** That is what CO looks like.
3. **Twenty feet, outdoors.**
4. **Indoors, a garage, a flooded basement.** Nothing that burns runs in any of them.
5. **The expiry date**, on the log, with the test date.
6. **`FOD-2`, `WTH-1` and `DRILL-1`.** Every flame in the program is behind this module.
7. **Pressed, and heard, in front of a second adult.**
8. **Because CO is the harm, and the alarm is the only thing that detects it.** You cannot smell it.
9. **What it sounds like, and that they leave the building and stay out.**
10. **One audible from the sleeping area, and one on each floor the household uses.**

### `MED-1`
1. **The reason it is missing.** A gap with a reason is a decision; a gap without one is an oversight.
2. **The date.** Every box, every time.
3. **Locked, and out of a child's reach.**
4. **The written medication list.** The kit without the list is a box of unlabelled possibility.
5. **The kit and the go-bag**, photographed.
6. **Nothing.** No dose is printed in this program; the label is the authority.
7. **Two adults.** One is a single point of failure.
8. **Doc 06 §6.1.**
9. **The rotation order** — what to use first.
10. **The box is not theirs, and they never open it.**

### `MED-2`
1. **Provider, pharmacy, and the supplier or utility.**
2. **Hour 4, hour 24, hour 72.** The three points at which the plan either works or has already failed.
3. **Power and refrigeration, not just pills.** A fridge is a medical device in this household.
4. **A named checker.** "Someone will check" is nobody.
5. **The supplier's emergency number.**
6. **Stopped or halved.** CDC: do not stop or change medicines without talking to your doctor.
7. **How long the medicine tolerates heat.**
8. **No answer to "what happens at hour 24".**
9. **Doc 06 §6.2.**
10. **The designated carer.**

### `MED-3`
1. **Pharmacy rehydration sachets.** Nothing else.
2. **No. There is no home ratio in this program and there never will be.** WHO classifies ORS as a medicine with a narrow margin.
3. **Exactly to the packet's stated volume, with named clean water.** Not estimated, not "about a glass".
4. **An infant under six months.** That is a clinician's call, always.
5. **A lethargic or floppy child; a child vomiting everything back; bloody diarrhoea.** Also no urine, sunken eyes, a rapid weak pulse.
6. **Go to care.** Running out means going, not improvising.
7. **Sachets plus a route to care** — not sachets instead of care.
8. **A sachet prevents dehydration in an ordinary illness; a dehydrated person needs a facility.**
9. **Mix a sachet, or give a drink to someone confused or very sleepy.**
10. **Doc 06 §6.3.**

### `MED-4`
1. **Soap and clean water**, with the water source named.
2. **Spreading redness, swelling, warmth, worsening pain, pus, a red streak, a bad smell.** Any two.
3. **Fever, shivering, fast heartbeat, vomiting, new confusion.** The "go now" set.
4. **New confusion or drowsiness.** It is read as tiredness and it is often infection.
5. **Today.** Not "when things settle".
6. **A bite; a puncture through a shoe; a wound with dirt driven into it; a wound in a diabetic or anticoagulated person; a wound from flood water; a wound over a joint, hand, foot or face.**
7. **Because function and appearance both matter, and both are worse when managed alone.**
8. **A daily wound check with a written log.**
9. **The four things not printed here — and who to ask instead.** Never invent them.
10. **A named person.** Owned, not shared.

### `MED-5` ⚑ — 10/10, no partial pass
1. **Bleach is a corrosive poison.** It is a measured dose for water with a contact time; neither EPA nor CDC countenances drinking it.
2. **Argyria — usually permanent blue-grey skin — and it is not an antibiotic.** NCCIH found no meaningful improvement.
3. **No quality control, wrong drug, wrong dose, resistance and poisoning, and no way to tell which you bought.** This program contains no antibiotic guidance and never will.
4. **Unknown concentration, organ harm, interactions with prescriptions, and delay of real treatment.**
5. **Only when public health or emergency officials or a clinician instruct it.** It protects only the thyroid and only against radioactive iodine.
6. **Never stop or change a prescribed medicine without talking to your doctor.** Halving a dose to stretch it is the most lethal arithmetic in the book.
7. **Use ready-to-feed; if you must mix, use bottled or boiled water as a last resort.** Never dilute to stretch it.
8. **Uncontrolled concentration, caustic, and not authorised for drinking water.** EPA specifies household bleach only.
9. **CDC: never use heating-system water for drinking, cooking or hygiene.** It carries treatment chemicals and corrosion products.
10. **Nothing — it cannot make it safe, and it concentrates some contaminants.** A fuel smell means a different source.

### `MED-6`
1. **Someone calls 911 and brings the kit** — say the words aloud to a second person.
2. **Is air moving?** Not "are they coughing".
3. **Do not intervene physically.** Encourage the cough and stay with them; thrusts can complete a partial obstruction.
4. **No counts, no hand placement, no force.** Those are taught with a manikin and someone watching your hands.
5. **A course.** The infant method is different in position, hand and force, and nothing in this program covers it.
6. **Auto-injector at the first sign of airway or breathing involvement, call 911, do not wait.**
7. **It settles hives and does nothing for an airway.** Substituting it is the commonest fatal home error.
8. **Face, Arms, Speech, Time.** Note the time and call, and say the word *stroke*.
9. **The time last known well** — the last moment you know they were normal.
10. **Falls, and the drill is the dark walk with the person at risk.** Light the route, clear the floor, fix the rails, footwear by the bed.

### `WTH-1`
1. **One.** One warm room, not one warm house.
2. **Bedding, water, 72 hours of food, light, medication, radio, charger, the waste plan.** Enough to live there three days.
3. **Physically stopped** — towels at the door, blanket over the window, the gap closed. Shown, not described.
4. **To keep everything that burns outside.** Generator, charcoal, gas stove, flameless heater, gas oven, candles.
5. **From the sleeping area.**
6. **Why it was rejected.** The reason is the skill.
7. **Nothing that burns runs indoors.**
8. **That the room is furnished for 72 hours** — by walking it, not listing it.
9. **They stay outside, and the child never touches either.**
10. **`CO-1`.** No tested alarm, no warm room.

### `WTH-2`
1. **103 °F.** With confusion, slurred speech or unconsciousness, that is heat stroke.
2. **Call now — delay can be fatal.**
3. **Do not give fluids to a suspected heat-stroke casualty.**
4. **Nothing.** It does not tell you which it is; both need the same call.
5. **90 °F indoors.** Above that a fan can raise body temperature.
6. **It becomes a convection oven with a cord** — it adds heat faster than evaporation removes it.
7. **Wet the skin** — cool damp cloth on neck, wrists and forehead; feet in a basin.
8. **A cooling centre and a travel method.** A destination with no way to get there is not a plan.
9. **Some medicines change heat risk and fluid balance** — ask the prescriber, and name the at-risk members.
10. **Because you look.** An elder's "I'm fine" is not an assessment.

### `FIR-1`
1. **The label**, and the gauge reading, dated on the log.
2. **Pull, Aim, Squeeze, Sweep.**
3. **In the air.** Never on a live fire as a demonstration.
4. **No candles; nothing that burns indoors; no water on a grease fire; no re-entry into a burning building; no relighting a pilot as a drill.** Any three.
5. **Never, for any reason.** That rule is taught to children in exactly those words.
6. **Never.** Water spreads a grease fire.
7. **The two ways out of the flat**, with the stair route named.
8. **Extinguisher clearances, burn treatment specifics and backfeed procedure.** No figure is invented to fill the gap.
9. **The local fire service's non-emergency line**, on a named day, and the answer goes on the card.
10. **The two ways out, the meeting place outside, and that they never go back inside.**

### `FUE-1` ⚑ — 10/10, no partial pass
1. **None. The default for an apartment is no gasoline in the dwelling.** Not "check the lease" — no.
2. **Stairwells and common areas.** Never, in any building.
3. **Never in a milk jug or an unlabelled container.** An unlabelled container is a poisoning waiting for a child.
4. **No propane cylinder indoors.** Ever.
5. **Only where the verified sources and the lease allow it; otherwise never.** An unvented kerosene heater in a flat that forbids it is a CO and fire risk plus a lease breach.
6. **A water heater or any pilot light.** Vapour travels to the flame.
7. **Twenty feet away, outdoors** — never in a garage, even with the doors open.
8. **No gallon figure, no clearance measurement and no kerosene grade.** NFPA 30/30A are paywalled, and a stale number presented as current is a lie.
9. **A room-by-room written record of what is stored where.**
10. **10/10. Nine is a fail and a re-teach.** No exemptions, no open book.

### `CLO-1`
1. **Dress the slowest member for 0 °C in five minutes, in the dark, from what is in the house.**
2. **Five minutes**, timed, and missing the time is a fail rather than a partial.
3. **That it works without light** — the failure happens at night.
4. **Shopping, borrowing, or fetching coats from the car.**
5. **Base moves moisture, middle traps air, outer stops wind and water.**
6. **Dry beats thick; loose beats tight; head, neck, hands, feet.**
7. **Cotton holds water against you and then chills you.** Wool and synthetics keep working when damp.
8. **Footwear with a back and a sole** — socks and backless slippers are a fall waiting for a wet patch.
9. **Labelled per person, with a reserved dry change.**
10. **It is a fail.** The clock is the point: the real failure happens in the five minutes you would have.

### `DRILL-1`
1. **Tier 0 and Tier 2.** The gate is the reason the drill moved to week 7.
2. **A member on mains-powered equipment; a member on cardiac, seizure or insulin medication not covered by `BAS-2`/`MED-2`; oxygen in the house.** Any one excludes the household.
3. **Oxygen in the house plus any open flame is a fire death.**
4. **The CO alarms** — tested on the day, not the week before.
5. **The unit breaker only. Never the building main, never the sprinkler riser.**
6. **Shut the power or gas before draining, and never drain a shared building system.**
7. **Execute the fridge and freezer plan, and cook the thawing food first.** Unplanned, the drill costs $100–300 of food.
8. **LED lights only.** No candles, ever.
9. **Anyone can call it off, it stops without discussion, and a named outside check-in person is told when it starts and ends.**
10. **The drill does not run, and that is a pass.** A correctly abandoned drill passes; a drill run over an exclusion fails.

### `SHE-1`
1. **Two layers**, with the perimeter sealed.
2. **One window in that room.** A sealed room with no operable window is a trap.
3. **That no board-up or seal-a-room dimension is printed here**, and who to ask instead.
4. **The hazard is inside the building; the room cannot be kept sealed; the household is told to leave.** Stated before the step, not after.
5. **Service animals only.**
6. **Real people or places.** Both answers — what happens to the pet, and where the household goes.
7. **Dimensions and specifications.** Nothing here is a build spec.
8. **The building manager, the local fire service's non-emergency line, or a contractor** — on a named day.
9. **It changes it completely** — a multi-unit block loses heat building-wide, so one warm room is the plan, not one warm flat.
10. **Which room the household seals, and that they go there and stay there when told.**

### `SHE-2`
1. **Roughly six floors.** Above that, city pressure cannot lift the water.
2. **Because the building uses a booster pump to fill a roof tank or pressure system, and the pump stops with the power.**
3. **72 hours at best**, and that is a planning assumption, not a guarantee.
4. **It has no exit**, which becomes a building-wide sanitation event within days.
5. **The lift is gone, so "we'll manage" is not a plan for someone who cannot do stairs.**
6. **Pests.** They follow the waste.
7. **What the generator actually powers** — usually lights and the fire system, not the pump and not the lift.
8. **A written carrying plan naming who carries, and what happens when they cannot.**
9. **The number, the generator's scope, pump responsibility, and the waste question in writing.**
10. **The stair route down and the meeting place outside.**

### `SEC-1`
1. **Twelve.**
2. **0, 1 or 2** — not true, partly true, true and demonstrable to a visitor.
3. **Twenty-four.**
4. **No.** The instrument is not validated, and inventing a pass mark would be fabricated authority.
5. **Two, on different days** — daylight and dark.
6. **Because the attack, if there is one, happens in the dark.** The daylight walk is the easy half.
7. **A named person or unit**, not "the police".
8. **The date, and what they said.**
9. **A dated written list of building faults.**
10. **A score sheet filled in from the armchair in one sitting.**

### `SEC-2`
1. **Three.** A child under stress can hold three, not five.
2. **"I'm not allowed to open the door. I'll get a grown-up."**
3. **"I'm going to get a grown-up now" — and then the child walks away from the door.**
4. **Because "I'll get a grown-up" is true whether four adults are home or none.** It removes the child from the easy-target category without a lie.
5. **Ask the caller anything.** A child who asks is a child in a conversation.
6. **No decision at the door, ever.** Everything is deferred to a phone call.
7. **"Then ring the number on my bill. I don't do business at the door."**
8. **The real utility does not need to come inside today.** You ring the number on your own bill.
9. **Inside the hall cupboard or beside the door — never on the outside of the door.**
10. **Who answers, from where, with whom present, what they say.**

### `SEC-3`
1. **Three**, or one plus a name from the wider block if there is only one neighbour.
2. **A capability, a reciprocal contribution, and a phones-down contact method.**
3. **A name, a date, and something the neighbour told you that you did not know before.**
4. **The wider block, a faith group, a building committee, or the CERT class itself.**
5. **FEMA IS-317.A, or a local CERT class.**
6. **A dated note that no class exists, and when you will re-check.**
7. **You have brought one other household into the conversation.**
8. **It costs nothing, it is available in minutes, and no amount of hardware replaces a neighbour who notices.**
9. **Not a substitute for emergency services, and not a licence to direct anyone's medical care.**
10. **Doc 05 §5.10** — what a neighbour with medical training is actually useful for.

### `SEC-4`
1. **Nothing, permanently.** No weapons use, handling or construction — the listing says so plainly.
2. **Because it genuinely varies by state and locality, and a national answer would be wrong somewhere.** The household's job is to ask.
3. **Deterrence and less-than-lethal measures.** Layers, lighting, the door protocol, neighbours.
4. **The state attorney general, the local police non-emergency line, and the local waste authority.**
5. **The answer, the date, and who gave it.**
6. **It is written, dated and specific.** "I looked it up once" is not a record.
7. **It is re-dated annually**, because the law changes.
8. **A line confirming every adult has heard the answers.**
9. **DEMONSTRATED only.** It is an administrative module; the dated record is the demonstration.
10. **Nothing.** A child's security education here is the door script and the neighbour's name.

### `MOV-1`
1. **Four.**
2. **Every named carrier lifts it and walks it to the door and back**, and a second person lifts it too.
3. **The medication list in original labelled containers, and a written clinician number.**
4. **The rally point card is in; anything that requires a decision is out.**
5. **A bag its carrier cannot lift.**
6. **"Whoever is nearest."**
7. **An elder.** The plan names who carries it.
8. **Every adult, at CAN TEACH IT** — any bag, from the worksheet.
9. **What is in their bag, that they can carry it, and who carries the rest.**
10. **The federal baseline is reproduced; it does not differentiate bags by person**, so the household fills the four-column worksheet itself.

### `MOV-2`
1. **One page.** A plan nobody can find in the dark is not a plan.
2. **Two, with separate jobs** — one is a single point of failure.
3. **The date it was measured.**
4. **The bad day.** Whatever it took, plan for twice that.
5. **Written, and short enough to say under stress.**
6. **The condition under which the household stops and changes plan.**
7. **A dated note that the household has no such equipment.**
8. **Oxygen-cylinder transport and evacuation-chair specifications.** That material is not sourced.
9. **"We'd manage."**
10. **Two, because one is a single point of failure.**

### `MOV-3`
1. **Two in daylight and one after dark.**
2. **The last person out, not the first.**
3. **The doubled time, and a written answer to "is this fast enough".**
4. **Exactly one change**, written down.
5. **Anyone being hurried.**
6. **The module has failed regardless of the clock.**
7. **The rules in §8.4.1, read before the clock starts.**
8. **The run is abandoned and re-run.**
9. **They walk the route, carry their bag, and arrive at the rally point.**
10. **Because the household is only as fast as its slowest member, and rushing them is how people fall.**

### `MOV-4`
1. **Two.**
2. **Close — the front of the building or the corner — and not the building's own doorway**, which is where everyone else will be.
3. **Because a nine-year-old can find "the tree outside the laundrette" and cannot use a postcode.**
4. **You go to the point and stay there. Nobody searches.**
5. **The household's names and both rally points.**
6. **A text is a few bytes and gets through when a call cannot.**
7. **No power, no signal, a dead battery with no charger, and a separated household.**
8. **Paper.** The ICE card, the rally points and the out-of-area number, carried.
9. **Public shelter or staffed centre, a relative with power, and a pre-arranged destination.**
10. **The person who lives there has been asked and has said yes.**

### `INT-1`
1. **`DRILL-1` is the drill; `INT-1` is the same 72 hours run as an assessment** — observed, not coached, with every module's field-observable criteria checked.
2. **Observes and writes. No teaching during the event.**
3. **The full §9.4 protocol, in doc 09.**
4. **Grade A.** Grade B is for flushing.
5. **The medication plan is executed and the answer recorded.**
6. **The decision card**, and the consultation is logged.
7. **One indoor flame, or one touch of the building main.**
8. **Six contact hours inside 72 elapsed.**
9. **Stage 3**, with a closed debrief.
10. **Their two jobs**, to DEMONSTRATED.

### `INT-2`
1. **It is listed by name, with a date.**
2. **A fix with an owner and a date, or a written acceptance naming the risk.**
3. **The risk, and who accepted it.**
4. **The scorecard, against the week-0 score.**
5. **Exactly one, for the next 30 days.** Five changes is none.
6. **Every adult.**
7. **It repeats.** An unlogged failure is a failure nobody owns.
8. **The drill log**, with the scorecard.
9. **`INT-1` passed and the debrief closed.**
10. **It is accepted in writing, by name, with the risk stated** — a conscious acceptance, not a silence.

### `MOR-1`
1. **The children, the elder, and the adults.** All three, in writing.
2. **No power.** And it must have a named place where it lives.
3. **Agreed with them, not assigned to them.** Purpose and dignity are the same instruction.
4. **Who takes over, and when.**
5. **A named person and a number.**
6. **The signs of burnout and of withdrawal.**
7. **Not mental-health treatment.** Crisis lines and clinicians are the answer for a person in crisis.
8. **A crisis line and a clinician** — and the plan says so plainly.
9. **What their job is, and that the household's plan depends on it.**
10. **There is no morale chapter in docs 00–08 yet**, so the module is scoped to the day-1-to-90 timeline and the household facts until that chapter exists.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version 1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. A question that cannot be answered from the chapter it points at is an error in this document rather than a gap in the reader — report it and it will be corrected in the next errata. Where a source does not cover an item, this document says so rather than supplying a number.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
