# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 01 — THREAT MODEL AND DECISION

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This document does two jobs. First it tells you what you are actually planning for — not a
generic disaster, but the specific hazards that hit a city building and the specific ways each
one changes your water, food, heat, waste and medical picture. Second it gives you the one page
the whole program exists to produce: a **three-branch decision** about whether to stay,
whether to go somewhere staffed, or whether to make a slow, assisted exit — written down,
signed, and decided before the day you need it.

It closes with module **`BAS-4`**, the household meeting that produces that page.

---

## 1.1 Why a threat model comes before a shopping list

Most preparedness material starts with a list: buy this, stack that, carry forty pounds. A list
is the last thing you need and the easiest thing to sell you.

What decides whether a household of five with an eighty-year-old and a four-year-old comes
through ninety days without utilities is not the quantity of gear. It is whether four questions
have an answer on the day the power goes:

1. **What exactly has failed?** A grid outage, a water main, a heat wave and a flood all look
   like "no utilities" from the inside and demand opposite responses. In a heat wave you want
   water, shade and possibly to leave. In a flood you want to assume contamination and probably
   to leave. In a winter storm you want one warm room and a CO alarm. Treating them as one
   hazard is the most common planning error in this whole field.
2. **What does that failure break first in *this* building?** A second-floor walk-up loses the
   lift and the elder is effectively trapped. An upper-floor flat in a multi-storey building
   may lose tap pressure when the building's pumps lose power — the water is fine, the pressure
   is gone. A basement flat floods before the street does. Your building's answer is not the
   internet's answer; §1.2 tells you what to go and check.
3. **What is the household's actual mobility?** Not the average — the slowest member's.
4. **At what point does staying become the more dangerous choice?** This is the question this
   document exists to answer, with numbers where numbers exist and a named procedure where they
   do not.

A threat model is just those four questions written down honestly. It costs nothing, it takes
an evening, and it is worth more than any purchase in doc 11.

---

## 1.2 The urban hazard matrix

The table below is the spine of this document. Read down the left column until you find the
hazard you are actually in, then read across. Each cell names the part of the program that
changes.

The right-hand column of every row is the same in spirit and different in detail: **every one
of these hazards eventually becomes a decision about movement**, and the decision is always set
by the slowest member.

### 1.2.1 Grid outage — days to weeks

- **Water:** stored water only. The mains may still be pressurised, or may not. The water
  heater tank is a **one-time draw** (roughly 30–50 gallons in a typical house — shut the power
  or gas to it before draining, and treat the water before drinking). Plan on **2 gallons per
  person per day**; for five people that is 10 gallons a day.
- **Food:** the clock in §00 starts here — **4 hours** for a closed refrigerator, **48 hours**
  for a full freezer, **24 hours** if it is half full. Cook the thawing food first. If the
  outage was four hours or less and the doors stayed shut, refrigerated food is generally safe
  — check the temperature and discard anything above **40 °F**.
- **Heat, CO and fire:** this is where people die. A generator goes **outdoors, more than 20
  feet from windows, doors and vents** — never indoors, never in a garage even with the doors
  open. Never charcoal indoors. Never a gas oven for heat. CO alarms are the first thing you
  test.
- **Sanitation:** waste accumulates when the sewer's lift stations lose power. Handwashing runs
  off a jug.
- **Medical:** refrigerated medicines and every power-dependent device move to the top of the
  list — oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair, insulin.
- **Mobility and security:** a lift outage in a walk-up means the elder does not leave the
  building without assistance. Plan the stairs.

### 1.2.2 Water main break or boil-water advisory

- **Water:** boil **1 minute**, or **3 minutes above 5,000 ft** (EPA's figure; some state health
  departments use 6,500 ft — the EPA number is the conservative one, and the advisory notice
  always wins) — or disinfect with unscented chlorine bleach at the dose in doc 02. Do **not**
  use tap water for formula, ice, brushing teeth or washing dishes while the advisory stands.
- **Food:** discard anything prepared with unsafe tap water. No ice.
- **Sanitation:** handwashing may still be fine with tap water during a *drinking* advisory —
  follow the notice — but wash more, because the supply is compromised.
- **Medical:** watch for diarrhoeal illness, and know that rehydration means **pharmacy
  sachets**, never an improvised salt-and-sugar mix (doc 06).
- **Mobility:** usually unchanged. This is the hazard most often survivable by staying.

### 1.2.3 Winter storm or extreme cold

- **Water:** store it indoors so it does not freeze. Melted snow is **not** a safe default
  source, and this manual will not pretend otherwise.
- **Heat, CO and fire:** the highest CO risk of all the hazards — generators, charcoal,
  kerosene, gas ovens, all used indoors by people who are cold. Vented heat only, CO alarm near
  every sleeping area.
- **Sanitation:** frozen pipes mean no flushing water. The waste plan stops being optional.
- **Medical:** cold illness and medication freezing; the elder's hypothermia risk is the
  clinical priority.
- **Mobility:** falls on ice and stairs. The elder does not leave the building. Oxygen tubing
  becomes brittle in cold.

### 1.2.4 Heat wave, or no air conditioning

- **Water:** need can **double** in very hot weather — plan **2 gallons per person per day**
  minimum and more for the elderly.
- **Food:** minimise cooking heat; no-cook meals.
- **Heat and CO:** the counter-intuitive federal fact — **fans only below 90 °F indoors**. Above
  90 °F a fan **can increase body temperature**. Cooling centers are found through **2-1-1**,
  your local health department or your emergency management agency.
- **Medical:** heat illness in the elderly and infants; medicines that impair sweating.
- **Mobility:** moving to a cooling center is a **mobility decision, not a heroic one**. This is
  the hazard where branch 2 fires most often, and it fires early.

### 1.2.5 Flood

- **Water:** assume contamination. Discard any water you cannot verify. **Boiling does not
  remove chemicals or fuel.**
- **Food:** discard anything not in a waterproof container; discard cardboard juice, milk and
  formula boxes and home-canned food that touched flood water; damaged cans out.
- **Heat and CO:** a generator outdoors — **never in a flooded basement or garage**.
- **Sanitation:** the highest sanitation risk of any hazard. Wash after any flood contact;
  disinfect children's toys.
- **Medical:** wound infection after flood contact. Tetanus timing is a question for a clinician,
  not for this manual.
- **Mobility:** evacuation is likely, and it is the slow-mover plan in doc 08. Remember that
  **most public shelters take service animals only** — pets need a pre-identified place.

### 1.2.6 Civil unrest or a security incident

- **Water and food:** the store has to survive a shelter-in-place order. Keep water indoors and
  out of sight; keep 72 hours of no-cook food that needs no kitchen light and makes no smell.
- **Heat and CO:** do not improvise heat or light with fuel indoors because the power is out.
  This is exactly when people do it.
- **Sanitation:** waste and hygiene while not leaving the unit.
- **Medical:** prescription continuity if pharmacies close.
- **Security:** the whole of doc 07 — lighting, sightlines, a door that answers safely,
  neighbors who know you, and knowing your local law. **No weapon tactics, and none anywhere
  in this program.**

### 1.2.7 Quarantine, or illness in the household

- **Water:** extra for the sick person; separate drinking vessels.
- **Food:** bland, rehydration-adjacent food; infant feeding handled carefully.
- **Sanitation:** isolate a bathroom if you can. Handwashing and surface cleaning become the
  main control.
- **Medical:** rehydration sachets and *get to a health facility* — this is the one hazard where
  the correct answer is usually "seek care", not "hold out".
- **Mobility:** the elder is the highest risk; the carer needs protection or the plan collapses.

### 1.2.8 Wildfire smoke

- **Water and food:** keep everything sealed; ash contaminates open containers. Keep food
  covered.
- **Heat and CO:** do not run a generator or burn anything where the smoke is already bad.
- **Medical:** respiratory risk to asthmatics, children and the elderly.
- **Mobility:** the evacuation decision is driven by the slowest member and by air quality.

### 1.2.9 What the matrix is telling you

Three patterns matter more than any individual row.

**First, four hazards in eight are decided by temperature.** Heat and cold are the fastest route
from "inconvenient" to "the elder is in danger", and they are the triggers that most often move
a household that intended to stay.

**Second, every hazard converges on the same short list.** Water, waste, warmth without
combustion, and medication/device continuity. Get those four right and the specific hazard
matters much less than you would think.

**Third, the matrix is generic and your building is not.** Go and find out, this week, four
things: whether your taps run without power (and at what floor they stop); where the lift is and
who to call if it stops; whether your building's water heater or boiler is yours or shared; and
what your landlord's emergency number actually is. Write the answers into the back of doc 10.
That page is worth more than the rest of this table.

---

## 1.3 The four constants

Whatever the hazard, the program keeps returning to four things. They are worth naming once,
here, because every branch below is triggered by one of them failing.

**Water.** The planning figure is **2 gallons per person per day** for a household like yours —
5 people, 10 gallons a day. The federal minimum of 1 gallon per person per day is the *floor*,
not the plan; use it only as the "we are now in trouble" number. Ninety days at 2 gallons is
**900 gallons**, which is roughly 75 large drums and about 7,500 lb — physically impossible in
most apartments and beyond typical residential floor loading. That is why the 90-day plan is
**store → harvest → treat → ration by activity**, and never "stack 900 gallons".

**Waste.** Garbage bags and ties are on the federal kit list; handwashing is 20 seconds with
soap and safe water. What no federal source retrieved for this program gives is a construction
method, a volume per person, or a disposal rule — so this manual gives you none of those either.
What it gives you instead is the honest statement that **the legality of waste disposal varies
by jurisdiction and is your household's job to check with your local health department**, and
that ninety days of waste from five people in an apartment is this plan's real failure point.
That is why "sanitation untenable" is an explicit trigger in §1.9 rather than an afterthought.

**Warmth without combustion.** A warm room and a CO alarm, in that order of thinking and the
opposite order of installation: alarm first, always.

**Medication and devices.** The commonest way a manageable outage becomes an emergency in a
household with an elder in it. A device that needs mains power or refrigeration is a
decision-tree trigger on its own (§1.9, trigger M1).

---

## 1.4 Why staying is a legitimate plan

Almost all evacuation advice is written for someone who can walk out. Yours cannot. That does
not make you unprepared; it makes the standard advice wrong for you.

Consider what "bugging out" actually requires of a household of five with an elder and a
four-year-old: a vehicle or a route, fuel or tickets, a destination that will take all five,
carry capacity for water, food, medication and mobility equipment, and the physical ability to
move all of it — probably on foot, because Ready.gov is explicit that **your evacuation route
may be on foot** depending on the disaster. For a household whose slowest member cannot do
stairs unassisted, that is not a plan. It is a hope with a backpack.

Staying is legitimate for four reasons:

1. **Your building is your shelter and it is already paid for.** Walls, a roof, a door that
   locks, plumbing, and a known distance to the stairs. An evacuation trades all of that for a
   road.
2. **Your store is already there.** Water, food, blankets, medication, tools. It does not have
   to be carried.
3. **Your neighbors are there.** Mutual aid is the highest-return security investment available
   and it costs nothing: three neighbors by name, and knowing which one has medical training.
4. **The alternative is usually worse for the person you are protecting.** A shelter is a
   congregate setting; **most public shelters take service animals only**, so a pet has nowhere
   to go; and moving an elder through a disrupted city is itself a hazard.

So the default is **STAY AND HARDEN**. But a default is not a policy. A default with no exit
condition is how people end up staying through the one event they should have left for. Hence
§1.5.

---

## 1.5 The three branches

The realistic answer for a household that cannot run is often **neither** bug-in nor bug-out.
It is one of three things, and the third one is the one almost nobody plans:

| Branch | What it means | Cost | How long it takes |
|---|---|---|---|
| **1. STAY AND HARDEN** | Remain in the home. Improve it. Ration. | Cheapest; uses what you have | Immediate — it is the default |
| **2. GO SOMEWHERE STAFFED** | Public shelter, cooling or heating center, or a relative's home with power | Low to moderate; transport dependent | Hours |
| **3. SLOW EXIT** | Pre-planned, assisted move to a pre-arranged destination, at the slowest member's pace | Highest; needs a destination, transport and a route | A day or more of preparation |

The branches are not ranked by toughness. Branch 2 is not a failure and branch 1 is not
bravery. The whole point of writing them down in advance is that **the decision is made by
people who are calm, about a situation that has not happened yet**, and then executed by people
who are frightened.

### 1.5.1 One rule that overrides all three branches

**An official instruction beats this document.** If local officials issue an evacuation order,
you go — that is not a branch decision, it is compliance. If they issue a shelter-in-place
order, you stay. Where this manual and a local advisory differ, the local advisory wins, every
time.

And one medical rule that overrides everything: **heat stroke is not a branch decision.** A body
temperature **above 103 °F**, or confusion, slurred speech or loss of consciousness in the heat,
means **call the emergency number now** — the National Weather Service is explicit that delay
can be fatal, and that you should **not give fluids** to someone in that state. Cooling and
calling happen at the same time; the decision card waits.

---

## 1.6 Branch 1 — STAY AND HARDEN

**What it is:** you remain in the home for the duration, and the work becomes rationing,
temperature management, waste management and morale.

**What has to be true for this to hold:**

- Water: a store of at least **14 days at 2 gallons per person per day** — for five people,
  140 gallons — *plus* a harvest and treatment method for after day 14.
- Waste: a route you have actually confirmed with your local health department or building
  management, not one you assume.
- Warmth: one room you can keep warm without combustion indoors, and a tested CO alarm.
- Medical: every device and every refrigerated medicine has a continuity plan (`BAS-2`,
  `MED-2`).
- Temperature: the indoor temperature is survivable for the least resilient member.
- Safety: the building is structurally sound, not flooded, not on fire, not under an order to
  leave.

**What it is not:** it is not "wait and see". Staying has its own work list — that is what the
twelve-week calendar in doc 00 is for. A household that stays without doing the work is not
executing branch 1; it is executing branch 0, which is drift.

**Why it is usually right for you:** it keeps the elder in a familiar place, keeps the store
accessible, keeps the neighbors close, and keeps the household out of a road and a congregate
shelter. Most outages in most buildings are survived by staying.

---

## 1.7 Branch 2 — GO SOMEWHERE STAFFED

**What it is:** a short move, hours not days, to a place that has staff, power and water —
a public shelter, a **cooling or heating center**, or a relative's home that still has
utilities.

**Where to find one:** **dial 2-1-1**. The CDC points households to 2-1-1, to state cooling
center listings, and to the local health department or emergency management agency. Do not
drive around looking for an open building.

**What it demands of you, honestly:**

- **Pets.** **Most public shelters allow only service animals.** If your household has a pet,
  branch 2 requires a pre-identified place that takes animals. Find it now, not at the door.
- **Equipment.** A shelter is not a clinical setting. Oxygen, a powered chair, a CPAP, or a
  member who needs help with toileting or feeding may make a relative's home a better target
  than a shelter — and that has to be decided in advance, by the person who would be doing the
  caring.
- **Transport.** You need a way there that does not require the slowest member to walk far or
  do stairs unassisted. If the answer is "a taxi", check now whether taxis are running, because
  in a regional event they are not.
- **What you carry.** Not the whole store. Medication, documents, water for the trip, the
  mobility equipment, chargers, cash, and the decision card. Doc 08 has the bags.

**What branch 2 is good at:** temperature. A heat wave with an elder in an un-air-conditioned
flat is the classic case, and the classic mistake is to stay out of pride while the indoor
temperature climbs past the point where a fan helps. Above **90 °F indoors a fan can increase
body temperature** — that is CDC and NWS both, and it is the most counter-intuitive fact in this
program. When that threshold is crossed and there is no way to cool the flat, branch 2 is the
correct answer and it is not weakness.

**What branch 2 is bad at:** duration. Shelters are for the acute phase. If the event will run
weeks, branch 2 buys you time to arrange branch 3, and should be treated that way.

---

## 1.8 Branch 3 — SLOW EXIT

**What it is:** a pre-planned, assisted move of the whole household to a pre-arranged
destination — a relative out of the affected area, a second property, a friend's house, a
motel — executed at the slowest member's pace, with the route and the transport already
decided.

**It is not an evacuation.** An evacuation is something done to you in a hurry. A slow exit is
something you do on a Tuesday because a trigger fired and you had already done the paperwork.

**The three prerequisites — all three, or it is not a branch:**

1. **A destination that has agreed to take you.** Named, spoken to, and aware of what your
   household actually needs: how many people, what equipment, whether there are stairs, whether
   there is a pet, how long you might stay. "We could probably go to my sister's" is not a
   destination. A phone call is.
2. **Transport that fits the slowest member.** Not "we'll figure it out". A named vehicle, a
   named driver, a named backup, and a loading plan that does not require the elder to stand on
   a kerb for twenty minutes.
3. **A route that does not require stairs or long walking at either end.** Both ends. The
   destination's front door matters as much as yours.

**When it fires:** when a branch-2 condition has clearly become long rather than short, or when
the destination will not be available later (a relative's spare room gets taken, a motel fills),
or when a trigger in §1.9 fires that a shelter cannot solve — a powered medical device that has
stopped and cannot be run anywhere but a home with power, for instance.

**Why it is worth preparing even though it is expensive:** because the alternative, when the
trigger fires, is a panicked version of the same journey with a frightened elder, no
destination, and no route. The difference between the two is one evening of phone calls and a
signed card.

---

## 1.9 The triggers — the numbers and conditions that move you

This is the operative page of the document. Each trigger is written so that a frightened adult
can check it in under a minute. **Any single trigger is enough to open the branch conversation;
two or more means act.**

Triggers are grouped by the four constants in §1.3, plus temperature, which cuts across all of
them.

### 1.9.1 Medical and device triggers

| # | Trigger | Fires | Because |
|---|---|---|---|
| **M1** | A **mains-powered device stops** and cannot be run from another source — oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair | **Branch 2 immediately**, branch 3 if it will not be short | The device is the lifeline, not the utility. This is the single most time-critical trigger in the program |
| **M2** | A medicine that **must stay cold** has no cold storage left, or a prescription runs out with no route to a refill | Branch 2 or 3 | The clinical risk is now the outage's fault, and it is not survivable by rationing |
| **M3** | Anyone shows **heat stroke signs** — body temperature **above 103 °F**, confusion, slurred speech, loss of consciousness | **Call the emergency number. Now.** Do not give fluids | NWS: delay can be fatal. This is not a branch decision |
| **M4** | Anyone shows signs of a **stroke** — face drooping, arm weakness, speech difficulty | **Call the emergency number. Now.** | Time-critical; every minute matters |
| **M5** | Diarrhoea or vomiting in a child or elder that will not stop, or blood in it | **Seek care** — rehydration sachets are first aid, not treatment | Dehydration in the very young and very old is fast and it is the commonest serious complication of a water outage |

### 1.9.2 Water triggers

| # | Trigger | Fires | Because |
|---|---|---|---|
| **W1** | Stored water is down to **1 gallon per person per day** — 5 gallons a day for five people — with no working harvest source | **Branch 2** | That is the federal *floor*, not the plan. Below it you are one hot day from a medical problem |
| **W2** | Water is available but **cannot be made safe** — no fuel to boil, no bleach of the right strength, and no filter that removes the relevant organisms | Branch 2 or 3 | Unsafe water is a faster route to a household-wide illness than thirst is |
| **W3** | Water is **contaminated with fuel, chemicals or floodwater** | **Branch 3.** Boiling does not fix it | Neither boiling nor bleach removes chemicals. This is the trigger people get wrong |
| **W4** | The store is intact but **rationing is already reducing drinking** | Branch 2 conversation **today** | Ready.gov: **never ration drinking water** unless authorities order it — reduce activity instead. If you are rationing drinking, the plan has already failed |

### 1.9.3 Sanitation triggers — the explicit ones

| # | Trigger | Fires | Because |
|---|---|---|---|
| **S1** | **Sanitation is untenable:** waste cannot be contained in the unit without a health hazard to the household, **or** there is no legal disposal route | **Branch 2, or branch 3 if it will last** | This is the plan's real failure point and it is stated as a trigger on purpose. A household that waits for the smell to decide has waited too long |
| **S2** | The toilet cannot be used and no alternative has been built | Branch 2 conversation | A working waste plan is a precondition of branch 1, not an optional extra |
| **S3** | Handwashing cannot be maintained — no soap and no safe water | Branch 2 conversation | Hand hygiene is the main infection control in every one of the eight hazards in §1.2 |

### 1.9.4 Temperature triggers

| # | Trigger | Fires | Because |
|---|---|---|---|
| **T1** | **Indoor temperature is at or above 90 °F** and cannot be reduced, with an elder, an infant or anyone with a cardiac or respiratory condition in the household | **Branch 2 — cooling center via 2-1-1** | Above 90 °F a fan **can increase body temperature**. Staying becomes the dangerous option |
| **T2** | Indoor temperature is falling and **the household cannot keep one room warm** without combustion indoors | Branch 2 or 3 | Cold plus an elder plus no safe heat is the winter equivalent of T1 |
| **T3** | Pipes are frozen, so there is no flushing water at all | Branch 1 can continue only with a working waste plan (S1) | Freezing converts a water problem into a sanitation problem |

### 1.9.5 Civil and structural triggers

| # | Trigger | Fires | Because |
|---|---|---|---|
| **C1** | An **official evacuation order** for your area | **You go.** Not a branch decision | Compliance. The local advisory wins |
| **C2** | Fire in the building, or a neighboring fire that has not been contained | **You go** | Smoke and fire spread through a building faster than any plan |
| **C3** | Floodwater in the unit, or the building declared unsafe | **You go** | Structural and contamination risk, and the generator/electrical hazard that follows |
| **C4** | Security has become an immediate threat to a household member | **Branch 2, tonight** | The plan protects people, not property. Doc 07 covers the calm version of this; the emergency version is "leave and call" |
| **C5** | The **elder has fallen** and cannot be safely moved by the adults present | **Call for help** | Falls are the leading injury cause over 65, and an unsafe lift is how a fall becomes a permanent injury |

### 1.9.6 How to use the triggers

Print the table. Keep it with the decision card. Check it at the points doc 00 sets: **72 hours,
day 7, day 14, day 30**. Check it immediately, any time, if something changes.

Two rules about triggers:

- **A trigger is not a debate.** It is a pre-agreed instruction from your calmer self to your
  frightened self. The only thing to discuss is *which* branch, never *whether*.
- **Write down the date and time each time you check.** A household that cannot say when it
  last checked has stopped running a plan and started improvising.

---

## 1.10 The decision card

Doc 10 contains the card itself, in printable and large-print form. It is one page and it has
six boxes. Fill it in at the household meeting (`BAS-4`), sign it, date it, and put one copy on
the inside of a kitchen cabinet and one in each go-bag.

1. **Branch 1 — we stay if:** the conditions in §1.6 hold. Write the household's own version,
   including the water number for *your* household size.
2. **Branch 2 — we go somewhere staffed if:** two named triggers from §1.9, written in your own
   words. Add the destination: which shelter, which center, which relative — and the phone
   number.
3. **Branch 3 — we make the slow exit if:** the destination, the transport, the driver and the
   backup driver, and the route.
4. **Who decides, and who decides if they cannot.** One name, and one alternate. A decision
   process that depends on one adult being conscious is not a process.
5. **Who is told, and when.** The out-of-area contact, and the check-in interval.
6. **Signatures and dates, from every adult in the household.** Not a formality: signing is
   what converts a conversation into an agreement that survives an argument at 2 a.m.

The card is deliberately short enough to read aloud in a minute. If yours does not fit on one
page, it is not finished.

---

## 1.11 Module `BAS-4` — Family decision card and household meeting

> **Tier 0 — BASELINE. This is the first module in the program and the only one that is
> entirely an act of agreement rather than an act of skill.**

**Objective.** Produce a signed, dated, one-page decision card covering all three branches, and
hold a household meeting in which every adult can state, in their own words, what each branch
means and what would make the household take it.

**Chapters.** `01 §1.5`–`§1.10` (this document) · `00 §0.5` (the scorecard) · `00 §0.6` (the
First 60 Minutes card) · `10` (the card and the ICE card) · `07 §7.3` for the door protocol
context (its legal side is §7.5) · `08` for the destination and transport details.

**Drill — the household meeting.** Ninety minutes, once, with every adult present and phones
down.

1. **Minute 0–10 — the roster.** Who is in this household, and who cannot walk far, lift, hear,
   be left alone, or manage stairs. This is `BAS-1` read aloud. Children over eight are told
   their two jobs: fetch help, and know the rally point.
2. **Minute 10–30 — the branches.** Read §1.5–§1.8 aloud, in order. Stop after each branch and
   ask every adult: *"Say back to me what this means for us."* Do not move on until each person
   has. An agreement nobody can restate is not an agreement.
3. **Minute 30–55 — the triggers.** Read §1.9. For each group, the household names the two
   triggers that worry them most and writes them on the card in their own words.
4. **Minute 55–75 — the destination and the transport.** Name the branch-2 places and the
   branch-3 destination. Write the phone numbers. If a call needs making, make it in the
   meeting — a destination nobody has spoken to does not count.
5. **Minute 75–85 — who decides.** Name the decider and the alternate. Name the out-of-area
   contact.
6. **Minute 85–90 — sign and date.** Every adult. Then decide where the copies go.

**Observable pass criteria — all six, or it does not pass:**

- A completed one-page card exists, in ink, dated.
- All three branches are written in the household's own words, not copied from this page.
- At least **two named triggers per branch**, drawn from §1.9.
- A named branch-2 destination **and** a named branch-3 destination, each with a phone number.
- A named decider **and** a named alternate decider.
- Every adult in the household has signed, and can restate the three branches without reading
  them.

**Assessment.** By an adult who did not lead the meeting, or by a neighbor or CERT contact in a
single-adult household. Rated **NOT YET / DEMONSTRATED / CAN TEACH IT**. The pass level for
`BAS-4` is **DEMONSTRATED by every adult**, and the household-level rating is the lowest
individual rating — one adult who cannot restate the branches means the household has not
passed, because that is the adult who will be making the call.

**Realistic hours.** 1.5 hours for the meeting, plus about 30 minutes of phone calls. This is
the cheapest module in the program and the one with the highest return.

**Who must be able.** Every adult, to the DEMONSTRATED standard, including the restatement.
Children aged eight and over are told their two jobs and must be able to state them, but are not
rated on the branches.

**What this module does not do.** It does not make the household ready, and it is not a
certificate. It makes the household *agreed* — which is the precondition for everything else in
this manual actually being used rather than admired.

---

## 1.12 What would make this plan wrong

Honesty requires naming the ways this document could fail you, so you can watch for them.

1. **The trigger fires and nobody checks.** The commonest failure. The calendar in doc 00 and
   the log in doc 10 exist only to prevent it.
2. **The destination was never really agreed.** A relative who says "of course, any time" in
   June is not the same as a relative who has been told what your household needs in November.
3. **The household has one capable adult.** If that adult is injured or ill, the plan collapses.
   This is why life-critical modules require **CAN TEACH IT**, not just DEMONSTRATED.
4. **The sanitation question is left to day 30.** It is the plan's real failure point, it is
   stated as trigger S1, and it is the one item this program cannot solve for you because the
   legality of disposal is local.
5. **A number is trusted that should not be.** This manual deliberately prints no improvised
   rehydration ratio and no fuel quantity. If you find yourself using a figure from a forum
   instead of a sachet or a fire marshal, the plan has left the manual.
6. **The event is nothing like the model.** The matrix in §1.2 is eight hazards; the world has
   more. The four constants in §1.3 transfer to almost anything. Fall back on those.

---

## 1.13 Before you go to doc 02

Three things, this week:

1. **Fill in the building page** in doc 10 — taps without power, lift, water heater ownership,
   landlord emergency number. Four questions, one phone call.
2. **Hold the `BAS-4` meeting** and sign the card.
3. **Score the readiness scorecard** in `00 §0.5` and date it.

Then doc 02 — water — which is the first of the four constants and the one that runs out first.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it
on. This is version 1.0, errata date 2026-11-02; corrections are recorded in the README and any
corrected figure is dated.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your
local emergency number. Follow your local health authority's guidance over anything in this
guide. Written for US households.*
