# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 05 — FIRST AID

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

The first injury of an outage is rarely dramatic. It is a hand on a hot pan in the dark, a foot through a
stairwell with no light, a cut opened on broken glass in a flooded basement, a hip that breaks on the way to a
toilet at 3 a.m. because the hallway is black and the slippers have no back. In a normal week each is a clinic
visit. In week three of a blackout, with the pharmacy shut, each is a decision about whether this household can
manage at home.

This chapter covers the first-aid kit, bleeding control, choking, anaphylaxis, stroke recognition, falls, burns,
wound care and infection, heat and cold illness, and the red flags that end the discussion. It closes with modules
**`MED-4`** and **`MED-6`**. Nothing here is finished by reading it.

> **The sourcing rule, and the hard limits of this chapter.** This chapter teaches **recognition** and **what to do
> in the first minutes**. It does **not** teach technique that belongs in your hands, under an instructor, with a
> manikin: no CPR compression depth or rate, no tourniquet application, no airway manoeuvre on a child under one,
> no splinting, no lifting. Those are printed nowhere in this program on purpose, because a half-remembered
> technique read at 2 a.m. is how a rescuer freezes instead of acting. The instruction is a course — a local
> in-person first-aid and CPR course, and FEMA's free **IS-317.A** (*Introduction to Community Emergency Response
> Team (CERTs)*) and **IS-22** (*Community Preparedness: Implementing Simple Activities for Everyone*). What
> follows is what you need to know **before** the course, and what you need to remember three years after it.

---

## 5.1 The first-aid kit

### 5.1.1 What this list is, and what it is not

**No federal page retrieved for this program specifies first-aid kit contents.** Ready.gov's kit guidance names
the medication categories — "non-prescription medications such as pain relievers, anti-diarrhea medication,
antacids or laxatives" and "prescription medications" — and nothing more granular. So the kit below is a **starting
list built by reasoning**, labelled as such: categories and jobs, not brands and not quantities. **This program
prints no quantities, because a quantity is a guess about your household dressed up as an instruction.** You count
for your own people and write the number on the box in your own hand.

The medication half of the kit is doc 06 §6.1, because medicine is a different problem from bandages: it expires,
it interacts, and it needs a list. This section is the **trauma** half.

### 5.1.2 The kit, by job

Buy by job, not by the pre-packed box: a $12 kit in a moulded plastic case is mostly small adhesive bandages and one
pair of gloves, designed for a kitchen.

**Stop bleeding:** absorbent gauze pads in more than one size; rolled or conforming gauze to hold a dressing in
place; tape; a heavy pad for a large wound; nitrile gloves in the size the adults here actually wear — a glove that
does not fit comes off while you are pressing on something.

**Clean and cover:** mild soap, the actual wound-cleaning agent (§5.8); clean water in a lidded jug reserved for
wounds; sterile dressings; plastic film to cover a dressed limb so a person can still wash. **See and reach:** a
torch kept with the kit and not borrowed; a thermometer; tweezers; blunt-nose scissors; pen, notebook, marker.
**Protect and hold:** a blanket or foil sheet; safety pins; a triangular bandage, which is a sling, a pad and a tie
in one object.

**Household-specific, and the part the pre-packed box never has:** the person's own prescribed emergency medicine
(§5.4); glucose for a diabetic member; a spare pair of the glasses without which someone cannot walk; the printed
medication list (doc 10); the ICE card (doc 01); and this chapter, printed.

### 5.1.3 Where it lives, and the two rules

**One kit, in one place, known to every adult and to the oldest child.** Not split between the bathroom cabinet and
the car. In a night-time fall it must be reachable without a search, which means the bedroom end of the flat.

**Rule one:** the kit is **checked twice a year**, when the clocks change and the CO alarm batteries are checked
(`CO-1`), and everything expired is replaced rather than kept "for the real thing." **Rule two:** anything used is
**replaced the same week** — the next time this household needs a dressing, someone is bleeding.

---

## 5.2 Bleeding control

### 5.2.1 Pressure, time, and calling early

Most external bleeding that frightens people stops with firm direct pressure held without interruption. The failure
mode is almost never too little pressure — it is **lifting the dressing to look**, which restarts the clock every
time. If the dressing soaks through, do not remove it; add another on top and keep pressing.

**Call while you press.** In this household that means saying the words out loud to a second person: *"call 911,
say heavy bleeding, bring the kit."* One adult pressing and one adult calling is the whole plan, and it needs
rehearsal, because everyone else in the room will stand still and watch.

**Position and warmth.** Lie the person down, keep them warm, keep talking to them. Someone bleeding heavily who
goes pale, clammy, thirsty, confused or drowsy is beating your dressing — that is "call now and say *bleeding that
will not stop*," not "press harder and see."

### 5.2.2 What this chapter deliberately does not print

**No tourniquet technique.** A manufactured tourniquet applied correctly saves a life. Applied from a paragraph by
someone who has never done it, it is a device that gets loosened to "check," or improvised from a belt, or left off
a wound that needed one because the reader was unsure. **This program prints the decision rule and no method:** a
tourniquet is for a limb wound bleeding so heavily that direct pressure is not controlling it, it is a commercial
device and not a cord, and the technique is a hands-on skill you acquire before you need it. Ask your course
instructor to teach it; then buy the device and know where in the kit it is.

**No wound-packing instructions, no pressure-point map, and no "elevate above the heart" as bleeding control.**
Elevation is a comfort measure for a small wound; taught as bleeding control, it makes people lift a leg instead of
pressing a dressing. **No removing an object stuck in a wound** — leave it, dress around it, get help. That one is
safe to print as an absolute, because the harm from pulling it out is immediate.

### 5.2.3 The fridge-door line

> **Press hard, do not lift to look, add a dressing on top, call early, keep them warm, keep talking.**

---

## 5.3 Choking

### 5.3.1 Recognition — the distinction people get wrong

The question is not "are they coughing." It is **"is air moving."**

**Air is moving:** they can cough, speak or cry; they are making noise. **Do not intervene physically.** A coughing
person is clearing their own airway, and a cough is the most effective tool available; thrusts on a coughing person
can turn a partial obstruction into a complete one. Stay, tell them to keep coughing, do not leave the room.

**Air is not moving:** they cannot speak, cannot cough, cannot breathe, may clutch the throat, and the sound — if
any — is a thin wheeze or nothing. Face red, then grey-blue. **Emergency now:** call 911 and start what you were
taught.

**The third state, which people miss:** a person who was choking, went quiet, and is now limp or unconscious. That
is a cardiac-arrest call and a CPR call, and it is exactly what the CPR course exists for (§5.10.3).

### 5.3.2 What to do, at the level this chapter will go

For a **conscious adult or child over one** with no air moving: call 911 (or have someone call, and say the word
*choking*), then deliver the sequence of back blows and abdominal thrusts you were taught. This program prints no
counts, no hand placement and no force, because those are taught with a manikin and a person watching your hands,
and because the adult-versus-child differences are exactly the detail a panicked reader gets wrong.

For an **infant under one** the method is different — different position, different hand, different force — and
**nothing in this program covers it.** Learn it from a course before you need it. If a baby here is choking and you
have not been taught, call 911 and follow the dispatcher in real time. That is not a cop-out: the dispatcher is
trained to talk a frightened adult through it and is a better source at that moment than any page.

**If they go unconscious:** lower them to the floor, call 911 if not already called, and begin the CPR you were
taught.

### 5.3.3 Prevention, the only part that reliably works

**Under four: whole grapes, whole nuts, hard sweets, hot-dog rounds, popcorn, deflated balloons** — an outage puts
unfamiliar food in front of distracted adults in the dark. **Nobody eats while walking, laughing or lying down, and
nobody eats in the dark.** The elder with a swallowing problem (doc 03's dysphagia diet) eats sitting fully upright,
unhurried, with a second adult in the room: doc 03 sets the texture rules, this chapter sets the supervision rule.
**Dentures come out at night only, never at a meal** — loose dentures are a choking mechanism.

---

## 5.4 Anaphylaxis

### 5.4.1 Recognition

Anaphylaxis progresses over minutes, and it is the emergency where hesitation kills most reliably — because the
treatment is in the house and the person talks themselves out of using it.

**Suspect it when, after an exposure (a food, a sting, a medicine, sometimes latex), a person develops two or more
of:** hives, flushing or swelling; swelling of lips, tongue or throat; difficulty breathing, wheeze or a hoarse
voice; vomiting or abdominal cramping; a sense of impending doom, agitation or confusion; dizziness, collapse or
fainting. **Airway, breathing or blood-pressure signs are what make it anaphylaxis rather than a rash** — and a
rash with difficulty breathing is a call now, not a wait and see.

**The trap in an outage:** the exposure is often something new — changed food (doc 03), a different soap, a
borrowed medicine, a sting while clearing debris. A reaction to something the person has never reacted to before is
still anaphylaxis.

### 5.4.2 The rule

> **Use the auto-injector at the first sign of airway or breathing involvement. Call 911. Do not wait to see if it
> gets worse. Do not drive them yourself if an ambulance is available.**

Why this is a rule and not a judgement call:

- **Using it unnecessarily is far less dangerous than waiting.** That is why every guideline puts the injector
  before the ambulance, not after.
- **It can come back.** A person who improves can deteriorate hours later, which is why the ambulance ride is part
  of the treatment and not a courtesy.
- **Antihistamine is not the treatment.** It may settle hives and does nothing for an airway. This is the most
  common fatal substitution in home first aid: the tablets are in the cupboard, the injector is in a drawer, and
  the tablets go in first.

### 5.4.3 The device, in this household

**The technique is printed on the device and in the manufacturer's own instructions, and you follow those, not this
page.** Devices differ — where they are held, whether the cap is a cap or a shield, how long you hold — and the
label in the box is the authority. What this chapter adds is the household discipline:

- **Two devices if the prescription allows**, in two different places, because one is in the bag that is in the
  car. The second dose is given per the prescription's own instruction if the person is not improving and help has
  not arrived.
- **Every adult has held the trainer.** Most manufacturers ship one with no needle; if yours did not, ask the
  pharmacist. A device never held by the person who will use it is a device that gets fumbled.
- **The expiry date is on the calendar** with the medication list (`MED-2`), and the replacement is requested
  before it lapses.
- **The school, the sitter, and the neighbour who takes the child in an emergency all know where it is.**
- **Nothing about the injection replaces the call.** The injector buys minutes; the ambulance is the treatment.

---

## 5.5 Stroke recognition

### 5.5.1 The one fact that changes the outcome

**Time last known well.** Not the time you found them, not the time the ambulance came — **the last moment you
know they were normal.** That fact decides whether a stroke can be treated, and it is the fact families lose,
because nobody was watching the clock in a blackout. With the power out and people sleeping in the warm room on an
irregular schedule, "last known well" is genuinely hard to establish — which is a reason to note the time someone
last spoke normally when the household goes to bed.

### 5.5.2 Recognition — the four-part screen

**FAST** takes twenty seconds, runs on anyone, and needs no equipment:

- **F — Face.** Ask them to smile. Does one side droop, or does the smile pull to one side?
- **A — Arms.** Ask them to raise both arms and hold them up. Does one drift down, or can they not lift one?
- **S — Speech.** Ask them to repeat a simple sentence. Is it slurred, wrong-word, or absent?
- **T — Time.** If any of the three is abnormal, **note the time and call 911 immediately.** Say the word *stroke*.

**Sudden trouble walking, sudden severe headache with no cause, sudden loss of vision in one eye, and sudden
dizziness or loss of balance** are stroke signs too, and they are the ones dismissed as "they stood up too fast."

**This screen is a recognition aid, not a diagnosis.** A person can have a stroke and pass it. If something is
suddenly wrong with a person's face, arm, speech, vision, balance or thinking, and it came on in minutes, that is a
call — and the honest position, which is the one the sources support, is **when in doubt, call your local emergency
number.** No retrieved source carries a home triage algorithm for stroke, so this chapter prints the screen and the
call, and nothing about what to do instead of calling.

### 5.5.3 While you wait, and three things not to do

**Do:** keep them still and calm, write the time last known well on paper, gather the medication list (doc 10),
unlock the door, and have someone wait where the ambulance can see them — a paramedic who cannot find the flat in a
blackout is a delay nobody planned for.

**Do not give food or drink.** A stroke can affect swallowing, and a mouthful of water in a person who cannot
swallow is a second emergency. **Do not give aspirin.** The reflex "aspirin for stroke" is wrong often enough — a
bleed in the brain is a stroke too, and aspirin makes it worse — that the decision belongs to the hospital. **Do
not let them "sleep it off."** That sentence costs the most, and it is usually said by the person having the
stroke.

---

## 5.6 Falls — the leading injury cause over 65

### 5.6.1 Why this section exists, and one honest caveat

Falls are the leading cause of injury in adults over 65. That is the premise of this section, and it is the one
claim in this chapter stated as a ranking rather than a figure — **no rate, count or percentage is printed here**,
because none was retrieved, and an invented number in a health chapter is worse than a blank.

The reason it belongs in a preparedness program is that **an outage manufactures falls.** Every mechanism gets
worse at once:

- **The lights are out.** A dark hallway, a dark stairwell, a torch left in the wrong room, a candle on the floor.
- **The routine is gone.** Odd hours, sleeping in the warm room (doc 04 §4.1.1), a familiar route walked through an
  unfamiliar layout of boxes, water containers, buckets and bags.
- **The load is new.** Carrying water up stairs is a new activity for an eighty-year-old, done tired, in the dark,
  with no hand free for the rail.
- **The floor is wet.** Handwashing stations, dishwater, spilled buckets, tracked-in rain, a leaking ceiling.
- **The footwear is wrong.** Backless slippers, socks on a bare floor, boots too heavy to lift properly.
- **The medicine is the same, the body is not.** Blood-pressure medicine, sedatives, sleeping tablets, diuretics
  and painkillers all raise fall risk, and dehydration or a week of poor eating makes a usual dose behave
  unusually. **Nothing is stopped or changed without the doctor** (doc 06 §6.2) — but the household should know
  which medicines are the fall-risk ones and walk accordingly.
- **The drop on standing.** Getting up fast after hours lying down causes a moment of dizziness that is entirely
  predictable and entirely preventable — sit up, count, then stand.

### 5.6.2 The prevention walkthrough — the part that actually works

Do this **with the person at risk, in the dark, with a torch**, not as a lecture. Twenty minutes; it is `MED-6`'s
second drill.

1. **Light the route, not the rooms.** The path from the sleeping place to the toilet is the path walked in the
   dark. A battery night-light, or a torch taped down so it cannot roll, on that route beats a bright kitchen.
2. **Clear the floor of the route completely** — cables, boxes, bags, the corner of a rug, the bucket, the shoes.
   Walk it in socks if you must, to find what a foot finds.
3. **Fix the rails.** The bathroom needs a grab point by the toilet and in the shower; the stairwell needs a
   continuous rail on at least one side. A loose rail is worse than no rail, because it will be grabbed.
4. **Footwear by the bed, with a back and a sole** (doc 04 §4.5.3). Socks and backless slippers on a bare floor are
   a fall waiting for a wet patch. **Make the toilet trip shorter** with a commode or urinal bottle in the warm
   room, which removes the commonest night-time fall and, with the water off (doc 04 §4.6), solves a second problem
   at once.
5. **Never rush the stairs:** one hand on the rail, one thing carried, and the stairs are walked, not hurried.
   **Water handling is a two-person job for the slowest member** — doc 08's carrying plan is the fall-prevention
   plan: who carries, how much, how many trips, and what happens when the carrier is the one at risk.
6. **The phone or whistle goes in the pocket, not on the table.** A person who falls and cannot get up is found in
   minutes with a phone in a pocket and in hours without one.

### 5.6.3 After a fall — the first ten minutes

**Do not rush to stand them up.** Everyone's instinct is to lift the fallen person to their feet, and lifting a
person with a broken hip is what turns a fracture into a much worse operation.

1. **Do not move them yet.** Kneel to their eye level and ask two questions: **where does it hurt**, and **can you
   move your toes and feel my hand.** Ask them to move the leg themselves, if they can, before you touch it.
2. **Look for what makes it a call:** a leg shortened or turned outward, inability to bear weight, a head injury
   (especially on a blood thinner — a head knock in a person on an anticoagulant is a hospital visit even if they
   seem fine), deformity at the wrist or hip, back or neck pain, or any loss of consciousness, even briefly.
3. **Call 911 and say "fall, possible hip fracture, and the person is on..."** — then read the medication list. The
   dispatcher needs the anticoagulant fact.
4. **Keep them warm and still, and give no food or drink** until it is clear whether an operation is coming.
5. **If there is no injury and they can get up**, they get up **their** way: roll to the side, to hands and knees,
   a stable chair, rise slowly with someone standing by but not lifting. **This program prints no lifting or
   hoisting technique** — a two-person lift by untrained people is how the helper's back goes too. If they cannot
   get up, that is a call.

**The long lie.** A person who has fallen and cannot get up, on a hard floor in a cold flat, deteriorates in ways
that have nothing to do with the fracture: cold, dehydration, pressure injury, fear. **That is the argument for the
phone in the pocket and for a fixed daily check-in call** — doc 07's mutual-aid habit applied inside the family.

---

## 5.7 Burns — the rule, and the open gap

### 5.7.1 What this program will and will not print

**Burn care is an open gap in this program's research, and it is labelled as one.** No authoritative free
burn-care page was retrieved — the CDC's burn pages were not reachable, the American Burn Association was not
reached, and the voluntary-aid organisation's first-aid pages refused access. What follows is **general first aid,
printed as general first aid and not as a cited protocol.** Three things are deliberately absent, because each is a
number a household would follow precisely and get wrong:

- **No irrigation volumes or durations.** "Cool it for X minutes under Y litres" is not printed here.
- **No dressing guidance.** Which dressing, how thick, whether to cover at all, whether to wrap — not printed.
- **No tetanus timing.** Whether a burn needs a booster, and how soon, is a clinical decision with a vaccination
  history attached.

### 5.7.2 The rule that survives without a source

> **Stop the burning, cool it with cool running water, cover it loosely, and get help for any burn that is large,
> deep, blistering, on the face, hands, feet, genitals or across a joint, or that came from electricity, chemicals,
> or being trapped in an enclosed space with smoke.**

The reasoning behind each clause is safe to print even where the numbers are not:

- **Stop the burning first.** Remove the source; cut clothing away rather than pulling it over the injury; do not
  peel anything stuck to skin. Smouldering fabric keeps burning the person while you look for the kit.
- **Cool running water — not ice, not butter, not toothpaste, not oil.** Ice causes further tissue injury; grease
  and ointments hold heat in and complicate the wound for whoever eventually cleans it.
- **Cover loosely and do not pop blisters.** A blister is a sterile dressing the body built; breaking it opens a
  wound in the week the pharmacy is shut.
- **The location rule is the one to memorise.** A small burn on a hand or across a joint, or on a face, is a bigger
  problem than a larger burn on a forearm, because of what those areas must do afterwards.
- **Electrical and chemical burns are hospital burns** even when they look trivial — an electrical burn has an exit
  wound somewhere you have not looked, and a chemical burn keeps burning after contact ends.
- **Smoke in an enclosed space is a lung injury.** A person who was in a fire in a closed room and is coughing or
  hoarse needs to be seen even with unmarked skin.

**Write the gap on the fridge card and ask the question at your course:** *"what do I do for a burn in this
house?"* The correct answer is that this program gives no protocol — you stop, cool, cover, and escalate — and the
household that knows it has a gap asks a person instead of trusting a page.

---

## 5.8 Wound care and infection signs

### 5.8.1 The verified core, and it is short

This is one of the few places in this chapter with an exact sourced instruction, printed verbatim because it is the
whole of what the sources support:

> CDC: **"Keep open wounds as clean as possible by washing well with soap and clean water."**
> CDC: **"Seek immediate medical care if a wound develops redness, swelling, or oozing."**

That is the entire wound-care protocol this program will print: **soap, clean water, and a hard escalation rule.**
Everything else people expect — irrigation volumes and pressures, which dressing, when to change it, whether to use
an antiseptic, when tetanus is due — is **not printed**, because none of it was verified, and the difference between
a good and a bad answer to "how much pressure" is a number nobody should take from a book.

**The practical consequences in an outage, which are editorial judgement and labelled as such:**

- **Clean water is the constraint, not soap.** A wound washed in water that has sat in a bucket for a week is a
  wound washed in whatever grew in the bucket. Doc 02's treated water and the household's lidded jug are the wound
  supply.
- **Wash your own hands first, and put gloves on.** The commonest way a small wound becomes a big one is a
  helper's hands.
- **Cover it**, so it stays clean in a house with no running water, an emergency toilet and a wet floor.
- **Check it daily, in daylight, with the dressing off, and write what you see.** In a normal week you would notice
  redness in the mirror. In week three, in a cold flat, with a person who does not want to be a nuisance, nobody
  looks — and that is how a wound that needed antibiotics on Tuesday becomes an admission on Saturday.

### 5.8.2 Infection signs — know them by heart

**Local, at the wound:** increasing redness spreading from the edges, swelling, warmth, pain getting worse rather
than better, pus or oozing, a red streak up the limb, or a bad smell.

**Systemic, the "go now" set:** fever, feeling cold and shivery, a fast heartbeat, vomiting, or **new confusion or
drowsiness in an older person** — and simply "they are not themselves." In an eighty-year-old, new confusion is an
infection sign as often as it is anything else, and it is the sign families dismiss as tiredness.

**The rule that resolves all of it:** CDC's wording is *seek immediate medical care* for redness, swelling or
oozing. In an outage "immediate" means **today**, and it means accepting that the trip is inconvenient — the
alternative is a wound that declares itself on day five, when the roads are worse.

### 5.8.3 The wounds that are not "just a cut"

**Anything from a bite**, animal or human. **A puncture through a shoe**, or any wound with dirt, gravel or fabric
driven into it. **A wound in a person with diabetes, poor circulation, or on a steroid or anticoagulant** — healing
is different and the threshold for being seen is lower. **A wound made by something dirty in a flood**, which doc 04
§4.6.7 already carries. **A wound over a joint, on a hand, on a foot, or on the face** — function and appearance
both matter, and both are worse when a household manages it alone.

---

## 5.9 Heat and cold illness

### 5.9.1 Heat — the three sentences, again

Doc 04 §4.3 and module `WTH-2` carry the full heat material, sourced to the National Weather Service. This chapter
repeats only what belongs in a first-aid context:

- **103 °F body temperature, or confusion, or slurred speech, or loss of consciousness = heat stroke = call 911
  now.** The source is explicit that **delay can be fatal.**
- **Do not give fluids to a suspected heat-stroke casualty.** A confused or unconscious person aspirates.
- **The skin sign does not tell you which it is.** "Hot and dry means heat stroke, sweating means only exhaustion"
  is wrong, and it kills people who were sweating.

**Heat exhaustion** — heavy sweating, weakness, cool pale clammy skin, fast weak pulse, cramps, dizziness, nausea,
headache, fainting — is cooled and watched, with the source's own escalation: **seek immediate medical attention if
the person vomits, if symptoms worsen, or if they last longer than an hour.**

### 5.9.2 Cold — recognition and the rule

Doc 04 §4.1.4 carries the cold emergency. The first-aid additions:

- **Hypothermia is a behaviour change before it is a temperature.** Slurred speech, clumsiness, confusion,
  withdrawal, or the person who has stopped shivering — **stopped shivering is worse, not better.**
- **Handle a severely cold person gently.** Rough movement of a deeply cold casualty can disturb the heart rhythm;
  that is why the rule is "warm the room, warm the person, call" rather than "rub the limbs."
- **No rubbing, no hot water, no alcohol, no cigarettes.** Rubbing frozen tissue damages it; a hot bath on a cold
  core drops the blood pressure; alcohol dilates surface vessels and loses core heat. **Warm the trunk first** —
  doc 04 §4.5's layering logic applied to rewarming.
- **Frostbite is a "do not thaw if it might refreeze" problem.** Thawing a foot and then walking on it to the
  shelter is worse than walking on it frozen.

---

## 5.10 Triage and red flags

### 5.10.1 The honest position

**No retrieved source in this program's research carries a comprehensive home triage algorithm**, and the
instruction to the writer was explicit: do not present one. So this section does not rank symptoms or teach a
decision tree. It prints **what the sources say**, and the rule that covers everything they do not:

> **When in doubt, call your local emergency number.** Not "wait an hour and see." Not "look it up." Call, describe
> what you see, and let a dispatcher who does this every day make the call.

### 5.10.2 The red flags this program can source

- **A wound with redness, swelling or oozing → seek immediate medical care** (CDC).
- **Carbon monoxide exposure that caused passing out** — CO "can make you pass out or kill you," and sleeping
  people "can die from CO poisoning before they have symptoms" (CDC). Anyone in a household where CO is suspected
  gets out and gets assessed; the alarm story is doc 04 §4.2.
- **Diarrhoeal illness that will not stay hydrated at home** — CDC directs people to the nearest health facility
  while continuing to keep them hydrated. This is `MED-3`'s escalation (doc 06 §6.3).
- **Overheating you cannot cool** — CDC: "know when to seek medical care."

### 5.10.3 The red flags stated as first-aid rule, not as a sourced algorithm

Each one is a call: **chest pain or pressure**, especially with sweating, nausea, breathlessness, or pain into the
arm or jaw · **any of the stroke screen** (§5.5) · **airway or breathing involvement in an allergic reaction**
(§5.4) · **choking with no air moving** (§5.3), or a choking that ended in unconsciousness · **bleeding that does
not stop under firm pressure** · **a fall with a suspected hip or head injury** (§5.6.3), and **any head knock in a
person on a blood thinner** · **a burn that is large, deep, blistering, on the face, hands, feet or a joint, or from
electricity or chemicals** (§5.7) · **new confusion in an older person**, treated as a medical event rather than
ageing · **a fever in an infant**, or any infant limp, feeding poorly or unusually sleepy.

**And anyone who stops breathing or has no pulse** — call, and start the CPR you were taught. **This program prints
no compression depth, no rate and no ratio**, and that is a decision, not an omission: those numbers belong to a
course where someone watches your hands on a manikin. What this chapter will print is the part people get wrong
before the course: **recognise it, call 911, put the phone on speaker, and do what the dispatcher tells you while
you wait.** A bystander doing dispatcher-guided compressions is enormously better than a bystander reading a page.

---

## 5.11 Module `MED-4` — Wound care and infection signs

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Pass level: CAN TEACH IT. Prerequisite: the kit in §5.1 is built and
> checked.**

**Objective.** Clean a wound correctly with soap and clean water, state the infection signs unprompted, and state
the escalation rule without being prompted. **Chapters.** `05 §5.8` · `05 §5.1` · `02` · `04 §4.6.7` · `10`.

**Drill — one wound, washed and watched.** One hour, with a real minor wound or a deliberate stand-in (a marked
area of skin the household treats as a wound for the exercise).

1. **Wash hands, gloves on, water and soap out** — and say out loud where the wound water comes from and why it is
   not the dishwater (doc 02, doc 04 §4.6.3).
2. **Wash the wound well with soap and clean water**, then cover it, saying what you are doing and why at each step.
3. **Recite the infection signs** — spreading redness, swelling, warmth, worsening pain, pus or oozing, a red
   streak, a bad smell; and the systemic set: fever, shivering, fast heartbeat, vomiting, **new confusion in an
   older person.**
4. **Recite the escalation verbatim:** *"Seek immediate medical care if a wound develops redness, swelling or
   oozing"* — and in an outage, immediate means today.
5. **State the four things this program does not print** and where they come from instead: irrigation volumes,
   dressing choice, antiseptic use, tetanus timing — the course instructor and a clinician.
6. **Start the wound log** in doc 10: date, what happened, what it looked like, who looked at it, the daily check
   time.

**Observable pass criteria — all five:** the wound is **washed with soap and clean water** with the water source
named; the **infection signs are recited unprompted**, local and systemic, including new confusion in an elder; the
**escalation sentence is stated verbatim** and "immediate" is defined as today; the household **names the four
things not printed here** and who to ask instead, rather than inventing them; and a **daily wound check with a
written log** is scheduled and owned by a named person.

**Assessment.** By an adult who did not run the drill, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; pass level **CAN TEACH IT**, because the person who cleans the wound may be the
person who is hurt. **Hours.** 1.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must know to fetch an adult, must not
touch a bleeding wound, and must be able to say where the kit is.**

---

## 5.12 Module `MED-6` — First aid that matters for this household

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical: pass level is CAN TEACH IT on the four recognition sets.
> Run this before `DRILL-1`, not after.**

**Objective.** Recognise and act on the four things most likely to kill a member of this household — heavy
bleeding, choking, anaphylaxis and stroke — and reduce the household's fall risk by walking the flat in the dark.
**Chapters.** `05 §5.2` · `05 §5.3` · `05 §5.4` · `05 §5.5` · `05 §5.6` · `05 §5.10` · `10`.

**Drill — the four sentences, the four searches, and the dark walk.** Two and a half hours.

1. **The four recognition sets, recited unprompted** by every adult, in their own words with the key words present:
   **bleeding** — press hard, do not lift to look, add on top, call early; **choking** — noise means air is moving,
   silence means call; **anaphylaxis** — airway or breathing means the injector first and the antihistamine never
   instead; **stroke** — face, arms, speech, and **the time last known well, written down.**
2. **The four searches, timed, in the dark.** Lights out, torch allowed; the household finds the first-aid kit, the
   auto-injector (one adult holds the trainer and reads the label's own instructions aloud), the medication list,
   and the phone. **Under two minutes, from the sleeping place.**
3. **The choking rehearsal.** With a volunteer, role-play the two states: a person coughing (stay, encourage, do not
   intervene) and a person silent (call, and start what the course taught). **No thrusts are practised on a person
   in this drill** — say out loud that the technique comes from the course, and that the infant version is a
   different method this program does not print.
4. **The falls walkthrough** (§5.6.2), in the dark, with the person at risk, on the route from the sleeping place to
   the toilet — and **the fixes written down**: which light, which rail, which object on the floor, which footwear,
   whether a commode goes in the warm room, and who checks in and at what time each day.
5. **The ten-second household brief.** Every adult states it out loud: *"if someone is bleeding heavily, one of us
   presses and one of us calls; if someone cannot speak, we call; if someone's face or arm or speech changes, we
   note the time and call; nobody is lifted off the floor before we know what hurts."*

**Observable pass criteria — all five:** all four **recognition sets are recited unprompted** with the key words
present, by every adult, and a hesitation on the anaphylaxis or stroke set is a re-teach, not a pass; **all four
items are found in the dark in under two minutes** and the auto-injector's label instructions are read aloud by an
adult who has held the trainer; the **choking role-play distinguishes the two states correctly** and the household
states, unprompted, that the technique and the infant method come from a course; the **falls walkthrough is
completed in the dark with the person at risk** and the fixes are **written down with a named owner**; and the
**ten-second brief is delivered by every adult** without reading it.

**Assessment.** By an adult who did not run the drill, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; pass level **CAN TEACH IT** on the four recognition sets — a skill that lives in one
head dies if that head is the one bleeding. **Hours.** 2.5.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must be able to say the address and the
emergency number out loud, unlock the door for help, fetch the kit, and stay with a hurt person and shout for an
adult — and must be told, plainly, that they are never expected to move a hurt person or stop bleeding
themselves.**

---

## 5.13 Closing the chapter

**What this chapter gives you is recognition, a kit, and an escalation rule.** You know that a wound is washed with
soap and clean water and that redness, swelling or oozing means medical care today, because CDC says exactly that.
You know that 103 °F or confusion means call now and hand them nothing to drink. You know the four-part stroke
screen, and that the time last known well is the fact that decides the outcome. You know that an antihistamine is
not anaphylaxis treatment and that the injector comes before the ambulance ride, not after. You know that falls are
the leading injury cause over 65 and that an outage manufactures them — dark stairs, wet floors, new loads,
backless slippers, a medication list that has not changed while everything else has.

**What this chapter does not give you is technique, and that is the design.** No compression depth or rate, no
tourniquet method, no thrust counts, no infant choking method, no splinting, no lifting a fallen person, no burn
irrigation volume, no dressing guidance, no tetanus timing. Each belongs to a person watching your hands — a local
in-person first-aid and CPR course, FEMA's free **IS-317.A** and **IS-22**, or the clinician on the phone. **Book
the course this month.** The rest of this program asks this household to store water and food and keep warm; this
chapter is the only one where the missing item is a skill in someone else's head, and the only way to store it is
to learn it and teach it to a second adult.

**And the last rule covers every gap above it.** When you are not sure — when the person is "a bit off," when the
wound is "probably fine," when the fall "didn't look that bad" — **call.** The call is free, the dispatcher does not
think you are wasting their time, and in a 90-day outage the cost of a needless call is nothing next to the cost of
the call you talked yourself out of.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version
1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a
source does not cover an item — burn care, CPR and tourniquet technique, irrigation volumes and pressures, dressing
guidance, tetanus timing, choking technique, a comprehensive triage algorithm, and any fall statistic beyond the
ranking in §5.6.1 — this document says so rather than supplying a number, and sends you to the person who does have
it: your course instructor, your clinician, or the emergency dispatcher.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
