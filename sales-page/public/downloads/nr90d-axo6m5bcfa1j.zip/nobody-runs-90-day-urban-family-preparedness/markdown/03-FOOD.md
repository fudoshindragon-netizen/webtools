# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 03 — FOOD

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This document does four jobs. It replaces the flat "2,000 calories a person" advice with the actual
federal table, because that flat number over-buys for a house of elderly women and under-buys for a
house of teenage boys, and either error is expensive. It turns calories into packages you can count
on a shelf. It gives the real shelf lives and the real food-safety times for a kitchen with no power.
And it handles the households a generic pantry quietly fails: an infant, a pet, a renal patient, a
diabetic, someone on a texture-modified diet.

It closes with modules **`FOD-1`** through **`FOD-3`**, which are Tier 1 of the program. Nothing
here is finished by reading it.

---

## 3.1 Why the flat 2,000 is wrong in both directions

The number everyone quotes is **2,000 calories per person per day**. It comes from a real place — it
is the reference intake the U.S. government prints on the Nutrition Facts label, which is why a
buyer can check any package against it without a calculator. It is also, for planning a household's
food store, wrong in both directions at once.

USDA and HHS publish calorie needs by age, sex and activity level in *Dietary Guidelines for
Americans, 2020–2025*, Appendix 2, Table A2-2. The footnote that makes that table usable here is
this one, quoted exactly:

> "**Sedentary** means a lifestyle that includes only the physical activity of independent living."

That is a word-for-word description of a household sheltering in place through a grid outage. **Use
the sedentary column.** It is also the lowest band the federal government publishes, which makes it
the defensible floor for planning.

**Downward.** The *Dietary Guidelines* states plainly that "due to reductions in basal metabolic rate
that occur with aging, calorie needs generally decrease for adults as they age." A sedentary
**woman aged 76 or over needs 1,600 calories**, not 2,000. A house of three elderly women planned at
the flat 2,000 buys **25% more food than it needs** — and in an apartment, that 25% is shelf space
and money that should have gone to water, medication or a CO alarm.

**Upward.** A sedentary **man aged 19–20 needs 2,600**. A **boy of 16–18 needs 2,400**. A household
of two young men and a teenage son planned at the flat 2,000 buys **21% less than it needs** — and
that error surfaces on day seventy-five, which is the worst possible day to find it.

**So the planning figure stays 2,000 for the household as a whole, and here is the honest reasoning.**
It is a reasonable average across a mixed household, it is checkable against any label, and **rounding
up is the only safe direction**: food stored and not eaten is a cost; food needed and not stored is a
crisis. But 2,000 is a *starting point for the household total*, not a per-person rule, and §3.2
gives you the table to correct it with.

**Two caveats that travel with every number in this chapter, and they are not small:**

1. **These are maintenance figures, not survival minimums.** The table estimates calories needed "to
   maintain energy balance." **No federal source states a minimum survival calorie level for
   emergency conditions, and this program does not invent one.** A household eating 1,200 calories
   a day for a week will lose weight and be hungry — a bad week, and **not** the same as crossing a
   cited starvation threshold. Do not read 2,000 as a line below which harm begins.
2. **Cold changes the maths, and no source here quantifies it.** These figures assume a normally
   heated home. A cold home raises energy needs — ordinary physiology, **stated as general reasoning,
   not as a *Dietary Guidelines* figure.** There is no sourced number for "extra calories in an
   unheated flat at 50 °F" and this program will not make one up. If your winter plan is one warm
   room and no heating, store more food than these tables give you and treat the surplus as warmth.

---

## 3.2 The tables — by person type

Source for every figure below: USDA & HHS, *Dietary Guidelines for Americans, 2020–2025*, Appendix 2,
Tables A2-1 (12–23 months), A2-2 (2 and older) and A2-3 (pregnancy and lactation). All sedentary, kcal
per day.

### 3.2.1 Adults

| Age | Male | Female |
|---|---|---|
| 19–20 | 2,600 | 2,000 |
| 21–25 | 2,400 | 2,000 |
| 26–30 | 2,400 | 1,800 |
| 31–35 | 2,400 | 1,800 |
| 36–40 | 2,400 | 1,800 |
| 41–45 | 2,200 | 1,800 |
| 46–50 | 2,200 | 1,800 |
| 51–55 | 2,200 | 1,600 |
| 56–60 | 2,200 | 1,600 |
| 61–65 | 2,000 | 1,600 |
| 66–70 | 2,000 | 1,600 |
| 71–75 | 2,000 | 1,600 |
| 76 and up | 2,000 | 1,600 |

### 3.2.2 Children and teenagers

| Age | Male | Female |
|---|---|---|
| 2 | 1,000 | 1,000 |
| 3 | 1,000 | 1,000 |
| 4 | 1,200 | 1,200 |
| 5 | 1,200 | 1,200 |
| 6 | 1,400 | 1,200 |
| 7 | 1,400 | 1,200 |
| 8 | 1,400 | 1,400 |
| 9 | 1,600 | 1,400 |
| 10 | 1,600 | 1,400 |
| 11 | 1,800 | 1,600 |
| 12 | 1,800 | 1,600 |
| 13 | 2,000 | 1,600 |
| 14 | 2,000 | 1,800 |
| 15 | 2,200 | 1,800 |
| 16 | 2,400 | 1,800 |
| 17 | 2,400 | 1,800 |
| 18 | 2,400 | 1,800 |

### 3.2.3 Toddlers 12–23 months

| Age | Male | Female |
|---|---|---|
| 12 months | 800 | 800 |
| 15 months | 900 | 800 |
| 18 months | 1,000 | 900 |
| 21–23 months | 1,000 | 1,000 |

**A toddler is not a small adult and the arithmetic is not a rounding.** At 800–1,000 kcal a day a
12-month-old eats roughly **40% of an adult male's intake** while occupying a fraction of the space.
A pantry built at "2,000 each" over-buys enormously for toddlers, which matters because toddler food
has the shortest shelf life in the house and the least substitutability.

### 3.2.4 Pregnancy and lactation — additions to the mother's own figure

| Stage | Additional kcal/day |
|---|---|
| 1st trimester | **+0** |
| 2nd trimester | **+340** |
| 3rd trimester | **+452** |
| Lactation, first 6 months | **+330** |
| Lactation, second 6 months | **+400** |

**Why this belongs in a preparedness document.** A household that plans ninety days without noticing
that one member is seven months pregnant has under-planned by about **40,000 calories** — and has
also under-planned water and, more seriously, the medical picture. `BAS-1`, the household roster, is
where this gets caught. If it was not caught there, catch it here.

---

## 3.3 The 90-day arithmetic

**Per adult at the flat figure: 2,000 × 90 = 180,000 calories.** That is the yardstick. Everything
below corrects it for who actually lives in the house.

### 3.3.1 Person-type totals for 90 days

| Person type | kcal/day | **90-day total** |
|---|---|---|
| Man 19–20 | 2,600 | **234,000** |
| Man 21–45 | 2,400 | **216,000** |
| Man 46–60 | 2,200 | **198,000** |
| Man 61+ | 2,000 | **180,000** |
| Woman 19–25 | 2,000 | **180,000** |
| Woman 26–50 | 1,800 | **162,000** |
| Woman 51+ | 1,600 | **144,000** |
| Teen boy 16–18 | 2,400 | **216,000** |
| Teen boy 13–15 | 2,000–2,200 | **180,000–198,000** |
| Teen girl 14–18 | 1,800 | **162,000** |
| Teen girl 11–13 | 1,600 | **144,000** |
| Child 9–10, boy | 1,600 | **144,000** |
| Child 9–10, girl | 1,400 | **126,000** |
| Child 6–8, boy | 1,400 | **126,000** |
| Child 6–8, girl | 1,200–1,400 | **108,000–126,000** |
| Child 4–5 | 1,200 | **108,000** |
| Child 2–3 | 1,000 | **90,000** |
| Toddler 12–23 months | 800–1,000 | **72,000–90,000** |

### 3.3.2 Household A — the house of elderly people

**Two women aged 76+, one man aged 71–75.**

| Member | kcal/day |
|---|---|
| Woman, 76+ | 1,600 |
| Woman, 76+ | 1,600 |
| Man, 71–75 | 2,000 |
| **Household daily** | **5,200** |
| **× 90 days** | **468,000 kcal** |

**Compare it to the flat advice.** Three people at 2,000 is 6,000 a day, or **540,000 kcal for 90
days.** The flat rule over-buys this household by **72,000 calories — the equivalent of 36 adult-days
of food.**

That is not a rounding difference. It is roughly **two extra months of food for one person**,
purchased, carried up stairs, stored in a flat that does not have the shelf, and rotated on a
schedule — for people who will not eat it. In a household on a fixed income that is real money spent
on a problem that does not exist, and money not spent on the water, the medication continuity or the
CO alarm this household actually needs.

**This is the household the flat advice fails silently.** Nobody notices an over-buy. The food sits
there, gets rotated, gets eaten slowly, and the household believes it is prepared for ninety days when
in fact it is prepared for about a hundred and five and has no idea.

**The correct answer for Household A is 468,000 calories — and the honest footnote is that it should
be *raised* slightly anyway**, because two of the three members are over 76 and a 90-day outage for a
78-year-old is primarily a medication and warmth event, not a calorie event. Buy the 468,000, and
spend the 72,000 you saved on the things doc 06 and doc 04 are about.

### 3.3.3 Household B — the mixed household

**Two adults aged 35 (one male, one female), a girl aged 6, a boy aged 12.**

| Member | kcal/day |
|---|---|
| Man, 35 | 2,400 |
| Woman, 35 | 1,800 |
| Girl, 6 | 1,200 |
| Boy, 12 | 1,800 |
| **Household daily** | **7,200** |
| **× 90 days** | **648,000 kcal** |

The flat rule gives 4 × 2,000 = 8,000 a day, or 720,000 — an over-buy of 72,000 here too, for the
opposite reason: it over-buys the woman and the six-year-old while under-buying nobody much. The
total is close enough that the flat rule is defensible as a first approximation, which is exactly why
it survives as folklore.

### 3.3.4 Household C — the household the flat rule starves

**Two men aged 19 and 20, and a boy aged 16.**

| Member | kcal/day |
|---|---|
| Man, 19 | 2,600 |
| Man, 20 | 2,600 |
| Boy, 16 | 2,400 |
| **Household daily** | **7,600** |
| **× 90 days** | **684,000 kcal** |

The flat rule gives 3 × 2,000 = 6,000 a day, or **540,000 kcal — a shortfall of 144,000 calories,
which is 21% short, which is 18 days of food that is not in the house.**

Eighteen days of nothing, at the end of a ninety-day event, in a household of three young men who are
the most physically capable members and therefore the ones doing the carrying, the hauling and the
standing watch — and therefore the ones whose intake has risen, not fallen. **This is the failure mode
the flat rule creates, and it is silent until it is not.**

### 3.3.5 The rule, in one line

**Build the household total from the table, person by person, at sedentary. Do not multiply the
headcount by 2,000.** It is one page and ten minutes, and it is the highest-value correction in this
document.

---

## 3.4 From calories to packages — the label method

You have a number: 648,000 calories, or 468,000, or your own. How does it become food on a shelf?

**The method is division, and the divisor is on the package.**

> **Packages needed = total household calories ÷ calories per package.**

**Calories per package** comes off the **Nutrition Facts panel**: calories per serving × servings per
container. Every retail food package in the United States carries this. It is the one number in this
chapter you do not have to take on trust, because it is printed on the object in your hand.

**This program deliberately does not print a calorie value for any named food.** "A bag of rice has
X calories" is a food-composition claim needing its own source, and a number copied from a website
into a preparedness guide is a number nobody can check. The label is the source, and it is in your
kitchen.

**Worked example, using an illustrative package that states 1,600 calories per bag:**

> 180,000 (one adult, 90 days) ÷ 1,600 (calories per bag) = **112.5 bags.**

Substitute your real label number. **The method is what is being taught, not the 1,600.**

Three reasons this is worth the tedium. **It converts a feeling into a count** — "we have a good
amount of food" becomes "we have 31 days at this household's rate", and only the second tells you when
to act. **It exposes the single-category pantry** — a household with a hundred bags of rice has a
hundred bags of rice and no fat, no protein variety and no vitamin C, and counting by package makes
that visible before you eat it. And **it makes rotation possible**: a pantry you have counted is one
you can rotate oldest-first, which is the difference between a store and a museum.

### 3.4.1 The honest volume problem

A 90-day food store for four is **648,000 calories of food.** In retail packaging that is a volume
comparable to a large wardrobe — and most urban apartments do not have a spare wardrobe's worth of
space that is cool, dry and pest-free.

**So this program's pantry target is 30 days of full calories at the household's own rate, with the
90-day figure calculated and displayed next to it.** That is `FOD-1`. The gap between the two numbers
is not a failure; it is the most useful piece of information in the chapter, because it is the number
that tells you how long you can actually stay before the decision tree in doc 01 fires.

**Thirty days is achievable in an apartment. Ninety usually is not.** Most urban households cap out
somewhere between thirty and forty-five days for a family of four on volume grounds alone, and a
product that pretends otherwise is selling you a garage you do not have. What thirty days buys is the
single most valuable thing in a real event: **time to think, before hunger is doing the thinking.**

---

## 3.5 Building the pantry — three layers

Ready.gov's guidance is the foundation and it is deliberately modest: stock canned foods, dry mixes
and other staples that **"do not require refrigeration, cooking, water or special preparation."** That
is the standard every item in Layer 1 must meet.

### Layer 1 — the no-questions layer (72 hours, eaten straight from the packet)

**Question it answers:** *the power just went out and nobody has eaten.*

Everything here needs no cooking, no water, no fridge and no preparation. Ready.gov's own list is the
shopping list: ready-to-eat canned meats, fruits and vegetables; canned juices; non-perishable
pasteurised milk; food for infants. Add a **manual can opener**, which Ready.gov names explicitly and
which is the most commonly forgotten item in the entire field. This layer is not about nutrition. It
is about the first three days being boring instead of dramatic.

### Layer 2 — the pantry (30 days of full calories)

**Question it answers:** *we are staying, and there is no shop.*

This is the layer the calculator in §3.4 is for. It is built on staples that keep at room temperature
for a year or more, plus enough variety that people keep eating.

- **Grains** — rice, pasta, dry mixes. The bulk of the calories and the cheapest calories.
- **Canned protein** — meat, fish, poultry. Shelf-stable for years, and what stops a pantry being a
  punishment.
- **Canned and jarred vegetables and fruit** — the vitamin C and the fibre, and what a grain-only
  pantry lacks.
- **Fats** — vegetable oil, salad oil. **The weakest link in the whole store** (§3.6).
- **Milk** — dry milk and canned evaporated or condensed milk; Ready.gov names non-perishable
  pasteurised milk specifically.
- **Sugar and honey** — "indefinitely" and two years respectively, and they make everything else
  edible.
- **Salt and seasoning.** A pantry with no salt is a pantry people stop eating from.
- **Dry beans and lentils** — store them, rotate them, and see §3.6.2 for the honest gap.
- **A manual can opener.** Repeated because it is the item people forget.

### Layer 3 — the stretch (the honest gap)

**Question it answers:** *how long can we really stay?*

The difference between your 30-day Layer 2 and your 90-day calculated total. Write that number on the
pantry card. It is not a shopping target — for most urban households it is not purchasable — it is a
**decision input**. When stored days drop below your written trigger, the household moves to branch 2
or 3 of doc 01's decision tree, and does so on a number rather than a feeling.

### 3.5.1 Where it goes, and how it survives

**Cool, dry, dark** — heat and damp destroy stored food more than time does. **Off the floor and off
the outside wall**, because a damp wall ruins a pantry that would have been fine. **In pest-proof
containers**: rodents and pantry moths are the second-largest cause of pantry loss after moisture, so
decant grains and dry goods into rigid lidded containers. **Spread, not stacked** — food is far
lighter than water, but losing a whole store to one leak or one infestation in one cupboard is the
same outcome. **One shelf you can reach in the dark**, so the first night's food needs no torch. And
**a pantry card on the door**: total calories, days of supply, oldest item, next rotation date. That
card is a `FOD-1` pass requirement.

### 3.5.2 Rotation

**Oldest in front, newest at the back, every time you put shopping away.** That one habit is worth
more than any preservation technique. Rotate on a schedule: oils on the six-month clock, grains on the
one-to-two-year clock, canned goods on their printed dates. And cook from the store regularly — a meal
a week from the pantry keeps it a food store rather than an archaeological site, and teaches you how
the items actually cook before you need to know.

---

## 3.6 Shelf lives — the real numbers, and the myth

Source: Virginia Cooperative Extension (Virginia Tech / Virginia State University), *Food Storage
Guidelines for Consumers*, publication **348-960**.

**The most important line in that publication must travel with every number below:** "**The
shelf-life of food will depend upon the food itself, its packaging, the temperature, and the
humidity.**" Every figure here is a **typical** pantry figure at ordinary room temperature — not a
guarantee, not a promise, not a 25-year claim.

| Staple | Unopened, pantry | Opened |
|---|---|---|
| **White rice** | **2 years** | 1 year |
| **Brown rice** | **1 year** | 6 months |
| **Pasta** | **2 years** | 1 year |
| **Vegetable oils** | **6 months** | 3–5 months |
| **Salad oil** | 6–12 months | 4 months |
| **Dry milk** | **"may be stored in airtight containers for one year"** | — |
| **Canned, condensed or evaporated milk** | 1 year | — |
| **Canned vegetables** | **2–5 years** | — |
| **Canned fruit and fruit juices** | 12–18 months | — |
| **Canned meat, unopened** | **2–5 years** | — |
| **Canned fish** | 2–5 years | — |
| **Canned poultry** | 5 years | — |
| **Honey** | 2 years | — |
| **Sugar (granulated, brown, confectioners)** | **"Indefinitely"** | 18–24 months |

### 3.6.1 The weak link is oil, not grain

Read the table again and notice which row is short. **Vegetable oil: 6 months unopened.** Not two
years. Six months.

**This is the most useful derived insight in the chapter, and it is a derivation, not a quote:** a
90-day pantry built on rice and pasta with a year's worth of oil is a *fine* pantry. The same pantry
with three-year-old oil is one that tastes rancid, whose fat-soluble vitamins are gone, and which
people will refuse to eat at exactly the moment eating matters most. **Rotate oil on the six-month
clock and everything else on the one-to-two-year clock.** Write the purchase date on the bottle.
Nothing else in the store needs that treatment.

**Brown rice** carries the same warning for the same reason — the publication notes its naturally
present oil can become rancid — which is why it is a one-year item and white rice is a two-year item.
If you are storing rice for a decade, you are storing white rice.

### 3.6.2 Two things this source does not cover, and this program will not guess

**Dry beans and legumes, and rolled oats, do not appear as rows in the 348-960 table.** There is no
shelf-life figure for them in the source.

**So this document prints no number for them.** What it says instead: **store them, rotate them, and
check them for insects and moisture.** A dry bean kept cool, dry and sealed keeps far better than one
that has been in a warm cupboard in a paper bag, and you will know by looking
and smelling. Do not accept a number from a website for these two items, including from this
program.

### 3.6.3 The "25-year shelf life" myth

**No source retrieved for this program supports multi-decade shelf lives for ordinary retail
staples.** Those claims belong to freeze-dried food in #10 cans and to mylar-and-oxygen-absorber
packaging — a *different product category* with its own manufacturer claims. Supermarket rice in its
original bag does not share them. If you want a 25-year store, buy a 25-year product and read its
manufacturer's claim; do not assume the bag in your cupboard is one.

---

## 3.7 No-fridge food safety — the exact FDA times

Source: U.S. FDA, *Food and Water Safety During Power Outages and Floods*. **Learn these five
numbers; they are the whole of this section.**

| Situation | FDA's figure |
|---|---|
| **Refrigerator, door kept closed** | **About 4 hours.** |
| **Full freezer, door closed** | **About 48 hours.** |
| **Half-full freezer, door closed** | **About 24 hours.** |
| **Discard threshold** | **Discard refrigerated food above 40 °F.** |
| **When to get coolers out** | **If the power will be out more than 4 hours.** |

Ready.gov's version of the same threshold: bacteria in food grow rapidly between **40 °F and 140 °F**.
That range is why 40 °F is the discard line and not a suggestion.

### 3.7.1 The procedure, in order

1. **Have an appliance thermometer in the fridge *and* the freezer, before the event.** FDA is
   explicit, and it is the difference between knowing and guessing. Two cheap thermometers are the
   highest-value food-safety purchase in this document.
2. **Keep the doors shut.** Every opening spends the cold. A fridge opened six times in four hours is
   not a four-hour fridge.
3. **Outage of four hours or less, doors closed:** refrigerated food should be safe. Check the
   temperature anyway and **discard anything above 40 °F.**
4. **Outage longer than four hours:** coolers, and move what you can. Prioritise what you cannot
   replace — refrigerated medication (doc 06), infant formula, meat.
5. **Cook the thawing food first.** A freezer is a food supply being spent. A full freezer of meat
   that thaws and is thrown away is $100–300 of food and a morale event; the same meat cooked on day
   one is dinner for a week. This is a written requirement of the drill protocol in doc 00 §0.4 and
   doc 11.
6. **Refreeze with a thermometer:** if the freezer thermometer reads **40 °F or below**, the food is
   safe and may be refrozen.
7. **Refreeze without a thermometer:** FDA — you **"can't rely on appearance or odor."** If the food
   still contains **ice crystals**, or is **40 °F or below**, it is safe to refreeze.

### 3.7.2 The two mistakes people make

**Trusting their nose.** FDA says explicitly that you cannot rely on appearance or odour. Food that
smells fine can be well inside the danger range. **The thermometer decides. Nothing else decides.**

**The "just this once" exception.** A household that keeps one questionable item "because it would be
a shame to waste it" has traded a $5 piece of meat for two days of diarrhoeal illness in a household
with no running water and no pharmacy. The asymmetry is not close. **When in doubt, throw it out** —
and the standard is doubt, not proof.

### 3.7.3 What this means for the pantry

Two consequences worth stating because they are not obvious. **Layer 1 exists partly so that the
fridge decision is never a hunger decision** — if the only food in the house is in the fridge, people
open the fridge, and a household with three days of no-preparation food on a shelf will keep the door
shut. And **a can that has been through a flood is out even if it looks perfect**, because the seam is
where the contamination is; doc 04 covers the disposal side.

---

## 3.8 No-fuel meals

**The safety rule comes before the menu, and it is not negotiable:**

> **Cooking with no power happens outdoors or on a ventilated balcony only. Never indoors. Never a
> garage. Never a flooded basement.**

This is `FOD-2`, a Tier 1 life-critical module, because the most foreseeable death in this entire
program is a household that is cold and hungry and lights a camp stove in a sealed kitchen. CDC's
list is unambiguous: never burn charcoal indoors; never use a portable gas camp stove indoors; never
use a flameless chemical heater indoors; never heat the home with a gas oven; never run a generator
indoors or in a garage **even with the doors and windows open**; and operate a generator outdoors
**more than 20 feet from windows, doors and vents.** And the ordering rule from doc 00: **`CO-1` — CO
alarms installed and tested — is a prerequisite before any combustion anywhere in this program.** No
exceptions, no "just to boil water".

### 3.8.1 The no-fuel menu, honestly framed

**What is verified:** Ready.gov directs households to staples that need **no refrigeration, no
cooking, no water and no special preparation**. That is the entire sourced basis for a no-fuel meal
plan, and it is enough to build menus from.

**What is not verified, and this program will not invent:** any specific no-cook menu, any
fuel-per-meal budget, and any canned-heat or stove safety guidance beyond the "outdoors only" rule.
**Do not expect a sourced calorie figure per meal here, because there isn't one.**

What you can build from the verified categories is a rotation of meals that are assembled rather than
cooked: **canned meat or fish + canned vegetable + canned fruit** (three cans, one bowl, no heat);
**canned juice and non-perishable pasteurised milk** as the drink and the dairy; **ready-to-eat cereal
or crackers with dry milk** where water allows mixing; **canned soup eaten cold** — not pleasant, and
entirely safe, and after three days of cold tins "not pleasant" stops registering; and **infant food
from the jar**, for the infant, with nothing substituted for it.

**The rotation matters more than the recipe.** A no-fuel plan that is the same three tins for ninety
days is a morale collapse by day twelve. Build a two-week rotation and accept that the second week
will be worse than the first.

### 3.8.2 The one hot meal a day, if you have fuel and a balcony

A household with a camp stove, fuel and a ventilated balcony can produce **one hot meal a day**, and
that single hot meal is worth more to morale than the calories suggest. **One pot, one boil**: boil
water once, cook the grain or pasta first, use the same water for a soup, then pour the rest into a
flask as a hot drink. **Soak instead of cook where you can** — dry goods soften in cold water given
hours, and overnight soaking saves fuel. **Cook for two days at once** and reheat only what you eat;
that halves fuel and halves the number of times somebody stands over a flame. And **never leave a
burning stove unattended**, or take a lit stove back inside "just to finish it".

**Doc 11 covers fuel quantities and storage; doc 04 covers the CO rules in full. Neither is optional
reading before this drill.**

---

## 3.9 The households a generic pantry fails

**Read this framing first: no federal source retrieved for this document gives emergency
food-storage or substitution guidance by therapeutic diet.** There is no sourced table of "if renal,
substitute X for Y", and this program does not publish one.

So this section names what changes, what to ask a clinician, and the small number of hard rules that
are not negotiable regardless. **For anything with a therapeutic diet or a food allergy, build the
90-day list with your own clinician or dietitian.** That is not a disclaimer, it is the instruction.

### 3.9.1 Infants

**What is verified.** Ready.gov's food list includes **"food for infants"**, and its food page states:
**"Use ready-to-feed formula. If you must mix infant formula use bottled water or boiled water as a
last resort."** CDC separately lists **"make baby formula"** among the things you must not do with
water you know or suspect is unsafe.

**The hard rules.** **Ready-to-feed formula is the emergency default** — it needs no water and no
mixing, which is exactly what you want in a household where water is the constraint. **Never dilute
formula to stretch it**: watery formula starves an infant of calories and electrolytes. (That specific
warning is not carried by a retrieved citation in this program, which is why the sourced
instruction — ready-to-feed, and bottled or boiled water if you must mix — is what is printed
instead.) **Formula is not a water substitute and water is not a formula substitute**; do not give an
infant under six months plain water. **And this document does not give infant feeding advice beyond
that** — follow your paediatrician and the formula label. Infant feeding in an emergency is a
specialist area, and the sources here stop where the specialist area begins. **Stock the formula
before the infant food** and count tins against days, because a tin is a fixed number of feeds and
there is no substitution.

### 3.9.2 Pets

**What is verified.** Ready.gov's kit list includes **"pet food and extra water."**

**What that means for this program's arithmetic, and it is a real gap worth naming:** the water
figures in doc 02 count **people**, not animals. A dog in a fourth-floor flat in a heat wave is a
significant water consumer and is not in the ¾-gallon-per-person figure. **Add pet water to your
water card as a separate line**, and pet food to the pantry count as a separate line — pet food is not
substitutable with human food, and a household that runs out faces a genuinely difficult decision.

Two more things. Shelters generally take **service animals only** — doc 01's branch 2 carries that
warning, and it is the reason a pet household should think about branch 3 earlier than a household
without one. And a pet that eats human food for a week will have digestive consequences you do not
want in a household with no running water.

### 3.9.3 Renal (kidney) diets

**What changes.** A renal diet restricts things a generic emergency pantry is built out of. Several
of the cheapest, longest-keeping staples — the grains and canned goods that carry the calories in
§3.5 — are exactly the items a renal diet is most careful with. A generic pantry is not automatically
safe for a renal patient, and in a 90-day event the patient cannot simply eat what is there.

**What to ask.** Ask your renal dietitian for **a written pantry list, in advance, of items that are
acceptable for you**, and build Layer 2 from that list rather than from this chapter's categories. Ask
specifically about canned versus fresh, which canned vegetables are acceptable, and portion limits on
the staples.

**The hard rule that crosses into doc 02.** A renal patient is often on a **fluid restriction**. **Do
not apply doc 02's ¾-gallon-per-person drinking figure to a person on a prescribed fluid
restriction.** Their number is the one their clinician gave them, and a household that "makes sure
Grandma drinks her water" in a heat wave can put a renal patient in hospital. Write the individual's
fluid limit on the water card next to the household total, in a different color.

### 3.9.4 Diabetic diets

**What changes — two different problems.** **The food itself:** a pantry built for maximum calories
per shelf-inch trends toward carbohydrate — rice, pasta, canned fruit, juice, sugar — and that is not
a diet a diabetic patient can simply switch to for ninety days. **Ask your diabetes team for a
written acceptable-food list before you buy**, and stock from it specifically; "healthy pantry food"
and "diabetic-safe pantry food" are not the same set.

**And the medication, which is more dangerous.** A diabetic patient whose food intake changes
significantly while their insulin dose stays the same is at risk of hypoglycaemia — and that is
exactly the scenario a 90-day outage creates: less food, different food, more physical work,
unpredictable timing.

**The hard rules.** **Never change an insulin or medication dose to match a changed diet without a
clinician** — not on your own judgement, not by rule of thumb, not because a neighbor's mother did
it. **Insulin needs to be kept cool, and that is a doc 06 problem** (`MED-2`) more than a doc 03 one,
but it belongs on this page too, because the food plan and the insulin plan are one plan and
separating them is how a household ends up with 90 days of rice and 10 days of insulin. **Keep a fast
sugar source in the pantry and in every bag**, and know that a household eating less than usual needs
it more, not less.

### 3.9.5 Dysphagia and texture-modified diets

**What changes.** A texture-modified diet — for someone who has had a stroke, has Parkinson's, or has
a swallowing difficulty — specifies the *texture* of what is eaten, not just its content. And a 90-day
pantry of dry grains, canned meat and crackers is **largely the wrong texture**.

**What to ask.** Get the **texture level your speech-language pathologist has specified** written
down, by level, before you shop (these are often recorded as an IDDSI level). Then build the pantry
around foods you can actually bring to that texture with the equipment you will have with no power: a
blender that works off a battery or a hand-crank, or foods already at the right texture in the tin.

**Three practical consequences.** **Purée-capable food beats food that needs chewing** — canned
vegetables and soft fruit are your friends here; crackers and dry meat are not. **Thickening:** if
thin liquids are restricted you need a thickening agent in the store and you need to know the correct
consistency before you need it; ask your SLP which one and how much, because this program does not
publish consistencies. And **aspiration is the risk, not hunger** — a person on a texture-modified
diet given the wrong texture because it was what was available can aspirate, and aspiration pneumonia
in a household with no running water and no ambulance is a serious event. **If the right texture is
not available, that is a branch-2 trigger**, not something to improvise around. Write it into the
decision card.

### 3.9.6 Food allergies

The pantry must be built **around** the allergy, not adjusted after it. A household with a tree-nut or
shellfish allergy needs a store containing none of it, including in the "may contain" sense, because
in an emergency nobody can read every label twice while hungry. **Read the label on every new item as
it enters the store, and keep a written list of safe brands on the pantry door.** A substitute bought
by a neighbor with good intentions is the classic route to a reaction.

---

## 3.10 Module `FOD-1` — Build the pantry

> **Tier 1 — LIFE SUPPORT. The module that replaces a belief about food with a number.**

**Objective.** Calculate the household's real daily and 90-day calorie requirement person by person
from the federal table, build and count a pantry meeting **30 days at that rate**, display the gap to
90 days, and produce a pantry card stating total calories, days of supply, the oldest item and the
next rotation date.

**Chapters.** `03 §3.2`–`§3.6` · `03 §3.9` for any household with a special diet · `10` (the pantry
calculator and card) · `11` (sourcing and budget) · `01 §1.9` (the triggers the days-of-supply figure
feeds).

**Drill — calculate, buy, count, card.** Three hours, plus the shopping.

1. **Build the household total** from §3.2, person by person, at sedentary. Write each person's number
   down. Do not multiply the headcount by 2,000.
2. **Multiply by 90.** That is the household's 90-day requirement.
3. **Apply §3.9 first** if anyone is an infant, a pet, renal, diabetic, on a texture-modified diet, or
   allergic. Their list comes from their clinician, not from this chapter.
4. **Set the Layer 2 target at 30 days** at the household's own daily figure.
5. **Build Layer 1** — 72 hours of no-preparation food, plus the manual can opener.
6. **Buy and count Layer 2** using the label method (§3.4): calories per package off the Nutrition
   Facts panel; packages = calories needed ÷ calories per package.
7. **Record the oil dates** — purchase date in marker on every bottle — and set the six-month rotation
   reminder.
8. **Decant into pest-proof containers**, off the floor, off the outside wall.
9. **Fill in the pantry card:** total calories stored, days of supply at this household's rate, the gap
   to 90 days, the oldest item, the next rotation date.
10. **State the trigger:** at what days of supply does the household move to branch 2 or 3?

**Observable pass criteria — all seven:**

- A **written per-person calorie figure** exists for every household member, taken from the table, and
  the household total is the sum of those figures — not headcount × 2,000.
- The **90-day requirement is calculated and displayed.**
- Layer 1 exists and is **verified by inspection** to need no cooking, no water and no refrigeration —
  and the **manual can opener is present and demonstrated on a real can.**
- Layer 2 is **counted, not estimated**, and the count meets **30 days** at the household's rate.
- **Every oil container carries a purchase date**, and the six-month rotation is in the calendar.
- The **pantry card** is on the pantry door and states total calories, days of supply, the gap to 90
  days, the oldest item and the next rotation date.
- The household can state its **branch-2 trigger in days of supply**, in its own words.

**Assessment.** By an adult who did not build the pantry, or a neighbor/CERT witness in a
single-adult household. Rated **NOT YET / DEMONSTRATED / CAN TEACH IT**. Pass level: **DEMONSTRATED**.
The count is checked by physically opening the pantry and counting, not by asking.

**Realistic hours.** 3 hours including the arithmetic and the card; shopping is on top.

**Who must be able.** One adult to DEMONSTRATED. **Every adult must be able to state the household
total, the days of supply and the trigger** — because the trigger is what moves the household, and it
has to survive the person who calculated it.

---

## 3.11 Module `FOD-2` — Cook with no power

> **Tier 1 — LIFE SUPPORT. Life-critical. The pass level is CAN TEACH IT, and breaking the "outdoors
> only" rule is a hard fail.**

**Objective.** Produce one hot meal for the household with no mains power, **outdoors or on a
ventilated balcony only**, with CO alarms installed and tested first, and state aloud every place
cooking must never happen.

**Chapters.** `03 §3.8` · `04` (CO and fire rules in full) · `11` (fuel) · `00 §0.4` (drill protocol)
· `FUE-1`.

**Prerequisites — hard gates.** **`CO-1` complete** (alarms installed and tested). **`FUE-1`
complete** (fuel safety, 10/10, no partial pass). **`FIR-1` complete** (extinguisher located, PASS
demonstrated). This module does not run before all three.

**Drill — one hot meal, outside, timed.** Ninety minutes.

1. **State the exclusion list aloud, unprompted:** never indoors; never a garage even with doors and
   windows open; never a flooded basement; never a stairwell; never a gas oven for heat; never
   charcoal indoors; never a flameless chemical heater indoors; and a generator never within 20 feet
   of a window, door or vent.
2. **Set up outdoors or on a ventilated balcony.** Show the assessor the placement and say why it is
   the placement.
3. **One pot, one boil.** Boil water once; cook the grain or pasta; use the same water for a soup; pour
   the rest into a flask.
4. **Produce a hot meal for every member of the household**, including any texture-modified or renal
   portion where §3.9 applies.
5. **Extinguish properly**, and show the extinguisher's location and the PASS sequence.
6. **Never leave it unattended** — state the rule and demonstrate it by not walking away.

**Observable pass criteria — all six, no partial pass:**

- **Cooking happens outdoors or on a ventilated balcony. Any indoor cooking is an automatic fail of
  the module, regardless of everything else done correctly.**
- The **full exclusion list is recited unprompted**, including the 20-foot generator rule and "never a
  garage even with the doors open".
- **A hot meal is produced for every household member**, with any special-diet portion correct.
- The **one-pot, one-boil method** is used and explained, and fuel use is visibly minimised.
- **Extinguishing is demonstrated**, the extinguisher located, and PASS recited.
- The stove is **never left unattended**, demonstrated rather than stated.

**Assessment.** By an adult who did not cook, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. Pass level: **CAN TEACH IT** — the assessor asks the household to walk
a second adult through placement and the exclusion list, and marks the explanation.

**Realistic hours.** 1.5 hours, plus the three prerequisite modules.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must be able to state that
the stove lives outside and that they never touch it**, and must know to fetch an adult. No child
operates any stove, ever, in this program.

---

## 3.12 Module `FOD-3` — Keep food safe with no fridge

> **Tier 1 — LIFE SUPPORT. Life-critical: the pass level is CAN TEACH IT. The five FDA numbers are
> the whole module.**

**Objective.** Recite the FDA time-and-temperature figures from memory, apply them to a real fridge
and freezer, make and defend the discard decision on a real item, and state the ice-crystal refreeze
rule correctly.

**Chapters.** `03 §3.7` · `04` (flood and sanitation, for disposal) · `06` (refrigerated medication) ·
`10` (the fridge card).

**Drill — simulate, measure, decide.** One hour, with the fridge door open and a thermometer in your
hand.

1. **Recite the five numbers** before touching anything: **4 hours** fridge door closed; **48 hours**
   full freezer; **24 hours** half-full freezer; **40 °F** discard line; **coolers out if the outage
   will exceed 4 hours.**
2. **Show the appliance thermometers** — one in the fridge, one in the freezer — and confirm both read
   correctly now.
3. **Walk the fridge and name the priority order** for what gets eaten first and what moves to a
   cooler.
4. **Name the "cook the thawing food first" plan** for your own freezer, and write it down: which item,
   cooked how, on which day, by whom.
5. **The discard decision.** The assessor presents an item and a thermometer reading. The household
   decides, states the number it is deciding against, and — where the reading is above 40 °F —
   discards it without negotiation.
6. **State the refreeze rule both ways:** with a thermometer, **40 °F or below = safe to refreeze**;
   without one, **ice crystals or 40 °F or below = safe to refreeze** — and **you cannot rely on
   appearance or odour.**
7. **State where refrigerated medication goes** if the outage exceeds four hours (doc 06).

**Observable pass criteria — all six:**

- **All five FDA figures recited from memory, correctly**, with no prompting: 4 h, 48 h, 24 h, 40 °F,
  coolers at 4 h.
- **Both appliance thermometers present and working**, verified by the assessor.
- A **written "cook the thawing food first" plan** exists for this household's own freezer, naming
  items and order.
- The **discard decision is made correctly** on a presented item, and the household states that it is
  deciding against a number and not against a smell.
- The **refreeze rule is stated correctly in both forms**, including "you cannot rely on appearance or
  odour."
- The household can state, unprompted, that **food above 40 °F is discarded** and that this is not
  negotiable in a household with no running water.

**Assessment.** By an adult who did not run the drill, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. Pass level: **CAN TEACH IT** — the assessor asks for the five numbers
to be taught to a second person, and a hesitation on any one of them is a re-teach, not a pass.

**Realistic hours.** 1 hour. Run it in week 1, before the 72-hour drill, so the drill does not cost
$100–300 of food.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must know the number 40 and
know that food that has been warm is not eaten.**

---

## 3.13 Closing the food chapter

Three things should be true of a household that has finished this chapter.

**It knows its own number.** Not "2,000 calories each" as a slogan, but a per-person figure from the
federal table, a household total, a count of packages on the shelf, and a days-of-supply figure on the
pantry door. A house of three people over seventy that knows it needs 468,000 calories is better
prepared than a house that bought 540,000 and believes it is covered — because only the first has
72,000 calories free to spend on water, medication and warmth.

**It has stopped confusing storage with safety.** Oil on a six-month clock, a thermometer in the
fridge, five FDA numbers known by heart, and one rule about where a stove may burn. Those four things
prevent more harm than any quantity of food.

**It has handled its own exceptions.** The infant's formula, the pet's food and water, the renal
patient's written list and fluid limit, the diabetic's insulin, the texture level from the
speech-language pathologist. A generic pantry is a starting point, and the households a generic pantry
quietly fails are the ones with the least margin to absorb the failure.

The honest gap has the same shape as the water chapter's: **ninety days of food for a family of four
is roughly a wardrobe's worth of calories, and most urban apartments do not have the wardrobe.** What
this program gives you is thirty days, honestly counted, a rotation that keeps it edible, safety
rules that keep it from poisoning you, and a written trigger that tells you when to stop relying on
it. Past that point the answer is not a bigger pantry. It is branch 2 or branch 3 of the decision you
already signed.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on.
This is version 1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected
figure is dated. Where a source does not cover an item — dry beans and oats for shelf life,
therapeutic diets for substitution — this document says so rather than supplying a number.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local
emergency number. Follow your local health authority's guidance over anything in this guide. Written
for US households.*
