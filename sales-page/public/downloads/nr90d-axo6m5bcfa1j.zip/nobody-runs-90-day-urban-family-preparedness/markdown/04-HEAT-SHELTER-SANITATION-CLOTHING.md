# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 04 — HEAT, SHELTER, SANITATION AND CLOTHING

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

What kills people in the first week of an outage, while the water and the food are still fine: a cold flat,
a generator in the wrong place, a fan pointed at an eighty-year-old woman on the hottest day of the year, a
building where the toilets stopped on day three and nobody said the word "leave."

This chapter covers warmth without utilities, carbon monoxide and fire, cooling in a heat wave, the shelter
chapter the first draft was missing (board-up, building-wide heat loss, seal-a-room, public shelter, pets,
above the sixth floor), clothing, and sanitation. It closes with modules **`WTH-1`**, **`WTH-2`**, **`SHE-1`**,
**`SHE-2`**, **`CLO-1`**, **`SAN-1`** and **`SAN-2`**. Nothing here is finished by reading it.

> **The sourcing rule.** Three of this chapter's four topics sit on gaps the research could not close. Where a
> figure is unavailable, this document says so plainly and sends you to the authority who has it — your fire
> department, your local health department, the appliance's own label. It does not invent one. A wrong
> clearance distance read at 2 a.m. is worse than a blank, because a blank makes you go and look.

---

## 4.1 Warmth without utilities

### 4.1.1 One room, not one house

Heating an apartment in an outage is impossible and was never the plan. The plan is to make **one room**
survivable and concentrate the household, water, food, light and sleeping in it. Heat leaves through surfaces,
and in a multi-unit block most of those surfaces are not yours — hallway wall, ceiling above, floor below,
party walls. You cannot insulate your way out of a building you do not control; you can shrink the volume you
keep warm.

**Choose the room in this order:** fewest exterior walls; no plumbing on an exterior wall if avoidable (a
frozen pipe on day nine turns a cold problem into a flood problem); where the slowest member already is (the
warm room follows the slowest member, not the reverse); a window that opens, for ventilation and a second way
out; and not the kitchen, if that is where the gas range is.

### 4.1.2 What actually makes a person cold indoors

Four things, and three are free:

- **Wet.** Water conducts heat away far faster than air. **Dry beats thick** — a dry cotton sweater beats a
  soaked wool one. Changing wet clothes comes ahead of adding blankets.
- **Moving air.** A draft at the back of the neck removes heat continuously: rolled towels at doors, a blanket
  over a single-glazed window, sheeting over a broken pane (§4.4.1). The opposite of a heat wave, where
  moving air is the tool.
- **Contact with cold surfaces.** A folded blanket to sit on costs nothing; bare feet on concrete is real heat
  loss, which is why §4.5.3 puts footwear by the bed.
- **Food.** Someone who has not eaten in eighteen hours gets cold faster, so the household eats whether or not
  anyone is hungry — the one place doc 03's calorie plan is an immediate safety issue.

**No target room temperature is printed here** — no verified household emergency target was retrieved, and a
number would read as a promise this book cannot keep. **Check the people, not the thermometer.**

### 4.1.3 What may run indoors, and what may never

**Never indoors, in any room, with any window or door open:**

- **A generator.** Not the flat, not the garage, not the basement, not the enclosed balcony, not "just for an
  hour." §4.2.2 has the exact wording and the 20-foot rule.
- **Charcoal, in any state.** CDC: "Never burn charcoal indoors. Burning charcoal — red, gray, black, or white
  — gives off CO."
- **A portable gas camp stove.** CDC: "Never use a portable gas camp stove indoors." That is the stove doc 03
  moved outdoors to cook. It is not a heater either.
- **A flameless chemical heater.** CDC: "Do not use portable flameless chemical heaters indoors." Sold as
  tent-safe; a tent is not a flat with a closed door and a sleeping child.
- **The gas oven or range, for heat.** CDC: "Never heat your house with a gas oven." Ready.gov: "Do not use a
  gas stove or oven to heat your home. It increases your risk of carbon monoxide poisoning." The commonest
  thing people do in a winter outage, and the one that produces the CO death.
- **Anything burning in an unvented stove or fireplace.** CDC: "Don't cook or burn anything on a stove or
  fireplace that isn't vented."
- **Candles.** This program's rule, not a sourced figure: **LED only.**

**What may run indoors** is the short list, and for most apartments the honest answer is nothing that burns.
What you have instead is **layers, one room, dry bedding and shared body heat** — §4.5 doing the work a heater
would otherwise do. A household that has passed `CLO-1` is warmer at 45 °F indoors than one with a kerosene
heater and no plan, and it has no CO risk at all.

### 4.1.4 The cold emergency

No core-temperature threshold is printed here: the verified clinical material retrieved covers heat illness
(§4.3, doc 05), not cold injury. What is printed matters more in a flat:

> **In a cold room, confusion or unusual drowsiness in an older person is a cold emergency until proven
> otherwise. Get them warm, get them dry, get medical help.**

The presentation is vague — "tired," "a bit confused" — and the people most at risk are the least likely to
say they are cold. **If two or more people in the same room are drowsy and confused at once, treat it as CO
(§4.2.4) until the alarm says otherwise.**

---

## 4.2 Carbon monoxide and fire

### 4.2.1 The scale, and the priority

CDC: **more than 400 Americans die each year from unintentional CO poisoning not linked to fires, more than
100,000 visit an emergency department, and more than 14,000 are hospitalized.** CO is, in CDC's words, "an
odorless, colorless gas that kills without warning." In this program's judgement, **generator placement and
"never charcoal indoors" are the highest-value safety content in the product — above water and above food.**
You run out of water over days and you act; you run out of air over minutes, asleep, with no sensation at all.

### 4.2.2 The 20-foot rule and the never-indoors rule

CDC's exact words — memorise both:

> **"Operate your generator outdoors more than 20 feet from windows, doors, and vents."**
>
> **"Never use a generator inside your home or garage, even if doors and windows are open."**

Read the second twice. **"Even if doors and windows are open"** is in the source because that is the
rationalisation that kills people: *it's ventilated, it's just the garage, the door is up.* A garage with the
door open is an indoor space; an attached garage shares a wall and a ceiling with the house, and CO goes
through both. The 20 feet is not decoration either: a generator at the property line under a neighbor's
bedroom window is the same hazard delivered to someone who has no idea it is happening. In an apartment
building the consequence is blunt: **a generator is not part of this household's plan.** There is nowhere on
a shared lot or balcony that satisfies the rule and does not endanger the people next door.

### 4.2.3 The alarm — all of `CO-1`

- Install **battery-operated or battery-backup CO detectors near every sleeping area.** The point is to wake
  people who are asleep, because — CDC — "People who are sleeping, drunk, or under the influence of other
  substances can die from CO poisoning before they have symptoms."
- **Check the batteries when the clocks change.** Prefer a detector with a **digital readout.**
- **Replace the detector per the manufacturer, or every 5 years.**
- **When using a generator, use a battery-powered or battery-backup CO detector in your home**, even though it
  is outside and more than 20 feet away.

**No ppm threshold and no exposure-time table is printed here.** No source retrieved states one, set-points are
built into listed devices and vary by model, and a household cannot measure ppm anyway. The instruction is not
a number:

> **The alarm sounds → everyone outside → call the fire department from outside. Nobody goes back in to open a
> window.**

### 4.2.4 The "whole household has the flu" rule

CDC's symptom list: "headache, dizziness, weakness, upset stomach, vomiting, chest pain, and confusion. CO
symptoms are often described as 'flu-like.'" That word is why this rule exists:

> **If several people in the same home develop headache, dizziness, nausea or confusion at the same time, in
> cold weather, in an outage, that is a CO alarm until proven otherwise. Everyone outside, then call for help
> from outside.**

Flu spreads over days and does not hit four people in an hour. CO hits everyone in the room at once, because
they are all breathing the same air. Cheapest diagnostic sentence in the chapter.

### 4.2.5 Fire: what this document will not print, and why

The research could not retrieve verified NFPA or CPSC material on **candle safety, fire-extinguisher selection
and placement, or generator backfeed** — NFPA's standards are paywalled and the CPSC safety pages returned
"page not found." So:

- **No extinguisher specification appears here** — no size, rating, placement distance or count per floor.
  **Ask your fire department.** Most run public education lines and will tell you what to buy for your
  building.
- **No candle rules beyond "don't."** The answer is LED, and that needs no citation.
- **No backfeed instructions at all.** What follows is general electrical-safety reasoning, labelled as such:
  a generator wired into the house without a proper transfer switch can energise wiring a utility worker
  believes is dead, and can back-feed the building's shared supply. **Have a licensed electrician install a
  transfer switch. Do not improvise a connection, and do not make one as a drill.**

What this document does say about fire, and will defend: **locate the extinguisher now** and read its own
label, which is the authority for that device; it is for **a fire the size of a wastebasket, behind you, with a
clear way out**, and anything bigger is a "get everyone out and call" fire; **PASS** — pull, aim, squeeze,
sweep — is the mnemonic fire services teach, a memory aid rather than a specification; **sleep with a clear
path to the door**, because in a blackout the path you cannot see is the path you fall over; and **no open
flame, no smoking indoors, no refuelling anything hot** — let a generator or stove cool, and refuel outdoors.

---

## 4.3 Cooling in a heat wave

### 4.3.1 The fan rule — 90 °F

Two federal agencies, the same fact:

> **CDC:** "Use fans, but **only if indoor temperatures are less than 90 °F**. In temperatures above 90 °F, a
> fan can increase body temperature."
>
> **National Weather Service:** "Use fan if heat index temperatures are below the high 90s. A fan can make you
> hotter at higher temperatures."

A fan cools by moving air across sweating skin, speeding evaporation. Once the air is hotter than your skin,
moving more of it across you adds heat faster than evaporation removes it, and the fan becomes a convection
oven with a cord. Which is why the household most likely to be harmed is the one that leaves it pointed at a
sleeping elder all afternoon on the worst day.

**Above 90 °F indoors, do this instead:** close windows and shades on the sun side by day, open them at night
when outside air is cooler; **wet the skin rather than blowing air at it** — cool damp cloth on neck, wrists
and forehead, a tepid sponge, feet in a basin; cut heat production indoors (no oven, no incandescent lighting,
no exercise, no hot showers); drink, and check that urine is light yellow or clear (CDC: "regardless of how
active you are"); move down and to the north side, the lowest and least-sunlit floor, and sleep there; and get
out in the afternoon — library, mall, cooling center — which is not defeat but the correct use of a building
you do not control.

### 4.3.2 Recognition — and the rule people get wrong

The cut-offs are NOAA/National Weather Service; doc 05 carries them in full. Three matter here:

1. **Body temperature above 103 °F, or confusion, or slurred speech, or loss of consciousness = heat stroke =
   call now.** NWS: "Call 911 or get the victim to a hospital immediately. Heat stroke is a severe medical
   emergency. **Delay can be fatal.**"
2. **Do NOT give fluids to a suspected heat-stroke casualty.** NWS says so explicitly; a confused or
   unconscious person aspirates. This contradicts every instinct in the room.
3. **The skin sign does not discriminate.** NWS lists "hot, red, **dry or damp** skin." The folk rule — hot
   and dry means heat stroke, sweating means only exhaustion — is **wrong** and kills by delay. Confusion and
   temperature are the discriminators.

**Heat exhaustion** — heavy sweating, weakness, cool pale clammy skin, fast weak pulse, cramps, dizziness,
nausea, headache, fainting — is a cool-them-down-and-watch problem: cooler place, loose clothing, cool wet
cloths, sips of water. NWS: "Seek immediate medical attention if the person vomits, symptoms worsen or last
longer than 1 hour."

### 4.3.3 Who is at risk, and the medication rule

CDC names the higher-risk groups: asthma (especially children), heart disease, pregnant women, **people 65 and
older**, people working or exercising outside, **infants and young children** — "People over 65 years of age
and young children may need to take additional actions on hot days." Two consequences: **check on the person
who lives alone**, and **look at the elder in your own flat rather than asking.** "Are you too hot?" gets "I'm
fine" from someone whose judgment the heat is degrading. Look: flushed, confused, not sweating when everyone
else is, unusually quiet.

On medicines, CDC is short and absolute: "Many medicines can make you dehydrated or overheated on hot days.
Also, some medicines need to be kept out of hot places." / **"Don't stop or change your medicines until you
talk to your doctor."** / "Have a plan for what to do with refrigerated medications and electronic medical
devices" — that is `MED-2`, built in doc 06.

### 4.3.4 Where to go

CDC points households to dial **2-1-1**, to the local health department or emergency management agency, or to
the National Center for Healthy Housing's by-state listing. Ready.gov: "Go to a community location with power
if heat or cold is extreme"; "Check with local officials about heating and cooling locations open near you."
For a household with an elder and no AC, a cooling center is not a last resort — it is **branch 2 of the
decision tree** (§4.4.4). Find out which one is open and how you get there a week before the heat wave.

---

## 4.4 The shelter chapter

The first draft had no shelter chapter. That was the gap the owner noticed. It is here because "shelter" is
four different problems people solve with one word, and solving the wrong one wastes the days you needed: cold
with no heat and the building intact (one warm room, §4.1 and §4.5); heat with no AC (passive cooling, §4.3);
**the building has failed** — no water upstairs, no lift, no waste removal, a broken window; and **an airborne
hazard outside** — smoke, a chemical release, a shelter-in-place order. Prepare for the first two and be
surprised by the last two, and you lose. The third is what actually happens in a long urban outage, and it is
why "sanitation untenable" is a trigger in the decision tree rather than an inconvenience.

### 4.4.1 Board-up and sheeting — the rule, and the missing figure

A broken window in January is a hole in your heating system; on a ground floor it is also a security problem
(doc 07). You are closing a hole, not building a fortification.

1. **Make the hole safe before you make it warm.** Glass out, edges swept, the frame checked for shards in the
   channel. Shoes on (§4.5.3) — that injury is the one that actually happens.
2. **Close it in two layers.** A rigid layer (plywood, a board, a cutting board — something that stops wind and
   a hand) fixed to the frame, then plastic over it on the **inside**, taped on all four edges. Plastic is the
   air seal; the board is the structure. One without the other is half a job.
3. **Seal the perimeter, not the middle.** Drafts come round the edge; tape the full perimeter, and tape to the
   casing or wall rather than to a loose board.
4. **Keep one window in the room operable.** A fully sealed room has no second way out and no way to vent a CO
   event or a fire. Hard rule.
5. **Tell the landlord in writing, the same day, and photograph it.** In a multi-unit building the envelope is
   the landlord's responsibility and your board-up is temporary, not a repair (doc 07).
6. **Do not board an egress window** in a bedroom people sleep in if there is any alternative. If there is none,
   board it, keep a hammer in the room, and treat it as a room you leave in a hurry.

**No board thickness, screw length, sheeting thickness, tape width or fastener count is printed here.** None was
source-verified and the right answer depends on the window. **Ask your fire department's public education line
or your building department** what counts as a secure opening in your jurisdiction — which is what matters if
an inspector or an insurer ever looks at it.

### 4.4.2 Building-wide heat loss in a multi-unit block

**In an apartment your heat is not entirely yours, and neither is your cold.**

- **The building is a shared thermal system.** In a cold outage the flats around you go cold too; your ceiling
  loses heat to the flat above, your floor to the flat below, your party walls to the neighbors. Five of your
  six surfaces are not yours to insulate. **The plan is still one room.**
- **Common areas are the leak.** A stairwell with a propped fire door is a chimney; a lobby door that does not
  close is a hole. Report it; if the landlord does nothing, doc 07's escalation is the answer, not a
  confrontation in the hallway.
- **Shared pipes are the second hazard.** Cold snaps burst pipes in the *building*; a burst riser floods the
  flats below and takes the water for everyone. If the building loses heat and there is a way to keep one tap
  moving slowly, ask the super whether that is wanted; **never drain a shared system yourself** (§3.0).
- **Your neighbors' behavior is your heating.** One flat running a gas oven for heat puts CO into a shared
  building — which is why `SEC-3`, three neighbors' names and numbers (doc 07), is a *warmth* module as much as
  a security one: the neighbor who knows to knock is the one who finds the elder asleep in a cold flat.

### 4.4.3 Seal-a-room for an airborne hazard

When officials say shelter in place, the instruction is not "stay in the building." It is "get into one room,
close it off, stay there until told otherwise."

1. **Go in, not out.** Everyone and the pets into **one interior room** with as few windows as possible, ideally
   above ground level. For a hazard heavier than air, low rooms and basements are the wrong choice; for smoke,
   the lowest floor away from the fire is usually right. If the official notice names a floor, that notice beats
   this paragraph.
2. **Shut the building's air handling down.** Heating and cooling off, fireplace damper closed, fresh-air intake
   closed if you have one, vents in that room taped.
3. **Seal the gaps, not the field.** Door perimeter taped, a damp towel or tape along the bottom, window edges
   sealed. You are not building a gas-tight chamber; you are slowing infiltration, which buys the hours.
4. **Plastic over the opening**, taped on all four sides. **Pre-cut and pre-tape it before you need it**, because
   you will do this in the dark, in a hurry, with a frightened child.
5. **Keep the radio or phone on and wait for the all-clear.** You leave when officials say leave, not when the
   smell goes away. A shelter-in-place order ends by announcement, not by sensation.
6. **Know the triggers to abandon the room:** smoke inside it, a CO alarm, or an order to evacuate. Then you go,
   and you take the go-bag.

**No plastic thickness, square footage per person, tape count or "how long this works" figure is printed here** —
none was verified, and household sheeting is not a rated barrier anyway. **Ask your local emergency management
office** for the shelter-in-place kit they recommend for your area; many distribute one, and theirs is what your
officials will assume you have.

### 4.4.4 Public shelter, and pets

This is **branch 2**: a public shelter, a warming or cooling center, or a relative with power. Ready.gov: "**Most
public shelters allow only service animals.**" If you have a pet, "identify a place to stay that will accept
pets" **in advance** — a planning task, not a day-of task. **2-1-1** and local emergency management give you
shelter and cooling-center locations; look them up before the outage and write them on the decision card in doc
10. **What to bring** is not a new list: the go-bag from doc 08 plus the medication and device list from `BAS-2`.
**What a shelter is not:** a hotel. It is a gym floor with cots, strangers, noise, no privacy and shared toilets,
and for an elder with dementia or a child with sensory needs the honest calculation may be "a relative with
power, 40 minutes away" rather than "the shelter, 10 minutes away." Write that preference down while everyone is
calm.

**Pets.** The federal kit list includes **"pet food and extra water"** (Ready.gov, *Build A Kit*) — your pet is
on the list. Plan for it as you would a person: food, water, medication, a carrier, a leash, vaccination
records, and a photo of you with the animal in case you are separated. Then write two answers: one named place
that will take the animal (a friend, a boarding vet, a pet-friendly motel on the route in doc 08), and one
person who will take it if you must enter a shelter that will not. A household that has not answered this either
stays behind for the dog — a real and common decision — or abandons it in the flat.

### 4.4.5 Above the sixth floor — `SHE-2`'s reality

**Above roughly six floors, the taps die with the power.** City pressure is not enough to lift water to the top
of a tall building, so the building uses a booster pump to fill a roof tank or pressure system. When the power
goes, the pump stops, and the water in the pipes and the tank is all the water the upper floors have — a
one-time volume. Below the sixth floor, mains pressure often still reaches the tap; above it, often not. The
number is approximate and depends on the building and the city, but the planning assumption for a high-rise
household is **"the tap is a 72-hour source at best, then it is gone."**

Four consequences: **water goes upstairs before the outage** (doc 02's buffer is not optional in a high-rise,
and carrying water up six flights is a fit adult's job that gets harder every day); **waste has no exit**, which
is a building-wide sanitation event within days (§4.6.6) and is where the "sanitation untenable" trigger usually
fires; **the lift is gone, and with it the slowest member's mobility** (doc 08), so "we'll manage" is not a plan
for someone who cannot do stairs; and **pests arrive before the neighbors do** — seal your own food, report, and
treat the building's condition as information about when to leave. Know the management emergency number, know
whether the building has a generator and **what it actually powers** (usually lights and the fire system — not
the pump, not the lift), and put the question in writing.

---

## 4.5 The clothing chapter

Clothing is the only heating system that still works when the gas is off, and `CLO-1` is the cheapest module in
the program to pass.

### 4.5.1 Layering, and what each layer is for

Three layers, three jobs. The jobs matter more than the fibre.

- **Base layer — touches skin — must be dry and must not hold water.** It moves moisture away from the skin.
  Cotton is comfortable and terrible at this: it holds water against you and then chills you. Wool and
  synthetics keep working when damp, which is another argument for wool over 90 days.
- **Middle layer — traps air — is the insulation.** Fleece, wool sweater, down jacket, a second sweater. Air
  trapped and not moving is the insulator, which is why two thin layers beat one thick one. Looseness matters:
  a layer tight enough to compress the insulation stops working.
- **Outer layer — stops wind and water — is the shell.** Indoors in a cold flat that is often just a
  tight-woven jacket that stops the draft; outdoors in rain it is a waterproof shell.

**Three rules follow:** **dry beats thick** (change out of damp clothes before adding layers); **loose beats
tight** (tight clothing, shoes and gloves reduce insulation and restrict circulation); **head, neck, hands,
feet** (a hat and dry socks change a person's whole day).

### 4.5.2 Clothing as the household's heat plan

The point of `CLO-1` is not good gear. It is **enough clothing for every person, in one place, findable in the
dark**, so that the answer to "the heat is off" is a drawer and not a shopping trip. Doc 11 is explicit that
**thrift and estate sales are the best value for durables, and military surplus is good for wool and cold
layers and little else.**

**What each person needs, in the flat, not in a storage unit:** two base layers (so one can dry while the other
is worn), two insulating mid layers, one wind/water shell, hat, gloves, scarf or neck gaiter, more dry socks
than you think, and one complete dry change kept dry and reserved for the moment someone gets soaked. **No
temperature rating, clo value, gram weight or "rated to X °F" claim is printed here** — those come from
manufacturers and describe a garment, not a household.

### 4.5.3 Footwear by the bed

Every person sleeps with closed shoes, or at minimum hard-soled slippers, within reach of the bed.

- **Broken glass.** The commonest blackout injury after a window goes is a cut foot, and in an outage you cannot
  see the floor.
- **The 2 a.m. exit.** A fire alarm, CO alarm or a knock at the door is not a moment to hunt for shoes; bare
  feet on a stairwell in a smoke event is a burn and a fall risk at once.
- **Cold floors.** Bare feet on a cold floor is real heat loss, and for an elder with poor circulation it is the
  start of §4.1.4.
- **Falls.** Backless slippers are a trip hazard on stairs — hence closed shoes or hard-soled slippers.

Costs nothing, takes one sentence to teach a child, and is obvious only after it has gone wrong.

### 4.5.4 Elder-specific clothing

An older person in a cold flat is not just "more cold." Five things change, each with a clothing answer:

- **They feel cold less, and that is the danger.** Reduced sensation and circulation mean an elder may not
  notice a cold room or cold feet. **You check them; they will not report it.** Look at hands and feet.
- **They lose heat faster and generate less.** Layers go on *before* the room is cold.
- **Arthritis and buttons.** Buttons, zips, tight cuffs and laces are the enemy of cold hands. Choose
  **pull-on, loose, front-opening, large-fastener** clothing, and footwear they can put on alone. A garment they
  cannot get on is not a layer; it is a trip hazard on the floor.
- **Incontinence and damp.** A wet pad or wet clothing in a cold room is the fastest route to the cold
  emergency, so the changing routine is part of the warmth plan and the supplies belong in the warm room.
- **Falls.** Loose hems, long dressing gowns and unsupported slippers cause falls, and falls are the leading
  injury cause over 65 (doc 05). The garment that keeps them warm and the garment that trips them are often the
  same one. Hem it or replace it.

One line for the carer: **the coldest person is usually the one who moves least.** Put the blanket on the one in
the chair, not the one doing the lifting.

### 4.5.5 Children, and the 0 °C standard

Children lose heat faster because they are small, and they will not say they are cold while they are playing.
Two rules: **they wear what the adults wear**, and **the hat goes on indoors.**

`CLO-1` is written as: **dress the slowest member for 0 °C in five minutes from what is in the house.** 0 °C is
freezing — the point at which a cold flat becomes an outdoor problem. Five minutes is what you would actually
have if the heat failed at night. "From what is in the house" is what makes it real: no shopping, no borrowing,
no "we'd grab the coats from the car." If the household cannot do it, the fix is not a better jacket. It is a
labelled drawer.

---

## 4.6 Sanitation and hygiene

This is where a preparedness book is most tempted to be confident and most likely to be wrong, and it is also
the chapter that decides whether a household stays or leaves, because **ninety days of waste from five people
in an apartment is this plan's real failure point** (doc 11).

### 4.6.1 What the federal kit list actually contains

The only sanitation content the federal kit list verifies is a **supply list**, not a method. Ready.gov's *Build
A Kit* includes:

> **"moist towelettes, garbage bags and plastic ties (for personal sanitation)"**

plus **water — one gallon per person per day for several days, for drinking and sanitation** — a **wrench or
pliers to turn off utilities**, a **dust mask**, and **non-prescription medications** including
anti-diarrhoeal. That is it. That is what the government tells you to have. It does not tell you what to build
with it, and this document will not pretend otherwise.

**What the household should own, on the strength of the list alone:** heavy garbage bags and ties for at least
two weeks at household scale, moist towelettes, disposable gloves, soap, hand sanitizer at **60% alcohol or
more**, a large water jug, a bucket, and a lidded container. None of it requires a build.

### 4.6.2 Handwashing — the 20-second standard

The one sanitation behavior with a verified number, and the highest-return thing in the chapter.

> **CDC: "Wash your hands with soap and water for at least 20 seconds,"** especially at the key times when you
> are most likely to spread germs.

The key times for an outage household: after the toilet or the bucket; after changing a diaper or a pad; before
preparing food and before eating; after handling waste, rubbish or flood water; after caring for someone sick;
after coming in from outside.

**With what water?** CDC: use water **that has been boiled or disinfected** if local authorities or your doctor
recommend extra caution — doc 02's treated water is the handwashing water in that case, which is why doc 02's
buffer includes sanitation, not only drinking. **During a boil-water advisory**, CDC is more nuanced than most
people expect: "**it may be safe to wash hands with tap water**." A drinking-water advisory is not
automatically a handwashing prohibition. **Read the local notice and follow it.**

**With no soap and no safe water:** an alcohol-based sanitizer with **at least 60% alcohol** (CDC). But it "does
not eliminate all types of germs and might not remove" chemicals, and is **not a substitute for soap and water
when hands are visibly dirty.** Order of preference: soap and safe water; then sanitizer; then neither, which is
not acceptable.

### 4.6.3 The handwashing station

CDC: "If clean tap water is not available, **create a temporary handwashing station by using a large water
jug**."

A station, not a build: a jug with a spigot, or one you tip, on a chair or counter, soap beside it, a basin
underneath for runoff, paper towels or a clean cloth. Put it where the hands are — by the toilet, and by the
food. Two things make it work: **soap stays out and open**, and **the runoff has a destination decided in
advance** — the same decision as §4.6.5.

### 4.6.4 Dishwashing and laundry — what is not printed, and why

The research could not verify a minimal-water dishwashing method, bleach ratios for dishes, graywater rules,
menstrual-product management, or a diaper-management method. **So none is printed here** — because a made-up
bleach ratio for dishes is the kind of error that makes people sick. What is verified, and enough to run on:

- CDC: "Clean food preparation areas and kitchenware with soap and safe water and let dry completely before
  reuse." Soap, safe water, dry completely — the whole dishwashing rule this document will stand behind.
- CDC on diapers: "**Even a microscopic amount of poop can contain millions of germs.**" That is the risk
  statement; the method is your pediatrician's or health department's.
- **Ask your local health department** for the dishwashing, laundry, menstrual and diaper guidance they issue
  during a water emergency. Most publish it, and theirs is written for your water system.

### 4.6.5 Waste — the honest position

> **This document contains no toilet-building method, no waste volume per person per day, and no disposal
> rule. None of the three could be verified from a primary source, and a wrong method or a wrong disposal rule
> is worse than none at all.**
>
> **What you do instead: call your local health department, ask what is permitted in your jurisdiction, and
> write the answer on the decision card.** That call is the module.

Why the rule cannot be generalized: it depends on whether you are on a municipal sewer, a septic system or
neither; on whether the sewer is functioning; on state and local solid-waste rules; on your lease and your
building's rules; and on whether the jurisdiction has declared an emergency with its own temporary instructions.
A book cannot know any of that. Your health department can.

**Two things are certain and are printed:** **never into a storm drain** (a storm drain goes to a waterway, not
a treatment plant — the one disposal line that holds everywhere and needs no local knowledge), and **never into
a container that will hold food or water again**, nor the same container as drinking water. That second one is
not a regulation, it is the fecal-oral route.

### 4.6.6 "Sanitation untenable" — the trigger

The decision tree in doc 01 has three branches, and **"sanitation untenable" is an explicit trigger that fires
branch 2 or branch 3.** It is a trigger rather than a nuisance because it is the failure a household cannot fix
by trying harder. Written as things you can observe:

- **The building's waste system has failed and there is no permitted alternative** — not "the toilet is slow,"
  but the system is down and the health department has nothing for you.
- **The household cannot keep hands, food surfaces and waste separate** — the handwashing station cannot be
  maintained because the water is gone, or the waste is in the room where the food is.
- **Someone has diarrhea and the household cannot maintain hygiene around them.** CDC's response to diarrheal
  illness after a disaster is rehydration, safe water and getting to care; if you cannot do the first two at
  home, home is the wrong place. This is the medical version of the same trigger, and it belongs to doc 06 as
  well.
- **Waste is accumulating in a shared space** — hallway, stairwell, balcony, courtyard — where children and
  neighbors are. That is a building-level event: call the health department *and* the landlord, and start the
  move.
- **Pests have arrived.** Rodents and insects following waste is the visible sign that the building has crossed
  from uncomfortable to unsanitary, and one household cannot reverse it.

**Writing the trigger down in advance matters because it will fire on a day when nobody is thinking clearly.**
The decision card in doc 10 is pre-signed so the call is not made in a panic — and "we said we'd leave if X, and
X has happened" is a sentence that works on day four when everyone is exhausted.

### 4.6.7 Wounds

Waste and dirty water plus a small cut is how a minor injury becomes a hospital visit. CDC: "Keep open wounds as
clean as possible by washing well with soap and clean water," and **"Seek immediate medical care if a wound
develops redness, swelling, or oozing."** In an outage that means going early, because the pharmacy is shut and
the infection does not wait for it to reopen. Doc 05 carries wound care.

---

## 4.7 Module `WTH-1` — Warmth without utilities

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Pass level: CAN TEACH IT. Prerequisite: `CO-1` complete. Run against
> the §3.0 drill safety protocol.**

**Objective.** Establish one warm room, prove it is the right room, and recite the never-indoors list
unprompted. **Chapters.** `04 §4.1` · `04 §4.2.2` · `04 §4.2.3` · `03` · `10`.

**Drill — build the warm room, cold.** Two hours, run **before** the heating fails.

1. **Choose the room out loud** against the five criteria in §4.1.1, naming the room you rejected and why.
2. **Move the room's contents in**: bedding, water, 72 hours of food, light, medication, radio, charger, the
   waste plan — enough that a person could live there three days.
3. **Stop the drafts** — rolled towels at the door, blanket over the window, the gap under the door closed. Show
   it, do not describe it.
4. **Recite the never-indoors list unprompted** (generator, charcoal, portable gas stove, flameless heater, gas
   oven, unvented stove, candles), including "never in a garage even with the doors open" and the 20-foot rule,
   and state the cold-emergency rule (§4.1.4). **Show and test the CO alarm.**

**Observable pass criteria — all five:** the **chosen room meets the criteria and the choice is explained**,
including the rejected room; **the room is furnished for 72 hours** and verified by walking it; **drafts are
physically stopped**, demonstrated not described; **the never-indoors list is recited unprompted** and the
household states that **nothing that burns runs indoors**; **the CO alarm is present, tested and audible** from
the sleeping area.

**Assessment.** By an adult who did not build the room, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; pass level **CAN TEACH IT** — the room choice and the list must be taught to a
second adult. **Hours.** 2.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must state that the stove and the
generator stay outside and that they never touch either**, and know the warm room by name.

---

## 4.8 Module `WTH-2` — Heat illness and the heat-wave plan

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical: pass level is CAN TEACH IT. Season gate: never run this
> drill in a heat wave (§3.0).**

**Objective.** Recite the 103 °F rule and the "no fluids" rule, state the fan rule correctly, and produce a
written heat-wave plan. **Chapters.** `04 §4.3` · `05` · `06` · `10`.

**Drill — the plan and the three sentences.** Two hours, indoors, in ordinary weather.

1. **Recite the three sentences**: **103 °F or confusion or slurred speech or unconscious = heat stroke = call
   now, and delay can be fatal**; **do not give fluids to a suspected heat-stroke casualty**; **hot-and-dry
   versus hot-and-sweaty does not tell you which it is.**
2. **State the fan rule both ways**: fans only **below 90 °F indoors**; **above 90 °F a fan can raise body
   temperature** — and name the replacements (shades closed by day, windows open at night, wet cloths on neck
   and wrists, feet in a basin, no cooking, lowest floor, north side).
3. **Write the one-page heat-wave plan**: the cool room; where the wet cloths and basin live; who is checked and
   how often; **which cooling center, its address and how you get there (2-1-1 or local health department /
   emergency management)**; and the person living alone this household calls.
4. **Name the medication question** — which medicines affect hydration or heat, which stay out of hot places,
   the rule that **nothing is stopped or changed without the doctor**, and where refrigerated medication goes
   (`MED-2`). **Name the at-risk members** from CDC's list and walk the cool room.

**Observable pass criteria — all five:** the **103 °F rule, the "no fluids" rule and the skin-sign correction are
recited correctly and unprompted**; the **fan rule is stated both ways** with the substitutes named; a **written
one-page heat-wave plan exists** with a named cooling center and a travel method; the **medication rule is
stated** and the **at-risk members are named**, not described generically; and the household states that **an
elder's "I'm fine" is not an assessment** — you look.

**Assessment.** By an adult who did not write the plan, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; a hesitation on the 103 °F or the "no fluids" rule is a re-teach, not a pass.
**Hours.** 2, in spring, before the first heat wave.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must know to fetch an adult if someone
is confused or has stopped sweating, and must never give a drink to someone who is confused.**

---

## 4.9 Module `SHE-1` — Shelter and building reality

> **Tier 3 — SHELTER, SECURITY AND COMMUNITY. Pass level: CAN TEACH IT on the seal-a-room step.**

**Objective.** Board and seal one opening, demonstrate sealing a room against an airborne hazard, state the
shelter and pet facts, and know what the building does to your heat. **Chapters.** `04 §4.4` · `07` · `08` ·
`10`.

**Drill — close a hole, seal a room, make three calls.** Three hours.

1. **Board and sheet one opening** (real or simulated on a frame): glass made safe, rigid layer fixed, plastic
   over it on the inside, full perimeter taped, **one window in the room left operable.**
2. **Seal one room for an airborne hazard, timed**: everyone and the pets in, ventilation off, vents and door
   perimeter taped, damp towel at the door, plastic over the opening, radio on, the three abandon triggers
   stated. Say out loud that **no board, screw, tape or sheeting dimension is printed in this program**, and
   that the fire department or building department is who to ask.
3. **State the shelter facts**: most public shelters allow **only service animals**; **2-1-1** and local
   emergency management give shelter and cooling-center locations; the go-bag plus `BAS-2` is what you carry in.
4. **State the building-wide heat-loss reality** for your building, then **make the three calls or lookups** —
   the landlord or management emergency number, the local emergency management line, and one neighbor (this
   overlaps `SEC-3`; do it once, count it twice) — and **write the two pet answers**: the place that will take
   the animal, and the person who will take it if the shelter will not.

**Observable pass criteria — all five:** the **opening is closed in two layers with the perimeter sealed** and
**one window in that room remains operable**; the **seal-a-room step is completed and timed**, ventilation shut
down and the three abandon triggers stated; the household states, unprompted, that **no board-up or seal-a-room
dimension is printed here** and names who to ask instead; the **shelter facts are correct** and **both pet
answers are written down**, naming real people or places; and the **three calls or lookups are done**, with
results on the card.

**Assessment.** By an adult who did not run the drill, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; the seal-a-room step must be teachable, because it is the one step that happens
in a hurry. **Hours.** 3, plus the calls.

**Who must be able.** Every adult to CAN TEACH IT on the seal-a-room step. **Children over eight must know which
room the household seals, and be able to go there and stay there when told.**

---

## 4.10 Module `SHE-2` — Above the sixth floor

> **Tier 3 — SHELTER, SECURITY AND COMMUNITY. Run it whether or not you live high up; the building-level facts
> change the plan either way.**

**Objective.** State what fails first in a tall building, produce a written water-carrying and waste plan for
your floor, and record the landlord conversation. **Chapters.** `04 §4.4.5` · `02` · `07` · `08` · `10`.

**Drill — the building audit.** Two hours, on foot.

1. **Walk the building and record**: your floor; where water enters and whether there is a booster pump or roof
   tank; whether there is a generator and **what it actually powers**; where the stairs are and how many flights
   to the ground; where the bins are.
2. **State the rule**: above roughly six floors the taps die with the power, so **the tap is a 72-hour source at
   best** — and say how many days of water this household actually has upstairs today.
3. **Write the carrying plan**: who carries, how much per trip, how many trips, how long it takes, and what
   happens when the carrier is injured or exhausted.
4. **Write the waste plan** — where it goes for 72 hours, which authority has been asked, and **the observation
   that fires the "sanitation untenable" trigger** (§4.6.6) — then **write the stairs plan for the slowest
   member** (doc 08), time one descent without rushing anyone, and **record the landlord conversation**.

**Observable pass criteria — all five:** the **building audit is written down** (floor, water source, booster
pump or tank, what the generator powers, stair count, bin location); the household states, unprompted, that
**above roughly six floors the taps die with the power** and says **how many days of water it has upstairs right
now**; a **written carrying plan exists**, naming who carries and what happens when they cannot; a **written
waste plan exists**, naming the authority asked and the trigger to leave; and the **landlord conversation is
recorded** — number, generator scope, pump responsibility, written waste question.

**Assessment.** By an adult who did not run the audit, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. **Hours.** 2.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must know the stair route down and the
meeting place outside.**

---

## 4.11 Module `CLO-1` — Dress the slowest member for 0 °C in five minutes

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Life-critical in a cold outage: pass level is CAN TEACH IT.**

**Objective.** Dress the household's slowest member for freezing conditions, in five minutes, in the dark, from
what is in the house — then do it for every member. **Chapters.** `04 §4.5` · `11` · `10`.

**Drill — five minutes, lights out, timer running.** One hour.

1. **Before the timer:** show the clothing store — the labelled drawer or box per person — and the complete dry
   change held in reserve.
2. **Lights out. Timer starts. Dress the slowest member** in base layer, mid layer, shell, hat, gloves, dry socks
   and footwear they can put on themselves. Five minutes, in the dark, by torch.
3. **Then every other member of the household**, same standard, including any child.
4. **Say the three rules** (dry beats thick; loose beats tight; head, neck, hands and feet) and **the
   elder-specific points**: you check them because they will not report cold; layers go on before the room is
   cold; pull-on, front-opening, large-fastener clothing for arthritis; a wet pad or wet clothing in a cold room
   is an emergency; loose hems and unsupported slippers cause falls. **Show footwear by every bed.**

**Observable pass criteria — all four:** the **slowest member is fully dressed for 0 °C within five minutes, in
the dark, from what is in the house**, timed — missing the time is a fail, not a partial; **every member is
dressed to the same standard** in the same session and **the clothing store is labelled per person** with a
reserved dry change; the **three layering rules and the elder-specific points are stated unprompted**; and
**footwear is by every bed**, verified by walking the bedrooms.

**Assessment.** By an adult who did not do the dressing, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT** — dress a second person while explaining the layering; both the speed and the
explanation are marked. **Hours.** 1. Cheapest module in the program; run it early.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must dress themselves to the same
standard in the dark**, and know where their own labelled clothing is.

---

## 4.12 Module `SAN-1` — Sanitation: the kit, the standard, the rule, the trigger

> **Tier 1 — LIFE SUPPORT. Pass level: CAN TEACH IT.**
>
> **This module contains no build drill. The earlier draft's "build and use the emergency toilet" drill is
> withdrawn.** The construction method, the waste volume per person per day, and the disposal rules could not be
> verified from a primary source, and this program will not teach a method it cannot source. What replaces it is
> the four things that are verified, plus the phone call that produces the fifth.

**Objective.** Assemble the federal-list sanitation supplies, demonstrate the 20-second handwash standard, state
the legality position correctly, and have a named authority and a written trigger. **Chapters.** `04 §4.6` ·
`02` · `01` · `10`.

**Drill — the kit, the wash, the call, the trigger.** One hour, plus the call.

1. **Lay out the kit** against the federal list: heavy garbage bags and ties, moist towelettes, disposable
   gloves, soap, sanitizer at **60% alcohol or more**, a large water jug, a bucket, a lidded container. Say which
   items are missing and write them on the shopping list.
2. **Demonstrate the handwash** — soap, safe water, **at least 20 seconds**, the key times named aloud — then the
   sanitizer fallback and its limits: it does not kill everything, it does not remove chemicals, it is not a
   substitute when hands are visibly dirty. **Build the handwashing station**: a large water jug on a chair or
   counter, soap beside it, a basin under it, and **a decided destination for the runoff** — one by the toilet,
   one by the food.
3. **State the legality position in your own words**: waste disposal is governed by your jurisdiction; **this
   program prints no disposal rule**; the household's job is to ask the local health department and follow what
   they say. Add the two certainties: **never into a storm drain**, and never into a container that will hold
   food or water again.
4. **Make the call or find the published guidance** — the local health department's water-emergency or
   solid-waste line — and write on the card who you called, what they said, and the date. **Write the "sanitation
   untenable" trigger** in this household's own words from §4.6.6 and sign it, and state the diarrhea response:
   safe water, rehydration (sachets — doc 06, never an improvised ratio), get to care.

**Observable pass criteria — all five:** the **kit is laid out and the gaps are written down**, with sanitizer
at 60% alcohol or more; a **20-second handwash is demonstrated with soap and safe water** and **the station is
built and sited** where the hands are with a decided runoff destination; the household states, unprompted, that
**this program prints no disposal rule** because disposal is jurisdictional and that **asking the local health
department is the household's job**; the **authority is named and the answer is written on the card, with a
date** — a blank card is a fail; and the **trigger is written and signed**, naming an observable condition, with
the household able to state that it fires branch 2 or branch 3 of the decision tree.

**Assessment.** By an adult who did not run the drill, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT** — the household must be able to explain to a second adult *why* there is no method
in this book, which is what stops someone inventing one at 2 a.m. **Hours.** 1, plus the call. Run it in week 4,
before the 72-hour drill.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must wash their hands properly,
unassisted, and know to fetch an adult rather than handle waste.**

---

## 4.13 Module `SAN-2` — Handwash and dish station, used for a week

> **Tier 1 — LIFE SUPPORT. The module that changes behavior, and behavior is what holds over 90 days.**

**Objective.** Run a handwash station and a dish station for seven consecutive days, with a log, and demonstrate
the clean-and-dry rule. **Chapters.** `04 §4.6.2`–`§4.6.4` · `02` · `10`.

**Drill — seven days, logged.** One hour to set up, seven days to run, half an hour to review.

1. **Set up both stations**: handwash by the toilet and by the food; dish station with soap, safe water, a basin,
   and a drying space.
2. **Log it daily for seven days**: hands washed at the key times (tick, not prose), water used (measured, so the
   household learns its real consumption), and any day the station was not maintained and why.
3. **Demonstrate the dish rule** from CDC: "Clean food preparation areas and kitchenware with soap and safe water
   and **let dry completely before reuse.**" Dry completely is the step people skip.
4. **Demonstrate the sanitizer limits** again and state when soap and water is required instead, then **review
   the week with the assessor**: what the water cost per day, what broke, what changes.

**Observable pass criteria — all four:** **seven consecutive days logged**, with key-time ticks and measured
water use, and **both stations still standing and in use at the end of the week** — not packed away; the **dish
rule is demonstrated**, including "let dry completely before reuse"; the **sanitizer limits are stated
correctly** (not a full substitute, does not remove chemicals, not for visibly dirty hands); and the **household
can state its measured water use per day for hygiene**, which is the number doc 02's buffer has to cover.

**Assessment.** By an adult who did not run the week, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. **Hours.** 1 setup and review, 7 days of running.

**Who must be able.** Every adult to CAN TEACH IT. **Children over eight must use the station unassisted for the
full week** — which is the point of running it for a week rather than an afternoon.

---

## 4.14 Closing the chapter

**On warmth, cooling, shelter and hygiene the rules are strong and the numbers are mostly missing.** You know a
generator goes more than 20 feet from any window, door or vent and never indoors even with the doors open,
because CDC says exactly that. You know a fan above 90 °F makes a hot person hotter, because CDC and the
National Weather Service both say it. You know 103 °F or confusion means call now and do not hand them a drink.
You know hands get 20 seconds of soap and safe water, sanitizer is 60% alcohol or better, and a large water jug
is the handwashing station when the tap is gone. You know that above roughly six floors the taps die with the
power, that most shelters take service animals only, and that a wet base layer undoes every layer above it.

**What you do not have is a clearance distance, an extinguisher specification, a toilet-building method, a waste
volume or a disposal rule — deliberately.** Each is a phone call to someone who does have them: your **fire
department** for the heater clearance and the extinguisher, your **local health department** for the waste rule
and the water-emergency hygiene guidance, your **building department** for what counts as a secure opening.

**And the shelter chapter is the one that changes the plan.** A household that has done `SHE-1` and `SHE-2`
knows what its building will do to it — where the heat goes, where the water stops, what the generator does not
power, how many flights the slowest member must descend — and that is what turns "sanitation untenable" from a
phrase in a decision tree into a sentence someone can actually say on day four: *we said we would leave if this
happened, and it has happened.*

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version
1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a
source does not cover an item — heater clearances, extinguisher and candle specifications, backfeed,
emergency-toilet construction, waste volume, disposal rules, dishwashing and laundry ratios, menstrual and diaper
management — this document says so rather than supplying a number, and sends you to the authority who does have
it.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
