# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 10 — FORMS AND CHECKLISTS

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This is the paper half of the program. Every module in doc 09 closes on something you can
show, and most of those somethings are a page in this document with your handwriting on it.
The prose in docs 00–08 tells you what to do; these pages are where you record that you did
it, when, and who watched.

Three rules govern every form here.

**They are meant to be written on by hand, in ink.** A form filled in on a phone is a form
that stops working when the phone does. Print these, keep them in the kit, and write on them.

**They work in black and white.** Nothing here depends on colour to be read: no red for
"danger", no green for "done", no shaded box that means something. Every distinction is
carried by a word, a line, or a box you tick. Print on the cheapest printer in the house, on
either Letter or A4, at 100% — never "fit to page", because shrinking a form is how a
writing line becomes too small to write on.

**The large-print pages are different pages, not the same page in bigger type.** The
medication list (§10.3) and the family decision card (§10.5) each have a large-print version
set from scratch: one field per line, one item per panel, short labels, wide ruled lines, no
small print anywhere on the sheet. They exist because the person who actually writes the
medication list, and the person who actually reads the decision card at two in the morning,
may be eighty years old with hands that shake. A footnote saying "print larger" would be an
insult to that person. These are real forms.

### 10.0 Which form belongs to which module

| Module | Form | Kept where |
|---|---|---|
| `BAS-1` roster | §10.1 household roster (part of the pantry calculator's first page) | kit |
| `BAS-2` medical and device inventory | §10.3 medication and device list, plus §10.3-LP large print | kit **and** go-bag |
| `BAS-3` documents, contact card, cash | §10.4 ICE card, one per member | wallet, every member |
| `BAS-4` decision card and meeting | §10.5 decision card, plus §10.5-LP large print | by the door, and one in the kit |
| `WTR-1` 14-day buffer | §10.2 water log and water card | taped inside the water cupboard |
| `FOD-1` pantry | §10.1 pantry calculator and pantry card | pantry door |
| `FOD-3`, `MED-2` | §10.6 hour-4 / hour-24 / hour-72 page (part of §10.3) | kit |
| `CO-1`, `FIR-1` | §10.8 alarm and extinguisher log | hall, near the alarm |
| `DRILL-1`, `INT-1` | §10.7 drill screen, drill log, abort record | kit |
| `MOV-3` | §10.7 evacuation log | go-bag |
| `SEC-1` | §10.9 security score sheet | with the household file |
| `SEC-2`, `SEC-4` | §10.9a visitor and door log | by the answer-door |
| everything | §10.10 supply inventory and rotation sheet | with the household file |

A blank form is a fail, not a plan. Where a form asks for a date, a blank line is read by the
assessor as "not done", which is exactly what it means.

---

## 10.1 Household roster and pantry calculator (`BAS-1`, `FOD-1`)

### 10.1.1 The roster — page one of the calculator

Fill this in with the household in the room. The point is not the list of names; it is the
column headed "what they cannot do on their worst day", which most households have never
written down and which changes the door protocol, the fire plan and the evacuation time.

| Name | Age | Can they walk a flight of stairs? | Can they lift 20 lb? | Hear a smoke alarm from their bed? | See well enough to cross a dark room? | Can they be left alone? For how long? | What they cannot do on their worst day | The workaround, named |
|---|---|---|---|---|---|---|---|---|
| | | Y / N | Y / N | Y / N | Y / N | Y / N — ____ h | | |
| | | Y / N | Y / N | Y / N | Y / N | Y / N — ____ h | | |
| | | Y / N | Y / N | Y / N | Y / N | Y / N — ____ h | | |
| | | Y / N | Y / N | Y / N | Y / N | Y / N — ____ h | | |
| | | Y / N | Y / N | Y / N | Y / N | Y / N — ____ h | | |

Include every person who is in the home daily, not only the people on the lease: the carer,
the grandparent who comes at three o'clock, the teenager next door who lets himself in.

**The slowest member is:** ______________________________ (a name, not "the elderly one")

**This person cannot be left alone for more than:** ______ hours.

**Every adult has read this page and can name the slowest member without looking:** tick each
name — ☐ ______ ☐ ______ ☐ ______ ☐ ______

### 10.1.2 The calorie calculator — per person, from the table, not from 2,000

Take each person's figure from the table in doc 03 §3.3. Do not use a flat 2,000; a sedentary
woman of 76 needs 1,600 and a teenage boy needs far more, and both errors are expensive. Write
the figure in the third column and show your arithmetic in the fourth.

| Person | Age / sex / activity level as listed in the table | Calories per day (from the table) | × 90 days = household requirement | × 30 days = pantry target |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| **Household total** | | **____ kcal/day** | **____ kcal** | **____ kcal** |

**From calories to packages** (doc 03 §3.4): packages needed = total calories ÷ calories per
package. Read calories per package off the Nutrition Facts panel: calories per serving ×
servings per container.

| Item | Calories per package | Packages needed (target ÷ per package) | Packages counted on the shelf | Gap |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

### 10.1.3 Layer 1 verification — needs no cooking, no water, no fridge

Tick only what you have physically picked up and read the label of. Layer 1 is the food you
can eat on day one with the power off and the taps dry.

| Item | Counted (number) | Needs no cooking? | Needs no water? | Needs no fridge? | In date? |
|---|---|---|---|---|---|
| | | ☐ | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ | ☐ |

**Oil and fats:** every container carries its purchase date, and the six-month rotation is in
the calendar.

| Container | Purchase date | Rotate by | In the calendar? |
|---|---|---|---|
| | | | ☐ |
| | | | ☐ |

### 10.1.4 The pantry card — cut out, tape to the pantry door

```
+---------------------------------------------------------------+
|  THE PANTRY, AS IT ACTUALLY IS          date: ____/____/______ |
|                                                               |
|  Calories stored, counted:  ______________ kcal               |
|  Household need per day:    ______________ kcal               |
|  DAYS OF FOOD ON THE SHELF: ______________ days               |
|  Gap to 90 days:            ______________ kcal               |
|  Layer 1 (no cook, no water, no fridge): ______ days          |
|                                                               |
|  Our trigger, in our words:                                   |
|  ____________________________________________________________ |
|  ____________________________________________________________ |
|                                                               |
|  Next count due: ____/____/______   By: ______________        |
+---------------------------------------------------------------+
```

**Days of supply is a number, not "about three months".** If you cannot write the number, you
have not counted.

---

## 10.2 Water log and water card (`WTR-1`, `WTR-4`)

The target is a 14-day Grade A drinking buffer at **¾ gallon (about 3 litres) per person per
day** (doc 02 §2.3), plus whatever Grade B you can hold. Grade A is drinking water. It is not
for the toilet, and the card says so, because the day someone pours it down the toilet is the
day the buffer stops being a buffer.

### 10.2.1 The water log

One line per container. Write the fill date **on the container** as well as here, in marker,
because a log in a cupboard and a jug in a bathroom are two different things.

| # | Container (type and size) | Gallons | Location | Fill date | Rotate by (6 months) | Checked by | Rotated on |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |
| 7 | | | | | | | |
| 8 | | | | | | | |
| 9 | | | | | | | |
| 10 | | | | | | | |
| | **Total Grade A gallons** | | | | | | |

**Grade B (washing, flushing, dishes) — counted separately, never mixed into the Grade A
total:**

| Container | Gallons | Location | Fill date | Use |
|---|---|---|---|---|
| | | | | |
| | | | | |

### 10.2.2 The water card

```
+---------------------------------------------------------------+
|  WATER, STATED AS A NUMBER            date: ____/____/______   |
|                                                               |
|  People in the household:            ______                   |
|  Grade A stored:                     ______ gallons           |
|  Daily drinking need (0.75 × people): ______ gallons/day      |
|  DAYS OF DRINKING WATER:             ______ days              |
|  Target is 14 days. Shortfall:       ______ gallons           |
|                                                               |
|  One-time draw from the building (water heater, tanks):       |
|  ______ gallons, and it can only be used once.                |
|                                                               |
|  Grade A is NOT for the toilet. Grade B is for the toilet.    |
|                                                               |
|  Our branch-2 trigger, in our words:                          |
|  ____________________________________________________________ |
|                                                               |
|  Rotation date in the calendar: ____/____/______              |
+---------------------------------------------------------------+
```

### 10.2.3 Water source survey (`WTR-4`)

| Source | Found? | Photographed? | Fuel type / ownership | Safe for drinking? | Notes |
|---|---|---|---|---|---|
| Water heater | ☐ | ☐ | | ☐ | |
| Toilet tank — bathroom 1 | ☐ | ☐ | n/a | ☐ only if untreated | |
| Toilet tank — bathroom 2 | ☐ | ☐ | n/a | ☐ only if untreated | |
| Other (rain, dehumidifier, pool) | ☐ | ☐ | | ☐ | |

**Never a source — write the household's own reason beside each:** radiator ____ ; boiler
____ ; toilet bowl ____ ; building main ____ ; sprinkler riser ____ .

**Unit shut-off located and physically demonstrated by:** ______________ date ______

---

## 10.3 Medication and device list (`BAS-2`, `MED-1`, `MED-2`)

This is the single most important page in the product. In an outage the device is the
emergency, not the pills, so the page has two halves and both are filled in. **This program
writes no doses.** The label is the authority; copy it exactly.

### 10.3.1 Medicines

| Person | Medicine (as printed on the label) | Dose as prescribed | When taken | Prescriber | Pharmacy and number | Refill due | Notes (what it is for, what happens if missed) |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

Refrigerated medicines — which ones, and what the label says about heat:

| Medicine | Must be kept cold? | How long it tolerates heat, per the label or the pharmacist | Where it lives |
|---|---|---|---|
| | ☐ | | |
| | ☐ | | |

### 10.3.2 Devices — the half that gets forgotten

Check every row, present or absent, and record which. A blank row is a fail: it means nobody
looked.

| Device | In the house? | Power source | Runtime on battery | Runtime on nothing | Supplier / emergency number |
|---|---|---|---|---|---|
| Oxygen concentrator | ☐ yes ☐ no | | | | |
| Home dialysis | ☐ yes ☐ no | | | | |
| Infusion pump | ☐ yes ☐ no | | | | |
| CPAP | ☐ yes ☐ no | | | | |
| Powered chair or scooter | ☐ yes ☐ no | | | | |
| Insulin (refrigerated) | ☐ yes ☐ no | | | | |
| Other: ____________ | ☐ yes ☐ no | | | | |

### 10.3.3 The hour-4 / hour-24 / hour-72 page (`MED-2`)

Answer these three questions for every device and every refrigerated medicine above. "I don't
know" is a legitimate answer to write down — it is the question for the supplier, and a
household that cannot answer hour 24 has not passed `MED-2`.

| Item | Hour 4 — what has happened? | Hour 24 — what has happened? | Hour 72 — what has happened? | Who we asked | Date |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Refrigeration plan, one page, named checker:** ______________________
**Power-off time rule, in our words:** ____________________________________________

### 10.3.4 The list travels

- ☐ Photographed, and the photograph is on every adult's phone.
- ☐ Paper copy in the medicine kit.
- ☐ Paper copy in the go-bag.
- ☐ A third copy with the out-of-area contact.

**If any device above is in this house, this list is what excludes the household from
`DRILL-1` until `MED-2` is closed. Every adult can state that unprompted:** ☐

---

### 10.3-LP Large-print medication list

Set from scratch for the person who writes it, not shrunk from the page above. **One medicine
per panel. One field per line. No small print on the sheet at all.** Print one copy per
person in the household, plus one for the kit. If your printer has a "large" or "poster"
setting, use it; the layout below is built so that nothing is lost if it is printed at the
size it appears.

```
================================================================
  MEDICINES FOR: ______________________________________________

  Date this page was written: ____ / ____ / ________
================================================================

  MEDICINE 1

  The name on the box, copied exactly:

  ______________________________________________________________
  ______________________________________________________________

  How much I take:

  ______________________________________________________________

  When I take it:

  ______________________________________________________________

  Who prescribed it:

  ______________________________________________________________

  Pharmacy and phone number:

  ______________________________________________________________

  Next refill due: ____ / ____ / ________

  What it is for, in my own words:

  ______________________________________________________________
  ______________________________________________________________

  If I miss a dose, I do this (or: I call this number):

  ______________________________________________________________
  ______________________________________________________________

----------------------------------------------------------------
  MEDICINE 2

  The name on the box, copied exactly:

  ______________________________________________________________
  ______________________________________________________________

  How much I take:

  ______________________________________________________________

  When I take it:

  ______________________________________________________________

  Who prescribed it:

  ______________________________________________________________

  Pharmacy and phone number:

  ______________________________________________________________

  Next refill due: ____ / ____ / ________

  What it is for, in my own words:

  ______________________________________________________________
  ______________________________________________________________

  If I miss a dose, I do this (or: I call this number):

  ______________________________________________________________
  ______________________________________________________________

================================================================
  IF SOMEONE ELSE IS READING THIS PAGE:

  Do not change, stop, or halve anything on it.
  The label on the box is the authority, not this page.
  The doctor's number is: ______________________________________
  The pharmacy's number is: ____________________________________
================================================================
```

Continue the same panel for each medicine, one per panel. On the back of the last panel,
print the large-print device page:

```
================================================================
  MACHINES THAT NEED POWER OR COLD

  Machine: _____________________________________________________

  What it does for me:

  ______________________________________________________________

  What it plugs into:

  ______________________________________________________________

  What happens if the power is off for 4 hours:

  ______________________________________________________________

  For 24 hours:

  ______________________________________________________________

  For 72 hours:

  ______________________________________________________________

  Who I call, and the number, written large:

  ______________________________________________________________
  ______________________________________________________________
================================================================
```

---

## 10.4 ICE contact card (`BAS-3`) — one per member, including each child

Paper, not a phone, because a dead battery has no contacts in it. Print four to a page, cut
along the lines, fold once, and put it in the wallet or the school bag. Fill in by hand, in
pencil for the phone numbers so they can be corrected.

```
..............................................................
|  IN CASE OF EMERGENCY — [ name ]                            |
|                                                             |
|  Name: ______________________________                       |
|  Date of birth: ______________________                      |
|  Address: ____________________________________________      |
|           ____________________________________________      |
|                                                             |
|  Conditions a stranger must know: ____________________      |
|           ____________________________________________      |
|  Allergies: __________________________________________      |
|  Medicines: see the medication list in the medicine kit      |
|  (kept at: __________________________________________)      |
|                                                             |
|  Doctor: ____________________ phone: _________________      |
|                                                             |
|  CALL FIRST — out of area:                                  |
|    1. ______________________ phone: _________________       |
|    2. ______________________ phone: _________________       |
|    3. ______________________ phone: _________________       |
|                                                             |
|  Our rally points:                                          |
|    One: ______________________________________________      |
|    Two: ______________________________________________      |
|                                                             |
|  Nobody goes back inside the building. Ever.                |
|                                                             |
|  Card written: ____/____/______  Reviewed: ____/____/_____  |
..............................................................
```

**Documents, copies, cash (`BAS-3`):**

| What | Copied? | Where copy 1 is | Where copy 2 is (off-site or digital) | Date |
|---|---|---|---|---|
| ID / passport / birth certificates | ☐ | | | |
| Insurance and prescriptions | ☐ | | | |
| Lease or deed | ☐ | | | |
| Medication list | ☐ | | | |

**Cash is kept at:** ______________________ **Amount:** __________
**Two adults who can state where it is and what it is for:** ____________ , ____________

---

## 10.5 The family decision card (`BAS-4`)

One page, in ink, dated, signed by every adult. It exists so the call is not made in a panic
at two in the morning by whoever happens to be awake. All three branches, in the household's
own words — not copied from this book. At least two named triggers per branch. A named
destination and phone number for branch 2 and branch 3. A named decider and a named alternate.

### 10.5.1 The card

```
+---------------------------------------------------------------+
|  OUR DECISION CARD              written ____/____/______      |
|  Reviewed every six months. Next review: ____/____/______     |
+---------------------------------------------------------------+
|  BRANCH 1 — STAY AND HARDEN (this is our default)             |
|  We move to this branch when:                                 |
|    1. _______________________________________________________ |
|    2. _______________________________________________________ |
|  What we do in the first hour:                                |
|    ___________________________________________________________ |
|    ___________________________________________________________ |
+---------------------------------------------------------------+
|  BRANCH 2 — GO SOMEWHERE STAFFED                              |
|  (public shelter, cooling or heating centre via 2-1-1, or a    |
|  relative with power)                                         |
|  We move to this branch when:                                 |
|    1. _______________________________________________________ |
|    2. _______________________________________________________ |
|  Where we go: _______________________________________________ |
|  Phone: ____________________  Confirmed on: ____/____/______  |
|  How we get there: __________________________________________ |
+---------------------------------------------------------------+
|  BRANCH 3 — SLOW EXIT                                         |
|  (pre-planned assisted move to a place we have already asked)  |
|  We move to this branch when:                                 |
|    1. _______________________________________________________ |
|    2. _______________________________________________________ |
|  Where we go: _______________________________________________ |
|  Phone: ____________________  Confirmed on: ____/____/______  |
|  Who we call first: _________________________________________ |
+---------------------------------------------------------------+
|  SANITATION UNTENABLE IS A TRIGGER. It fires branch 2 or 3.    |
|  Our sanitation authority: ______________________________     |
|  Their answer, with the date we asked: __________________      |
|  ___________________________________________________________  |
+---------------------------------------------------------------+
|  WHO DECIDES: ______________________ (name)                   |
|  IF THEY CANNOT: ____________________ (name)                  |
|  We all agree that either of them may make the call alone.     |
|                                                               |
|  SIGNED, every adult:                                         |
|    ______________________  date ____/____/______              |
|    ______________________  date ____/____/______              |
|    ______________________  date ____/____/______              |
|    ______________________  date ____/____/______              |
+---------------------------------------------------------------+
```

Every adult must be able to restate the three branches without reading them. If one adult
cannot, the household has not passed `BAS-4` — that adult is the one who will be making the
call on the day.

### 10.5-LP Large-print decision card

A separate page, not a magnified version of the card above. **One branch per page. One line
per thought. Everything a person needs is on the page in front of them.** Print on one side
only, on card if you have it, and tape page one inside the hall cupboard where the household
keeps the torch.

```
================================================================
  PAGE 1 OF 4 — WHAT WE DO, AND WHEN

  Written on: ____ / ____ / ________
  Look at this again on: ____ / ____ / ________
================================================================

  WE HAVE THREE PLANS.
  SOMEBODY IN THIS HOUSE HAS ALREADY DECIDED WHICH ONE.

  The person who decides is:

  ______________________________________________________________

  If that person cannot, the person who decides is:

  ______________________________________________________________

  Either of them may decide alone. Nobody has to wait
  for anyone else to agree.

================================================================
```

```
================================================================
  PAGE 2 OF 4 — PLAN 1: STAY HERE AND MAKE THE FLAT SAFE

  This is what we do unless something on page 3 or 4 happens.

  We switch to this plan when:

  1. ____________________________________________________________
     ____________________________________________________________

  2. ____________________________________________________________
     ____________________________________________________________

  In the first hour we do this:

  1. ____________________________________________________________

  2. ____________________________________________________________

  3. ____________________________________________________________

================================================================
```

```
================================================================
  PAGE 3 OF 4 — PLAN 2: GO SOMEWHERE WITH PEOPLE AND POWER

  This means a public shelter, a cooling or heating centre
  (call 2-1-1), or a relative who has power.

  Note: shelters take service animals only. Not pets.

  We switch to this plan when:

  1. ____________________________________________________________
     ____________________________________________________________

  2. ____________________________________________________________
     ____________________________________________________________

  Where we go:

  ______________________________________________________________
  ______________________________________________________________

  The phone number, written large:

  ______________________________________________________________

  We called them and they said yes on: ____ / ____ / ________

  How we get there:

  ______________________________________________________________

================================================================
```

```
================================================================
  PAGE 4 OF 4 — PLAN 3: LEAVE SLOWLY, WITH HELP

  This is the plan we use when we can see it coming and we
  have time to do it properly.

  We switch to this plan when:

  1. ____________________________________________________________
     ____________________________________________________________

  2. ____________________________________________________________
     ____________________________________________________________

  Where we go:

  ______________________________________________________________

  The phone number, written large:

  ______________________________________________________________

  We called them and they said yes on: ____ / ____ / ________

  Who we telephone first, and the number:

  ______________________________________________________________
  ______________________________________________________________

================================================================
  ONE MORE THING, ON EVERY PAGE:

  If the toilet cannot be used safely, and we cannot fix it,
  that on its own is a reason to leave. It counts as a trigger
  for plan 2 or plan 3. It does not need a second reason.

  We asked: ______________________________________ (who)
  On: ____ / ____ / ________
  They told us: __________________________________
  ______________________________________________
================================================================
```

**Signatures, on the back of page 1, written large:**

```
  We have all read this. We agree with it.

  ______________________________  ____ / ____ / ________

  ______________________________  ____ / ____ / ________

  ______________________________  ____ / ____ / ________

  ______________________________  ____ / ____ / ________
```

---

## 10.6 Alarm, extinguisher and rotation log (`CO-1`, `FIR-1`)

| Alarm or extinguisher | Where it is | Type | Installed on | Expires / service by | Press-to-test date | Tested by | Audible from the sleeping area? |
|---|---|---|---|---|---|---|---|
| CO alarm 1 | | | | | | | ☐ |
| CO alarm 2 | | | | | | | ☐ |
| Smoke alarm 1 | | | | | | | ☐ |
| Smoke alarm 2 | | | | | | | ☐ |
| Extinguisher | | | | gauge checked: ☐ | | | n/a |

**Monthly test, twelve boxes; write the date in each:**

☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___ ☐ ___

**The "flu" rule, written by the household in its own words:** if more than one person in the
house has a headache, nausea and drowsiness at the same time, we __________________________
______________________________________________. This is what CO poisoning looks like, and it
is not slept off.

---

## 10.7 Drill logs (`DRILL-1`, `INT-1`, `MOV-3`)

### 10.7.1 The pre-drill screen — every line is a stop condition

Read aloud before the drill starts, by an adult, to every adult. **A correctly abandoned drill
passes the module. A drill run over an exclusion fails it.**

| # | Stop condition | Applies? | If yes, the drill does not run |
|---|---|---|---|
| 1 | Anyone on mains-powered equipment (oxygen concentrator, dialysis, infusion pump, CPAP, powered chair) or on cardiac, seizure or insulin medicine not yet covered by `BAS-2` and `MED-2` | ☐ yes ☐ no | stop |
| 2 | CO alarms not installed and tested today (`CO-1`) | ☐ yes ☐ no | stop |
| 3 | Cold snap or heat wave; above 90 °F | ☐ yes ☐ no | stop |
| 4 | No written fridge and freezer plan | ☐ yes ☐ no | stop |
| 5 | Water heater not isolated, or a shared building system would be drained | ☐ yes ☐ no | stop |
| 6 | Anyone may be in the lift | ☐ yes ☐ no | stop |
| 7 | The valve is the building main or the sprinkler riser | ☐ yes ☐ no | stop |
| 8 | Candles in use; no LED lights | ☐ yes ☐ no | stop |
| 9 | No named outside check-in person, or the abort rule not stated by every adult | ☐ yes ☐ no | stop |

**Outside check-in person:** ____________________ phone ____________________
**Told the drill started at:** ______ **and ended at:** ______

**Abort rule, stated aloud by every adult before the start:** ☐ ______ ☐ ______ ☐ ______
☐ ______

### 10.7.2 The 72-hour log

Three days, two checks a day. Write the number, not a feeling.

| | Day 1 am | Day 1 pm | Day 2 am | Day 2 pm | Day 3 am | Day 3 pm |
|---|---|---|---|---|---|---|
| Date and time | | | | | | |
| Grade A water used (gallons, cumulative) | | | | | | |
| Meals served (number) | | | | | | |
| Room temperature (°F) | | | | | | |
| Toilet used, waste route honoured? | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Handwash station running? | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| CO alarm still powered and tested? | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Medication hour-24 answer executed? | | ☐ | | | | |
| Decision card consulted? | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Anything that broke | | | | | | |

**What broke, named, one per line:**

1. ____________________________________________ 2. ____________________________________
3. ____________________________________________ 4. ____________________________________

**Did we stop?** ☐ No, 72 hours completed ☐ Yes — stopped at ______ by ____________________
because ________________________________________________. A stop is not a failure of the
household; running on over an exclusion is the failure.

### 10.7.3 The evacuation log (`MOV-3`)

Timed, at the pace of the slowest member, **last person out**, to rally point one.

| Run | Date | Time of day | Last person at the rally point (mm:ss) | Doubled time | Anyone hurried? | One change made before the next run |
|---|---|---|---|---|---|---|
| 1 (daylight) | | | | | ☐ no ☐ yes | |
| 2 (daylight) | | | | | ☐ no ☐ yes | |
| 3 (after dark) | | | | | ☐ no ☐ yes | |

**Is that fast enough? Our answer, in writing:** __________________________________________
______________________________________________________________________________________

A run in which anyone was hurried does not count. A fast time with a distressed slow mover
fails the module regardless of the clock.

### 10.7.4 The re-score log — for every drill after the program ends

| Date | Drill | What we tested | Time or score | What changed since last time | Signed |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

---

## 10.8 Supply inventory and rotation sheet

Count, don't estimate. Every line gets a date, because a stock without a date is a rumour.

| Category | Item | Quantity | Unit | Stored where | Bought | Rotate or expires | Checked by |
|---|---|---|---|---|---|---|---|
| Water | Grade A containers | | gal | | | | |
| Water | Grade B containers | | gal | | | | |
| Water | Disinfecting bleach (concentration written on the bottle) | | | | | | |
| Water | Filter or other treatment | | | | | | |
| Food L1 | No-cook items | | | | | | |
| Food L2 | Cooked-from-store items | | | | | | |
| Food | Oils and fats | | | | | | |
| Medical | Kit, per `MED-1` | | | | | | |
| Medical | Prescription stock on hand | | days | | | | |
| Sanitation | Bucket, bags, cover material | | | | | | |
| Sanitation | Soap, sanitizer (60% alcohol or more) | | | | | | |
| Heat | Blankets, layers, hand warmers | | | | | | |
| Light | LED lights, batteries, head torch | | | | | | |
| Fuel | Approved cans, stored where | | | | | | |
| Cooking | Stove and fuel, stored outside | | | | | | |
| Tools | Extinguisher, wrench, sheeting, tape | | | | | | |
| Documents | Copies, cash, cards | | | | | | |
| Comfort | Children's no-power activity store | | | | | | |

**Quarterly count done on:** ____/____/______ by ____________________
**Next count:** ____/____/______

---

## 10.9 The security assessment score sheet (`SEC-1`)

Score each line **0, 1 or 2**. Zero is not true at all; one is partly true or true some of the
time; two is true and demonstrable to a visitor. **There is no pass mark.** The instrument is
not validated, and inventing a pass mark would be exactly the false authority this program
refuses. The score is for comparison with yourself.

Two walks, on two different days: one in daylight, one after dark with a torch. **The dark walk
is the whole drill.** A sheet filled in from an armchair in one sitting does not pass.

Start across the street, where a stranger would stand, not at your own front door.

| # | Statement | Daylight | After dark |
|---|---|---|---|
| 1 | Standing across the street in daylight, I can tell that someone is home. | | |
| 2 | Standing across the street after dark, I can tell that someone is home. | | |
| 3 | The approach to my door has no place where a person could stand unobserved from my windows. | | |
| 4 | There is a light at the answer-door that works without mains power. | | |
| 5 | I can identify a person at the door, at night, before opening it. | | |
| 6 | Everyone in the household knows which door is the answer-door. | | |
| 7 | No one opens the door to an unexpected caller without the door protocol. | | |
| 8 | A second adult can hear the answer-door from somewhere in the home. | | |
| 9 | Every fault on the shared entrance is written down, with a date, and reported. | | |
| 10 | I can name three neighbours and say which one has medical training. | | |
| 11 | At least one neighbour would notice if something were wrong at my home. | | |
| 12 | I have spoken to my local crime-prevention unit, or have the number and a date to call. | | |
| | **TOTAL, out of 24** | | |

**Daylight walk:** date ____/____/______ by ____________________
**Dark walk:** date ____/____/______ by ____________________

**Building faults, written down with dates (the landlord list):**

| Fault | Noticed on | Reported on | To whom | Fixed? |
|---|---|---|---|---|
| | | | | ☐ |
| | | | | ☐ |
| | | | | ☐ |
| | | | | ☐ |

**The call — the part most households never make:**

| What | Written here |
|---|---|
| The unit or officer I spoke to, by name | |
| Their number | |
| The date | |
| What they told me that I did not know | |
| What I will do about it, and by when | |

**Lines that stayed at zero across two scorings** — write down that you accepted them, and why:

1. __________________________________________________________________________________
2. __________________________________________________________________________________

---

## 10.9a The visitor and door log (`SEC-3`, `SEC-4`)

The door protocol in doc 07 §7.5 is only worth what you can show you did with it. One line per
caller, written the same day — including the callers you turned away, and especially the ones who
came back. This is a record for your own household, not a list of suspects: describe the caller,
never name a neighbour.

| Date | Time | Who it was (as they described themselves) | Expected? | Door protocol followed? | What happened | Initials |
|---|---|---|---|---|---|---|
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |
| | | | ☐ yes ☐ no | ☐ yes ☐ no | | |

**Callers who came back, or who would not leave a name** — write them down here and say what the
household decided. A pattern is only visible on paper:

| Date | What was decided, and by whom | Signed |
|---|---|---|
| | | |
| | | |

**Visitors expected during a disruption** — the people the household has agreed in advance it will
let in, and who can vouch for them. Agree this while nothing is happening:

| Name | How we know them | Who lets them in | Agreed on |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

This log records what the household did. It is not a legal document, it is not evidence for anyone
outside the household, and it is not a substitute for calling the emergency number when a caller
will not leave.

---

## 10.10 The forms, kept honestly

A stack of blank forms is not a household plan. The value of these pages is that they are
filled in, dated, signed by someone who was there, and kept where the household can put a
hand on them in the dark. When a form is empty, leave it empty and say so at the debrief —
an honest gap is fixable, and a form filled in from memory three weeks later is not a record,
it is a story.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
