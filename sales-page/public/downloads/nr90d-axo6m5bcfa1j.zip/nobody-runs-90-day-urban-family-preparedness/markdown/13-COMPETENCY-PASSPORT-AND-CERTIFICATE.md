# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 13 — COMPETENCY PASSPORT AND CERTIFICATE

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This is the record. Everything else in the program is instruction; this is the part that says,
in your own handwriting, with dates and initials, that a named household did named things in
front of a named person.

It is deliberately unglamorous. There is no seal on it, no crest, no badge, and no ribbon.
That is not a design failure — it is the honest shape of what this document is.

### 13.1 What this passport is, and what it is not

**It is a signed log.** For each of the thirty-nine modules it records the date the module was
closed, the rating that was given, who demonstrated it, and who watched. Signed by a household
member, dated, kept with the household's papers.

**It is not a qualification.** Nobody accredits it. No school, employer, licensing body,
insurer, landlord or clinician has any reason to accept it, and none of them has endorsed it.
It records that a household practised something in its own home. That is all it records, and
it is worth having for exactly that reason: a household that can produce this page has a
written answer to "did we actually do any of this, or did we only read the book?"

**The value is the log, not the paper.** A household that closes every module and never prints
a certificate has lost nothing. A household that prints a certificate with a half-filled log
behind it has a lie on the wall. Keep the log first.

**The certificate's framing paragraph** (§13.7.1) is printed in full, in the body of the
certificate itself, on every stage. It is never moved to a footnote, never set in smaller type
than the rest, and never removed to make the page look more official. If a copy of the
certificate turns up without that paragraph on it, that copy is wrong.

### 13.2 The three ratings, and who is allowed to give one

There are three ratings in this program and no others. There is no percentage anywhere, no
score out of a hundred, no grade, and no "mostly done".

| Rating | What it means | What the assessor must have seen |
|---|---|---|
| **NOT YET** | Not done, or done once with help. | Nothing, or help was given. This is the default and it is not a judgement. |
| **DEMONSTRATED** | Done unassisted, to the module's pass criteria. | The whole thing, once, without a hand on it. |
| **CAN TEACH IT** | Done unassisted **and** taught to another household member who then did it themselves. | Two events: the demonstration, and the teaching, and the second person doing it. |

**Who assesses.** By default, an adult who did not perform the task. In a single-adult
household a neighbour or a CERT contact may witness and initial. If nobody at all is
available, score yourself, date it, and write **self-assessed** beside your initials. A
self-assessed line is worth less and pretending otherwise would be dishonest; the log has a
column for it so that the difference is visible at a glance.

**The household rating is the lowest individual rating.** One adult who cannot restate the
three branches means the household has not closed `BAS-4`, because that adult is the one who
will be making the call on the day.

**Two modules have no partial pass.** `MED-5` and `FUE-1` are closed-book written checks:
**ten out of ten**, each answer with a one-line reason. Nine is a fail and a re-teach. There
is no CAN TEACH IT tier on those two; a person either has the rule or does not.

**Children eight and over** are rated only on age-appropriate competencies — fetching help,
the door script, the rally point, the water station, carrying their own bag. A child is never
rated on whether they were frightened, and no child is ever given a rating on a page their
parent signs for them without them being told what it says.

---

## 13.3 The competency log — thirty-nine modules

Fill one line per module. **"What the assessor must see" is not the whole pass criteria** —
the full criteria are in doc 09 for each module, and the assessor reads them before watching.
This column is the reminder of what to look at, not a substitute for the page.

Ratings: **N** = not yet · **D** = demonstrated · **T** = can teach it.
Write the initials of the person who demonstrated, and the initials of the person who watched.
Mark **SA** after the assessor's initials if it was self-assessed.

### TIER 0 — BASELINE (week 0)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `BAS-1` Household roster and vulnerability map | Every person and daily visitor with a named limit and workaround; slowest member named as a person | | | | | |
| `BAS-2` Medical and device inventory | Every medicine with dose, prescriber, refill; every device with power source and runtime; all six devices checked present or absent | | | | | |
| `BAS-3` Documents, contact card, cash | Copies in two places; a paper ICE card for every member with the out-of-area contact; two adults can say where the cash is | | | | | |
| `BAS-4` Family decision card and household meeting | Card in ink, three branches in the household's own words, two triggers each, named decider and alternate, every adult signed and can restate | | | | | |

### TIER 1 — LIFE SUPPORT (weeks 1–4)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `WTR-1` Store a 14-day buffer | Grade A counted, not estimated, against ¾ gal × people × 14; dates on containers; water card states days as a number | | | | | |
| `WTR-2` Boil water safely | Correct time stated before the pot goes on; rolling boil observed outdoors; two things boiling does not remove | | | | | |
| `WTR-3` Disinfect water with bleach | Two batches, clear and cloudy, dosed from the printed table at the bottle's actual concentration; contact time timed | | | | | |
| `WTR-4` Find water inside the building | Water heater found, photographed, unit shut-off demonstrated; never-list in the household's own words | | | | | |
| `FOD-1` Build the pantry | A per-person calorie figure from the table; 90-day requirement displayed; Layer 1 verified; Layer 2 counted to 30 days | | | | | |
| `FOD-2` Cook with no power | One hot meal cooked **outdoors or on a ventilated balcony**; exclusion list recited unprompted; extinguisher located | | | | | |
| `FOD-3` Keep food safe with no fridge | All five figures from memory — 4 h, 48 h, 24 h, 40 °F, the 4-hour cooler point; a real discard decision defended | | | | | |
| `SAN-1` Emergency sanitation: kit, handwash, disposal route | Kit laid out, 20-second handwash demonstrated, authority named with a dated answer, trigger written and signed | | | | | |
| `SAN-2` Handwash and dish station | Seven consecutive days logged; both stations still standing; measured daily hygiene water use stated | | | | | |
| `CO-1` Install and test CO alarms | Alarms audible from the sleeping area, tested in front of the assessor, expiry dates logged, the "flu" rule stated | | | | | |

### TIER 2 — HEALTH, WARMTH AND CLOTHING (weeks 4–7)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `MED-1` Build the medicine kit | Sourced categories present, gaps written with reasons, boxes dated, kit locked, list copied to kit and go-bag | | | | | |
| `MED-2` Medication and device continuity | Written hour-4 / hour-24 / hour-72 answers; provider's answers written; refrigeration plan with a named checker | | | | | |
| `MED-3` Rehydration by sachet | Sachet mixed exactly to the packet's volume; the five go-now signs named; "running out means going, not improvising" | | | | | |
| `MED-4` Wound care and infection signs | Wound washed with soap and clean water; infection signs unprompted, including new confusion in an elder; daily check owned | | | | | |
| `MED-5` The "do not do this" list | **10/10 closed book, every adult, with a real one-line reason each.** Nine is a fail | | | | | |
| `MED-6` First aid that matters here | Four recognition sets unprompted; four items found in the dark in under two minutes; falls walkthrough with fixes owned | | | | | |
| `WTH-1` Warmth without utilities | Warm room chosen and the rejected room explained; drafts physically stopped; CO alarm present and audible | | | | | |
| `WTH-2` Heat illness and heat-wave plan | The 103 °F rule and the "no fluids" rule unprompted; written heat-wave plan with a named cooling centre | | | | | |
| `FIR-1` Fire and CO | Extinguisher located, label read aloud, gauge dated; PASS recited and the sweep demonstrated in the air only | | | | | |
| `FUE-1` Fuel safety | **10/10 closed book, every adult**, plus the room-by-room fuel walk with every exclusion named | | | | | |
| `CLO-1` Dress the slowest member for 0 °C | Slowest member dressed for freezing, in the dark, in five minutes, timed; every member to the same standard | | | | | |

### TIER GATE — `DRILL-1`

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `DRILL-1` The 72-hour no-utilities drill | Signed pre-drill screen; 72 hours with the daily checks logged; abort rule stated by every adult beforehand; debrief lists every failure by name | | | | | |

### TIER 3 — SHELTER, SECURITY AND COMMUNITY (weeks 8–9)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `SHE-1` Shelter and building reality | One opening closed in two layers; seal-a-room timed with the three abandon triggers; both pet answers naming real people | | | | | |
| `SHE-2` Above the sixth floor | Written building audit; days of water upstairs stated as a number; carrying plan and waste plan each naming people | | | | | |
| `SEC-1` The security assessment | Score sheet completed on two walks on two days; a **named** person at the police department spoken to, with the date and what they said | | | | | |
| `SEC-2` The door protocol | Child delivers all three lines through a closed door and walks away; elder delivers lines one and two; every adult states the four parts | | | | | |
| `SEC-3` Mutual aid and CERT | Three neighbours with capability and reciprocity; one conversation evidenced by a date and something new learned; dated course registration | | | | | |
| `SEC-4` Legal reality | Dated written answers from three named authorities, and a signed minute confirming every adult heard them | | | | | |

### TIER 4 — MOBILITY AND MOVEMENT (weeks 10–11)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `MOV-1` Per-person bags | A four-column worksheet per person; every bag lifted and carried to the door by its named carrier; a second lift by the backup | | | | | |
| `MOV-2` The mobility plan | One page: route, two lifters with separate jobs, a measured time with a date, the doubled time, a script, a stop rule | | | | | |
| `MOV-3` The timed assisted evacuation drill | Two clean daytime runs and one night run; **last** person timed; nobody hurried; one change made between runs | | | | | |
| `MOV-4` Rendezvous and comms | Two rally points on every card in every bag; an out-of-area contact who can state them back; a confirmed tier-two destination | | | | | |

### TIER 5 — INTEGRATION (week 12)

| Module | What the assessor must see | Date | Rating | Demonstrated by | Assessor | Notes |
|---|---|---|---|---|---|---|
| `INT-1` The full 72-hour simulation | The household assessed, not coached; no rule broken once; decision card consulted and logged; medication plan executed at hour 24 | | | | | |
| `INT-2` The debrief | Every failure named with a date; each fixed with an owner or consciously accepted in writing; scorecard re-scored; one change committed | | | | | |
| `MOR-1` Morale and mental health | A no-power activity store named and located; the elder's job written and agreed with them; adult rest rule naming who takes over | | | | | |

**Count the closed modules:** DEMONSTRATED or better: ______ of 39. CAN TEACH IT: ______.

---

## 13.4 The written checks — recorded separately

These two are not like the others and get their own page, because a 10/10 is a fact and a
"mostly" is not. Both are closed book. Both are taken by every adult. Both are re-taken after
a re-teach, and the retake is recorded, not hidden.

### `MED-5` — the "do not do this" list

| Adult | Attempt | Date | Score | Assessor | What was re-taught, if anything |
|---|---|---|---|---|---|
| | 1 | | /10 | | |
| | 2 | | /10 | | |
| | 1 | | /10 | | |
| | 2 | | /10 | | |
| | 1 | | /10 | | |
| | 2 | | /10 | | |

### `FUE-1` — fuel safety

| Adult | Attempt | Date | Score | Assessor | What was re-taught, if anything |
|---|---|---|---|---|---|
| | 1 | | /10 | | |
| | 2 | | /10 | | |
| | 1 | | /10 | | |
| | 2 | | /10 | | |
| | 1 | | /10 | | |
| | 2 | | /10 | | |

---

## 13.5 The children's page — eight and over

Not a certificate, and not a rating of the child's character. It records that a child was
taught the things a child can do, and that they did them, because in an outage the child who
can unlock the door for help and say the address is worth more than any adult's good
intentions. Every line is marked **shown** when the child did it themselves, in their own
words, without prompting.

| Child | Age | Says the address and the emergency number out loud | Knows the two ways out and the meeting place | Never goes back inside | Door script, three lines, through a closed door | Knows the neighbour's door | Own bag, carried to the door | Date | Adult who watched |
|---|---|---|---|---|---|---|---|---|---|
| | | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | | |
| | | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | | |
| | | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | | |

---

## 13.6 The Stage 1, 2 and 3 award requirements

There are three stages. The stage number is the label; the word after it is a description of
what the household can do, not a status anyone confers. Nobody is "an Operational household"
in the way a person is a licensed electrician. The stages exist so a household can see how far
along it is without inventing a percentage.

### STAGE 1 — FOUNDATION

**Requirement: every module in Tier 0 and Tier 1 rated DEMONSTRATED or better.**

That is twelve modules: `BAS-1` to `BAS-4`, and `WTR-1`, `WTR-2`, `WTR-3`, `WTR-4`, `FOD-1`,
`FOD-2`, `FOD-3`, `SAN-1`, `SAN-2`, `CO-1`. A household at Stage 1 has a roster, a medication
list, a signed decision card, two weeks of drinking water, a pantry, a way to cook outside, a
working toilet plan and CO alarms that have been tested.

| Condition | Met? | Date |
|---|---|---|
| All four Tier 0 modules DEMONSTRATED | ☐ | |
| All ten Tier 1 modules DEMONSTRATED | ☐ | |
| `MED-5` and `FUE-1` are not required at Stage 1, but if taken, the scores are recorded | ☐ | |
| Every adult has read the log and knows what is still NOT YET | ☐ | |
| Household rating applied — the lowest individual rating, not the best | ☐ | |

**Signed as complete by:** ______________________ date ____/____/______

### STAGE 2 — OPERATIONAL

**Requirement: Stage 1, plus Tier 2 and Tier 3, with every life-critical item at CAN TEACH
IT.** `DRILL-1` must also be closed — a household that has not lived 72 hours on its own
stores has not been tested, and a stage awarded without the drill is a claim, not a record.

Life-critical items at CAN TEACH IT: `WTR-2`, `WTR-3`, `FOD-2`, `FOD-3`, `SAN-1`, `SAN-2`,
`MED-2`, `MED-3`, `MED-4`, `MED-6`, `WTH-1`, `WTH-2`, `FIR-1`, `CLO-1`, `SHE-1`, `SHE-2`,
`SEC-2`. `MED-5` and `FUE-1` at 10/10 for every adult. `DRILL-1` DEMONSTRATED by the household.

| Condition | Met? | Date |
|---|---|---|
| Stage 1 complete and dated | ☐ | |
| All eleven Tier 2 modules closed | ☐ | |
| All six Tier 3 modules closed | ☐ | |
| `DRILL-1` closed with the screen signed and 72 hours logged | ☐ | |
| Every life-critical item at CAN TEACH IT | ☐ | |
| `MED-5` and `FUE-1` at 10/10, every adult | ☐ | |
| The security score sheet scored twice, on two days | ☐ | |
| Every adult has read the log and signed below | ☐ | |

**Signed as complete by:** ______________________ date ____/____/______

### STAGE 3 — HOUSEHOLD READY

**Requirement: all six tiers closed, `INT-1` passed as an assessment, and `INT-2` debrief
closed.** All thirty-nine modules. The simulation is not a rehearsal — the household is
observed and written down, not coached, and a single indoor flame or a single touch of the
building main fails it.

| Condition | Met? | Date |
|---|---|---|
| Stage 2 complete and dated | ☐ | |
| All six Tier 4 modules closed | ☐ | |
| `INT-1` passed, assessed, with no rule broken on the day | ☐ | |
| `INT-2` debrief closed: every failure fixed with an owner, or accepted in writing | ☐ | |
| The debrief committed to exactly one change for the next thirty days | ☐ | |
| Every adult has read the log and signed below | ☐ | |

**Signed as complete by:** ______________________ date ____/____/______

### If a stage is not reached

Most households do not reach Stage 3, and the program would rather say so than sell the idea
that everyone does. A household that closes Tier 0 and Tier 1 and stops has done the things
that kill people first: water, food safety, CO, sanitation, and a signed plan. That is a real
result and it is recorded here as one. Write the stage you reached, write the date, and write
which modules are still NOT YET. An honest Stage 1 is worth more than a fictional Stage 3,
and it is the only one that survives a question.

---

## 13.7 The certificate

Three stages, one layout. The certificate is a single page, printed at home, on the household's
own paper. It carries no seal, no crest, no ribbon, no "certified" badge, no hologram, no
serial number and no issuing body — because there is no issuing body, and inventing one that
sounds like an institute would be the exact deception this program exists to avoid.

### 13.7.1 The framing paragraph — printed in full, in the body of every stage

> **What this page is.** This page records that the household named above practised the
> competencies listed on the dates listed, and that a household member watched them do it.
> The assessor is a member of this household with no independent qualification of any kind:
> they are not a clinician, an instructor, an inspector or an examiner, and they hold no
> certification that would let them assess anyone outside this home. This is not an accredited
> qualification. It is not recognised by any school, employer, licensing body, insurer,
> landlord or health service, and no organisation has endorsed, approved or reviewed it. It
> confers no legal, medical or employment status, and it must not be presented as one. It
> certifies only that the named household demonstrated the listed competencies on the listed
> dates — nothing about the household's competence on any other day, and nothing about any
> other household.

That paragraph is not optional, not abridged, and not set smaller than the rest of the page.

### 13.7.2 Certificate — STAGE 1 — FOUNDATION

```
+-------------------------------------------------------------------+
|                                                                   |
|              HOUSEHOLD COMPETENCY RECORD — STAGE 1                |
|                          FOUNDATION                               |
|                                                                   |
|  Household: ____________________________________________________  |
|  Address:   ____________________________________________________  |
|                                                                   |
|  Tier 0 and Tier 1 of this program were demonstrated, on the      |
|  dates recorded in the log that accompanies this page.            |
|                                                                   |
|  Modules covered:  BAS-1  BAS-2  BAS-3  BAS-4  WTR-1  WTR-2       |
|                    WTR-3  WTR-4  FOD-1  FOD-2  FOD-3  SAN-1       |
|                    SAN-2  CO-1                                    |
|                                                                   |
|  Log closed on: ____/____/______                                  |
|                                                                   |
|  Assessed by (household member): _______________________________  |
|  Signed: ______________________________  Date: ____/____/______   |
|                                                                   |
+-------------------------------------------------------------------+
|  WHAT THIS PAGE IS                                                |
|                                                                   |
|  This page records that the household named above practised the   |
|  competencies listed on the dates listed, and that a household    |
|  member watched them do it. The assessor is a member of this      |
|  household with no independent qualification of any kind: they    |
|  are not a clinician, an instructor, an inspector or an examiner, |
|  and they hold no certification that would let them assess        |
|  anyone outside this home. This is not an accredited              |
|  qualification. It is not recognised by any school, employer,     |
|  licensing body, insurer, landlord or health service, and no      |
|  organisation has endorsed, approved or reviewed it. It confers   |
|  no legal, medical or employment status, and it must not be       |
|  presented as one. It certifies only that the named household     |
|  demonstrated the listed competencies on the listed dates —       |
|  nothing about the household's competence on any other day, and   |
|  nothing about any other household.                               |
|                                                                   |
|  Modules not yet done, written honestly: ______________________   |
|                                         ______________________   |
+-------------------------------------------------------------------+
```

### 13.7.3 Certificate — STAGE 2 — OPERATIONAL

```
+-------------------------------------------------------------------+
|                                                                   |
|              HOUSEHOLD COMPETENCY RECORD — STAGE 2                |
|                         OPERATIONAL                               |
|                                                                   |
|  Household: ____________________________________________________  |
|  Address:   ____________________________________________________  |
|                                                                   |
|  Stage 1, plus Tier 2 and Tier 3 of this program, were            |
|  demonstrated on the dates recorded in the accompanying log,      |
|  with every life-critical item taught on to another member of     |
|  this household who then did it themselves. The 72-hour           |
|  no-utilities drill was run, or correctly abandoned under the     |
|  drill safety protocol, and is recorded.                          |
|                                                                   |
|  Log closed on: ____/____/______                                  |
|  Drill run on:  ____/____/______                                  |
|                                                                   |
|  Assessed by (household member): _______________________________  |
|  Signed: ______________________________  Date: ____/____/______   |
|                                                                   |
+-------------------------------------------------------------------+
|  WHAT THIS PAGE IS                                                |
|                                                                   |
|  This page records that the household named above practised the   |
|  competencies listed on the dates listed, and that a household    |
|  member watched them do it. The assessor is a member of this      |
|  household with no independent qualification of any kind: they    |
|  are not a clinician, an instructor, an inspector or an examiner, |
|  and they hold no certification that would let them assess        |
|  anyone outside this home. This is not an accredited              |
|  qualification. It is not recognised by any school, employer,     |
|  licensing body, insurer, landlord or health service, and no      |
|  organisation has endorsed, approved or reviewed it. It confers   |
|  no legal, medical or employment status, and it must not be       |
|  presented as one. It certifies only that the named household     |
|  demonstrated the listed competencies on the listed dates —       |
|  nothing about the household's competence on any other day, and   |
|  nothing about any other household.                               |
|                                                                   |
|  Modules not yet done, written honestly: ______________________   |
|                                         ______________________   |
+-------------------------------------------------------------------+
```

### 13.7.4 Certificate — STAGE 3 — HOUSEHOLD READY

```
+-------------------------------------------------------------------+
|                                                                   |
|              HOUSEHOLD COMPETENCY RECORD — STAGE 3                |
|                      HOUSEHOLD READY                              |
|                                                                   |
|  Household: ____________________________________________________  |
|  Address:   ____________________________________________________  |
|                                                                   |
|  All six tiers of this program were demonstrated on the dates     |
|  recorded in the accompanying log. The full 72-hour simulation    |
|  was run as an assessment, observed rather than coached, and      |
|  the debrief was closed with every failure either fixed with a    |
|  named owner or accepted in writing.                              |
|                                                                   |
|  Log closed on:      ____/____/______                             |
|  Simulation run on:  ____/____/______                             |
|  Debrief closed on:  ____/____/______                             |
|                                                                   |
|  Assessed by (household member): _______________________________  |
|  Signed: ______________________________  Date: ____/____/______   |
|                                                                   |
+-------------------------------------------------------------------+
|  WHAT THIS PAGE IS                                                |
|                                                                   |
|  This page records that the household named above practised the   |
|  competencies listed on the dates listed, and that a household    |
|  member watched them do it. The assessor is a member of this      |
|  household with no independent qualification of any kind: they    |
|  are not a clinician, an instructor, an inspector or an examiner, |
|  and they hold no certification that would let them assess        |
|  anyone outside this home. This is not an accredited              |
|  qualification. It is not recognised by any school, employer,     |
|  licensing body, insurer, landlord or health service, and no      |
|  organisation has endorsed, approved or reviewed it. It confers   |
|  no legal, medical or employment status, and it must not be       |
|  presented as one. It certifies only that the named household     |
|  demonstrated the listed competencies on the listed dates —       |
|  nothing about the household's competence on any other day, and   |
|  nothing about any other household.                               |
|                                                                   |
|  This is the highest stage this program awards. There is no        |
|  Stage 4, no instructor level, and nothing that can be taught     |
|  to the public on the strength of it.                             |
+-------------------------------------------------------------------+
```

### 13.7.5 How the certificate may be spoken about

It may be described as: a record of what this household practised, with dates, signed by
someone in the house.

It may not be described as: a certification, a qualification, a licence, a credential, a
diploma, a course completion recognised by anyone, or evidence of professional competence. It
may not be used on a résumé, in a job application, in a care setting, or in any commercial
offer. Nobody may be told they will be "certified" by buying or completing this program, and
that phrase does not appear anywhere in this material.

---

## 13.8 Keeping it true — re-validation

A log records a day. Households change: a new baby, a new diagnosis, a device arriving, an
elder moving in, a member dying. The log has to keep up or it stops being a record and becomes
a souvenir.

| Event | What has to be redone | Date done |
|---|---|---|
| Annually, on a fixed date | Re-score the security sheet; re-date the legal record; re-check every alarm expiry; re-count the pantry and water; re-check the medication list against the boxes | |
| A new person joins the household | `BAS-1`, `BAS-2`, `BAS-3`, `BAS-4`, `CLO-1`, `MOV-1`, `MOV-2`, `MOV-4` | |
| A new device or a new prescription | `BAS-2`, `MED-2`, and the hour-4 / 24 / 72 answers | |
| A member's mobility changes | `MOV-2`, `MOV-3`, `CLO-1`, and the evacuation times in the log | |
| A move | Everything in Tier 3 and Tier 4, plus `WTR-4`, `SHE-1`, `SHE-2`, `SEC-1` | |
| A drill that went badly | `INT-2` — log the failure, fix it or accept it in writing, re-score | |

**Annual review date, written where the household will see it:** ____/____/______
**The person who owns the annual review:** ______________________

### 13.8.1 The re-score page

| Date | What was re-scored or re-run | Result, as a number or a time | What changed | Signed |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

---

## 13.9 The honest ending

Thirty-nine modules is a lot of work for a household that also contains a four-year-old and a
carer, and most households will finish with a log that has gaps in it. The gaps are the useful
part. A log with eleven NOT YETs written next to the module names tells a household exactly
where it would fail; a log with every line ticked and no dates tells it nothing at all.

So: sign what you watched, date what you did, leave blank what you did not do, and print the
certificate for the stage you actually reached. The paper is worth exactly what the log behind
it is worth, and no more — which is the whole point of putting the paragraph on it that says
so.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
