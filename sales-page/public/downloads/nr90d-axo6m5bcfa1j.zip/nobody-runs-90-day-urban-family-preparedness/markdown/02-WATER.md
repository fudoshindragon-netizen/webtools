# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 02 — WATER

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

This document does four jobs. It tells you how much water you actually need over ninety days,
and then tells you the uncomfortable truth about that number. It tells you what to store, where
to put it, and how to keep it from becoming a science project. It teaches four treatment methods
with the exact figures from the federal pages that publish them — including two bleach columns
that people confuse at the cost of a child's stomach. And it tells you where the water inside
your own building is, which of those sources are real, and which is a myth that will make you
sick.

It closes with modules **`WTR-1`** through **`WTR-4`**, which together are Tier 1 of the
program. Nothing in this chapter is finished by reading it.

---

## 2.1 The arithmetic nobody prints

Most preparedness material gives you one line: *one gallon per person per day, store two weeks.*
That line is correct as far as it goes, and it is why thousands of households believe they are
ready when they are not — because this program is not two weeks. It is ninety days.

**The floor — 1 gallon (≈3.8 L) per person per day.** Ready.gov gives one gallon per person per
day for drinking and sanitation, and breaks it down: **¾ gallon (≈2.8 L) is drinking
fluid**, the remainder for food preparation and basic sanitation. That is the federal household
planning figure, and it assumes a few days, not a season.

**The working figure — 2 gallons (≈7.6 L) per person per day.** Ready.gov states that hot
temperatures, exertion and specific needs can **double** the requirement. This program uses 2
gallons, for three reasons that are its own judgement rather than a quote: the household includes
children and older adults, and the same guidance flags both as needing more; sheltering in place
in a city is not a camping trip, because a household with no running water uses water to flush and
to wash hands; and ninety days has no resupply guarantee, so planning the floor means planning a
crisis.

**The hot-weather figure — 2.5 gallons (≈9.5 L) per person per day.** In a heat wave, or in an
unheated building where people are layered up and working to stay warm, need rises further. Treat
2.5 gallons as the number for a household in a heat emergency — and remember from doc 01 that a
heat wave is a mobility decision as much as a water one.

| Household | 1 gal floor | 2 gal working | 2.5 gal hot |
|---|---|---|---|
| 1 adult, 90 days | 90 gal (341 L) | 180 gal (681 L) | 225 gal (852 L) |
| 2 adults, 90 days | 180 gal (681 L) | 360 gal (1,363 L) | 450 gal (1,703 L) |
| 4 people, 90 days | 360 gal (1,363 L) | 720 gal (2,725 L) | 900 gal (3,407 L) |
| 5 people, 90 days | 450 gal (1,703 L) | 900 gal (3,407 L) | 1,125 gal (4,259 L) |

### The admission this chapter is built on

**A household of four cannot store 720 gallons in an apartment. A household of five certainly
cannot store 900.**

Do the physical picture, because the number is abstract until you do. 900 gallons is about 3,400
liters. In the large 45-liter drums sold for exactly this purpose, that is **75 drums**. Water
weighs 8.3 lb per gallon, so 900 gallons weighs **about 7,500 lb — roughly 3,400 kg, or three
mid-size cars** — spread across the floor area you actually have. Residential floors are not
designed for that, and stacking it in one corner of an upper floor is how people crack a ceiling.
There is also the matter of where seventy-five drums go in a flat that already contains furniture,
a bed and a family.

Every honest preparedness product eventually has to say this and most do not, because "store 900
gallons" sells drums. **This program does not sell drums.** It says plainly: **storage alone
cannot solve ninety days of water, and any plan that claims it can is arithmetic theatre.**

So you stop treating "water" as one substance with one storage requirement. You split it, store
what is storable, harvest what the building already holds, learn to make unsafe water safe, and
ration by activity so that drinking water is never spent on a toilet.

---

## 2.2 The four verbs

Everything in this chapter is one of four actions, in descending order of reliability.

**1. STORE.** Water in a container on a known date that you can put your hand on in the dark. The
only water you can count on with certainty, and limited by volume and floor loading — which is
why it is a buffer and not a plan.

**2. HARVEST.** Water already inside your building: the water heater, the toilet tanks, the pipes,
the tub you filled when the warning came. A **one-time draw** that does not refill, and it must be
treated. It buys days, not months — and days are frequently the difference.

**3. TREAT.** Boiling, bleach, filters, sunlight. This converts harvested and found water into
drinkable water, and it requires fuel, or bleach, or a filter, or sunshine — which means thinking
about it before you need it.

**4. RATION BY ACTIVITY.** The decision about what water is spent on what. Free, highest-leverage
thing in the chapter, and the one nobody teaches.

A household that has a modest buffer, knows where the building's water is, can boil and dose, and
rations by activity will outlast a household with twice the storage and no method.

---

## 2.3 STORE — containers, quantities, placement, rotation

### 2.3.1 Two grades, and why the split is the whole trick

**Grade A — potable.** Drinking, food preparation, brushing teeth, ice, dishes. Has to be clean,
and it is what you count in gallons per person per day.

**Grade B — non-potable.** Flushing, floors, cleaning. Does not need to be drinkable. Needs to be
*there*.

The split works because the ¾ gallon of drinking fluid per person per day is the part that cannot
be compromised and it is small: four people for fourteen days is 42 gallons — about 159 liters,
four 45-liter drums, or 21 two-gallon jugs. That fits in a closet. The flush water is the big
volume, and flush water has cheaper sources: the tub, the water heater, rain, a bucket.

**The storage target for this program is a 14-day Grade A buffer at ¾ gallon per person per day,
plus as much Grade B as the building allows.** That is `WTR-1`. It is deliberately not ninety
days, because ninety days of Grade A storage is not physically possible for most urban households
and pretending otherwise is the failure this chapter exists to prevent.

| Household | Grade A, 14 days (¾ gal/person/day) | In 2-gal jugs | In 45-L drums |
|---|---|---|---|
| 1 adult | 10.5 gal (40 L) | 6 | 1 |
| 2 adults | 21 gal (79 L) | 11 | 2 |
| 4 people | 42 gal (159 L) | 21 | 4 |
| 5 people | 52.5 gal (199 L) | 27 | 5 |

That table is a shopping list you can carry up a stairwell, and for most apartments it is about
the honest limit of what a household will buy, fill, date and rotate.

**Containers.** Commercially bottled water is the easiest correct answer and the one to buy first:
food-grade, sealed, already dated. For self-filled storage, use containers sold for drinking
water, food-grade plastic, screw lid. **Do not use containers that held anything else** — milk
jugs are the classic mistake, because the plastic is thin, the handle traps water, and the residue
feeds bacteria within weeks. No glass in a building with small children.

**Sanitising containers before filling — the Ready.gov method.** Clean thoroughly with dishwashing
soap, then sanitise with a solution of **one teaspoon of unscented liquid household chlorine
bleach per quart of water.** Note the concentration: that is a *container-sanitising* solution,
roughly forty times the drinking-water dose in §2.6. It is for the inside of a bottle, poured out,
never for anything a person drinks.

**Fill to the top.** Air space is where things grow. Fill until it overflows, cap, store cool and
dark.

### 2.3.2 Rotation — the six-month clock

**Ready.gov: water that has not been commercially bottled should be replaced every six months.**
Put it in the calendar with the clocks going forward and back — the same day you test the smoke
alarms — and write the fill date on the container in marker. A container with no date is one you
will not trust and will not drink, which makes it furniture, not storage. Bottled water carries
its own best-by date; rotate on that.

**Rotate without waste.** The water you rotate out flushes the toilet, waters plants, washes the
floor. Rotate on a weekend, use the outgoing water that day, refill, re-date. Two hours, twice a
year. Do not store water in a car, a boiler cupboard or a south-facing windowsill — heat degrades
the container and encourages growth.

### 2.3.3 Placement, and the floor-loading reality

- **Low, spread, on structure.** Ground floor, along a wall, across several rooms. Never all in
  one closet on an upper floor, never on a balcony that was not built for it, never on a high
  shelf where a fall becomes an injury.
- **Out of the light**, and **where it will not freeze** — a frozen container splits.
- **Out of the way of the door you will use in the dark.** You will carry this at 2 a.m.
- **One container accessible without moving anything.** The first gallon is the one that matters.

### 2.3.4 Twenty minutes that changes the arithmetic

When a warning comes — a hurricane track, a boil-water advisory, a grid warning — **fill
everything that holds water before you need it**: the tub, every pot, every jug, every bucket, the
sink. That water is Grade B, for flushing and cleaning, and a full bathtub is on the order of
fifty gallons of it. This is plain reasoning, not a quoted protocol. Label it, cover it, never
drink it, and never leave a toddler near it unattended — a full tub is a drowning hazard, and that
risk is immediate in a way the outage is not.

---

## 2.4 HARVEST — water inside the building

Everything here is a **one-time draw**. It does not refill. It must be treated. Its purpose is to
buy days while you solve the next problem.

**The water heater tank.** CDC lists water from "your home's tap water heater tank — the tank that
connects to the water that comes out of your faucets and showerheads." A genuine source, and a
**one-time draw of roughly 30–50 gallons in a typical house**, less in an apartment with a smaller
tank. Treat the figure as "one tankful, once", not a number you can bank. Two hard rules: **shut
off the power or gas before draining** — draining a live electric element destroys the heater and
creates a shock and scald risk — and **never drain a shared building system.** If your hot water
comes from a building boiler rather than a tank in your own unit, that is not your tank to open.

**The toilet tank, never the bowl.** CDC: water from "your home's toilet tank (**not from the
bowl**), if it is clear and has **not been chemically treated** with toilet cleaners such as those
that change the color of the water." A tank with a blue tablet is out. The bowl is never a
drinking source, no matter how it looks.

**Shutting off the main valve.** CDC notes you may need to shut off the main water valve to your
home to prevent contaminants entering the pipes. Water already in the plumbing is a small
one-time volume, and shutting the valve is what keeps it clean when pressure drops and the mains
draw back. Know where your valve is now; in an apartment it may be a unit valve in a service
cupboard, and you should confirm with your landlord or super which valve is yours. **Never touch
the building main or the sprinkler riser.**

**Swimming pools and spas — hygiene only.** CDC: pool and spa water "can be used for personal
hygiene, cleaning, and related uses, but **not for drinking.**" It is chemically treated and may be
saltwater. It does not go in a drinking container, and it does not go in a pot that will later hold
food.

**Rainwater.** CDC lists it among the options to consider. Assume contamination: roof and gutter
debris, bird droppings and grit are normal in a city. Grade B, and treat it hard if you intend to
drink it.

### 2.4.1 What is never a source

- **Radiators and heating boilers.** CDC: "**Never** use water from radiators or boilers that are
  part of your home heating system for drinking, cooking, or hygiene. This water could make you
  sick." The most repeated urban myth in the field, and a hard no even for washing.
- **Water with fuel, chemicals or radioactive material in it.** CDC: you "**cannot** make water
  containing fuel, toxic chemicals, or radioactive materials safe by boiling or disinfecting it."
  Boiling concentrates contaminants; it does not remove them.
- **The toilet bowl.** Not a source. Ever.
- **Sprinkler systems and decorative water features** — the first is not a potable system, the
  second is a bacterial soup.

### 2.4.2 The high-rise fact that changes everything

Above roughly the sixth floor, the taps die with the power. Not because the water is gone but
because **city pressure needs a booster pump** to get water up that high, and the pump needs
electricity. The mains water is fine. The pressure is gone. Your tap will hiss and stop.

Two consequences. **The building's water is still there and you cannot reach it**, so a high-floor
household's buffer is worth more than a ground-floor household's and should be larger. And **the
same pumps serve the flush water**, so a high-rise household loses the toilet at the same moment
it loses the tap. Doc 04 covers the sanitation consequence. From the water side: **above the sixth
floor, add two days to your Grade A target and buy the buckets before the event.**

---

## 2.5 TREAT — boiling

**Boiling is the safest method.** That is Ready.gov's own wording, and it is the default whenever
you have fuel and a pot, because it kills bacteria, viruses and protozoa at once — including the
parasites *Cryptosporidium* and *Giardia*, which chemical disinfection handles less well.

| Situation | Time | Source |
|---|---|---|
| Ordinary altitude | **Rolling boil, 1 full minute** | Ready.gov, EPA |
| Above 5,000 ft (1,000 m) | **Rolling boil, 3 minutes** | U.S. EPA |

A "rolling boil" means bubbles breaking the surface and not stopping when you stir. Not a simmer,
not steam, not "almost". Start counting when it rolls.

**On the altitude conflict, printed both ways because the sources differ:** EPA says three minutes
above **5,000 ft**; CDC says three minutes above **6,500 ft**; Ready.gov gives no altitude rule at
all. **This program uses EPA's 5,000 ft figure**, because it is the more conservative of the two
and comes from the federal page dedicated to emergency disinfection. **A local boil-water advisory
always overrides every number on this page** — it knows something about your specific system that
this document does not.

**What boiling does not do.** EPA: boiling and disinfection "will not destroy other contaminants,
such as heavy metals, salts, and most other chemicals." Boiling actually makes some of them worse,
because the water leaves and the contaminant stays. Boiling is for **microbiological** danger; for
chemical danger there is no household method in this program, and the answer is a different
source.

**The procedure.**

1. **Cloudy water: settle and filter first** — clean cloth, paper towel or coffee filter (EPA).
   Sediment protects germs from heat and makes the water taste of mud.
2. **Rolling boil, held** for one minute, or three above 5,000 ft.
3. **Cool naturally, covered.** No ice, no fridge, no pouring hot into plastic.
4. **Store in clean containers with covers** — EPA is explicit; open cooled water is
   re-contaminated water.
5. **Fix the flat taste.** EPA: **one pinch of salt per quart or liter**, or pour between two clean
   containers several times. Ready.gov's version is the pouring alone. Either works; the pinch is
   for taste and nothing else, and it is never scaled up.

**Fuel honesty.** Boiling a gallon takes meaningful fuel, and a household planning to boil ninety
days of drinking water for four people has planned a fuel problem it has not solved. This is why
§2.6 and §2.7 exist. Doc 11 covers quantities and storage, and doc 04's CO rules govern where you
may burn anything: **outdoors or a ventilated balcony only. Never indoors. Never a garage. Never a
flooded basement.** A pot of water is not worth a CO death.

---

## 2.6 TREAT — bleach, and the two columns that are not interchangeable

This is the section to read twice and photocopy. Household bleach is the cheapest treatment
available and the easiest to get dangerously wrong, and the error that hurts people is using the
wrong column.

### 2.6.1 The two concentrations

Household chlorine bleach is sold at two strengths, both common on shelves: **5.25%–6.0% sodium
hypochlorite** ("regular") and **8.25% sodium hypochlorite** ("concentrated").

**These are not interchangeable. 8.25% bleach dosed at the 6% rate is an overdose** — roughly a
third more chlorine than the water needs, wrong in taste and smell, a particular risk to a child
who drinks it, and entirely avoidable by reading one line on the label.

**Read the label. Find the sodium hypochlorite percentage. If the label does not state it, do not
use that bottle for water.**

### 2.6.2 EPA's dose table, both columns

Source: U.S. EPA, *Emergency Disinfection of Drinking Water*.

| Volume of water | **6% bleach** | **8.25% bleach** |
|---|---|---|
| 1 quart / 1 liter | 2 drops | 2 drops |
| 1 gallon | **8 drops** | **6 drops** |
| 2 gallons | **16 drops (¼ teaspoon)** | **12 drops (⅛ teaspoon)** |
| 4 gallons | **⅓ teaspoon** | **¼ teaspoon** |
| 8 gallons | **⅔ teaspoon** | **½ teaspoon** |

Note the shape: at one quart the columns agree, and from one gallon upward they diverge. A
household that learned the dose at a quart and scaled up by feel will overdose every time. **Use
the row for the volume you are actually treating. Do not scale.**

### 2.6.3 Ready.gov's version, and why it differs

Ready.gov gives the dose as a kitchen measure: **⅛ teaspoon per gallon**, stir, stand 30 minutes;
if there is no slight bleach odour, repeat the dose and stand another 15 minutes; **if there is
still no chlorine smell, discard the water and find another source.** It specifies bleach must be
**5.25%–6.0%** sodium hypochlorite.

The two sources agree — ⅛ teaspoon of 6% bleach is about 8 drops, EPA's 6% column. The difference
is presentation: Ready.gov uses a spoon, EPA uses drops and adds a column for the stronger bleach.
**Print both. Use drops if you have a dropper**, because drops are less ambiguous than a "teaspoon"
from a cutlery drawer.

### 2.6.4 Rules that apply to both columns

- **Only regular, unscented chlorine bleach suitable for disinfection.** EPA: "Do not use scented,
  color safe, or bleaches with added cleaners." Splashless is out too — it is thickened and does
  not mix the way the dose assumes.
- **Fresh bleach.** Use bleach stored at room temperature for **less than one year**. Bleach loses
  strength as it sits; a three-year-old bottle is not a weaker dose, it is an unknown dose. Date
  it when you buy it.
- **Double the dose if the water is cloudy, colored, or very cold.** EPA's rule, and the one
  people skip in winter. Cold slows the reaction; cloudiness shields germs.
- **Stir and let stand 30 minutes.** Contact time is the treatment. A dose with no wait is wasted.
- **Then smell it.** Slight chlorine odour means it worked. No odour: repeat the dose, wait another
  15 minutes. Still nothing: **discard the water** — the chlorine is being consumed by something
  in it, and that something is why you were treating it.
- **Too strong?** Pour between clean containers and stand a few hours. Do not dilute with untreated
  water.
- **Use a clean dropper**, and **treat, do not store indefinitely** — treated water is not sterile.

### 2.6.5 What not to do with bleach

- ❌ **Never use pool chlorine, calcium hypochlorite or stabilised pool tablets** as a substitute.
  Neither EPA nor Ready.gov authorises this for drinking water, there is no pool-shock recipe in
  this program, and the concentration is uncontrolled and caustic.
- ❌ **Never use bleach whose label does not state a percentage.**
- ❌ **Never substitute iodine or other water-treatment products** — Ready.gov states iodine
  products "are not recommended and should not be used." Iodine is a particular problem in
  pregnancy and with thyroid conditions.
- ❌ **Never exceed the dose "to be safe."** Over-chlorination is a poisoning risk, and children
  are the ones it hurts.
- ❌ **Never drink the bleach solution**, and never treat bleach as a personal disinfectant to be
  swallowed. In water treatment it is a measured dose for *water*, never for a person.
- ❌ **Never use bleach on water you suspect of chemical contamination.** It does not remove
  chemicals, and the smell of bleach will convince you it is safe when it is not.
- ❌ **Never use bleach instead of boiling when boiling is possible.** Ready.gov calls boiling the
  safest method, and it is right.

---

## 2.7 TREAT — filters and UV

Filters are where the marketing is loudest and the science narrowest. Learn the accurate statement
exactly:

> **A filter of the right pore size removes parasites and bacteria. It does not remove viruses.
> Filter, then disinfect or boil.**

Everything below is from CDC's emergency water page.

| Claim | CDC's position |
|---|---|
| A filter makes water safe | **No.** "Portable water filters do not remove all types of germs from water." |
| **Viruses** | Portable filters **will not remove viruses.** |
| **Bacteria** | Needs an **absolute pore size of 0.3 micron or smaller.** |
| **Parasites** (*Giardia*, *Cryptosporidium*) | Needs an **absolute pore size of 1 micron or smaller.** |
| The correct sequence | **Filter first, then add a chemical disinfectant** to the filtered water, "because the disinfectant will kill any viruses and bacteria." |
| Boiling vs chemicals | "Boiling is the best way to kill germs in water." Disinfectants "do not work as well as boiling for killing some germs, including the parasites *Cryptosporidium* and *Giardia*." |
| **UV units** | Kill germs "in small amounts of clear water"; UV "does not work well in cloudy water because small particles can block germs from the light." **Filter first.** |

Practical consequences: **a 0.3-micron absolute filter plus a bleach dose is a complete treatment
chain** for microbiological risk, and it costs less fuel than boiling — that pairing is the
backbone of a no-fuel plan. **A kitchen "water filter" pitcher is not this**; those are for taste
and chlorine removal on already-safe municipal water. **A filter does not remove chemicals**
either. **Filters clog** — a silt-heavy source kills a cartridge in a day, so pre-filter through
cloth always. **Store spare cartridges**, because a filter with no spare has a known expiry date.

---

## 2.8 TREAT — SODIS, the last resort that works

Solar disinfection is included because a household that has run out of fuel *and* bleach still has
the sun, and because it genuinely works against the things that cause diarrhoeal illness. It is
also the weakest method here and must be understood as such.

**CDC's method, exactly:** clean, **clear plastic** bottles filled with **clear** water; **laid on
their side** in the sun (laying them down "allows the sun's rays to kill more germs", and a **dark
surface** underneath helps further); **6 hours if sunny, 2 full days if cloudy.**

**The limits, as plainly as the method:** SODIS is a **reduction method, not sterilisation** — CDC
frames it as "improving the quality" of water in an emergency. **It does not work well in cloudy
water**, because particles shade the germs; if you cannot see through the bottle it is not your
method. **It removes nothing chemical.** And it is a daylight method with a two-day worst case, so
a household needing water today cannot use the cloudy-day version. Bottles must be clear PET — not
colored, not frosted.

**Where it sits:** below boiling, below filter-then-bleach, above nothing. It is what you do on day
nine when the fuel is gone and the bleach is gone, and having thought about it in advance is the
difference between using it correctly and guessing.

---

## 2.9 RATION BY ACTIVITY — the free half of the plan

This is the section that makes a 14-day buffer behave like a 30-day buffer. It costs nothing and it
is almost never taught. The principle: **water is not one budget, it is a stack of budgets, and the
drinking budget is the only one that cannot move.** Every allocation below is decided in advance,
in writing, so it is not decided by a thirsty person at 3 a.m.

Ready.gov's own split gives the frame: **¾ gallon (≈2.8 L) per person per day is drinking fluid**,
the rest of the gallon for food preparation and sanitation. This program keeps that split and
adds the 2-gallon planning figure on top for a household with no running water.

| Activity | Per person per day | Reducible? | Notes |
|---|---|---|---|
| **Drinking fluid** | **¾ gal (≈2.8 L)** | **No** — protected budget | Doubles in heat. Never rationed to make a flush work. |
| Food preparation | ~¼ gal | Slightly — cook once, eat twice | Grade A. |
| **Handwashing** | Small, non-negotiable | Frequency can drop, practice cannot | Soap and 20 seconds matter more than volume. Doc 04. |
| **Dishwashing** | Moderate | Yes — fewer dishes, one pot | Treated water only. Doc 04. |
| **Toilet flushing** | **Large — the biggest line item** | **Yes, dramatically** | **Grade B only. Never Grade A.** Doc 04. |
| Personal hygiene | Moderate | Yes | Grade B, away from wounds and mouths. |
| Laundry | Very large | Near-eliminated | Hand-wash smalls only. Doc 04. |

The biggest lever is the one everybody underestimates: **toilet flushing consumes more water per
person per day than drinking does, in a household with a conventional toilet.** One flush is on the
order of one to two gallons. Four people flushing four times a day is sixteen to thirty-two gallons
— the entire stored drinking budget for four people, spent on urine.

**So the ration rule is one sentence: Grade A never touches a toilet.** Bucket-flush from Grade B,
from the tub, from the water heater, from rain. Doc 04 gives the method and the legal endgame for
the waste; from the water side you only need the separation.

### 2.9.1 The household water card

One page, kept where the water is (`WTR-1` requires it):

1. **Grade A total stored, in gallons, with dates.** One number.
2. **People, and anyone who needs more** — ill, pregnant, breastfeeding, or on a medication that
   changes fluid balance. **If anyone is on a prescribed fluid restriction, their limit goes here
   in a different color and overrides the household figure** (see doc 03 §3.9.3).
3. **The daily allocation:** ¾ per person drinking + ¼ food prep, as a number for *this* household.
4. **Days of Grade A at that allocation.** Divide. That is the real buffer, and it is almost always
   smaller than the household believed.
5. **The trigger:** at what day-count do you move to branch 2 or 3? Doc 01 §1.9.2 gives the water
   triggers; write the household's own number.
6. **Who may draw from Grade A**, and who may not. With children in the house, say it out loud
   rather than assuming it.

### 2.9.2 What you do not ration

- **Drinking water for children, and for anyone ill.** A child with diarrhoea needs fluid, and
  restricting it is how a manageable illness becomes a hospital trip. Doc 06 covers rehydration and
  carries the hard rule: **pharmacy sachet first, and this program does not publish a household
  salt-and-sugar recipe, ever.** A wrong ratio is worse than plain water.
- **Water for handwashing** after the toilet and before food — the cheapest infection control
  there is.
- **Water for anyone's medication.** A dry swallow is its own problem.

**And one accounting line:** Ready.gov says do not drink carbonated or caffeinated beverages
*instead of* water, because "caffeinated drinks and alcohol dehydrate the body which increases the
need for drinking water." That is not a moral position, it is arithmetic. In a 90-day water plan, a
beer is a negative.

---

## 2.10 GREY WATER — the honest version

**Read this framing first: no federal source retrieved for this program gives household greywater
reuse rules.** The dosing, the storage limits, the permitted uses — none of it is in the brief, and
this program does not invent numbers. What follows is **plain reasoning presented as plain
reasoning**, and deliberately more conservative than anything you will find online.

Greywater here means water already used for washing — hands, dishes, floors, bodies. Not sewage.
Not water that has touched a toilet.

1. **Greywater is Grade B and never becomes Grade A.** No amount of filtering, boiling or bleaching
   in a household converts used wash water back into drinking water. Retire the idea.
2. **Use it within 24 hours or pour it out.** Standing greywater grows things fast. A lidded,
   labelled, dated bucket; past the date it goes down the drain.
3. **Flushing and floors only.** Not dishwashing, not handwashing, not a sponge bath, not near a
   wound, not near food.
4. **Never store it in a container that has held or will hold drinking water.** Physically separate
   containers, different colors, different places. This is the rule that prevents the accident.
5. **Never pour it where a child plays or a pet drinks.**
6. **Check local rules.** Some jurisdictions restrict greywater discharge, and in a multi-unit
   building the drain is shared property — in an apartment, "down the drain" is usually the right
   answer and the garden is not available.
7. **Root zone only** on anything edible, never the leaves, and wash before eating.

**What this is not:** not a reuse system, not a plan for compost-toilet leachate, not a method for
making one flush do the work of two. Those are real topics with real engineering, none of it
sourced here, so none of it published here.

---

## 2.11 Module `WTR-1` — Store a 14-day buffer

> **Tier 1 — LIFE SUPPORT. The module that turns a belief into a number.**

**Objective.** Fill, date, log and rotate a 14-day Grade A drinking-water buffer at ¾ gallon per
person per day, plus whatever Grade B the household can hold, and produce a one-page water card
stating the household's real days of supply and its branch-2 trigger.

**Chapters.** `02 §2.1`–`§2.3` · `02 §2.9.1` (the card) · `01 §1.9.2` (water triggers) · `10`
(the water log form).

**Drill — fill, log, rotate.** Two hours, once, plus one rotation.

1. **Count the household** from the `BAS-1` roster, noting anyone who needs more.
2. **Calculate Grade A:** ¾ gal × people × 14 days. Write the number down before you shop.
3. **Buy containers** — food-grade and lidded, or buy bottled water. No milk jugs.
4. **Sanitise and fill** — dish soap, then the one-teaspoon-per-quart bleach solution (§2.3.1),
   poured out, then fill to overflowing and cap.
5. **Date every container** in marker, on the container, not on a list.
6. **Place it** low, spread, out of light, out of the way of the dark route.
7. **Complete the water card**, including the real days-of-supply figure and the trigger day.
8. **Rotate one container on the spot** to prove the procedure, and calendar the next rotation.

**Observable pass criteria — all six, or it does not pass:**

- Grade A stored equals or exceeds ¾ gal × household size × 14 days, **counted, not estimated.**
- **Every container carries a fill date written on it.**
- The water log is filled in: container, volume, date filled, next rotation.
- The water card exists on one page and states **the real days of supply** — a number, not "about
  two weeks".
- The card names **the branch-2 trigger** from doc 01 §1.9.2 in the household's own words.
- A rotation date is in the calendar within six months, and the household can state the rule
  (Ready.gov: replace non-commercially-bottled water every six months).

**Assessment.** By an adult who did not do the filling, or a neighbor or CERT contact in a
single-adult household. Rated **NOT YET / DEMONSTRATED / CAN TEACH IT**. Pass level:
**DEMONSTRATED**. The count and the dates are checked by physically inspecting containers, not by
asking.

**Realistic hours.** 2 hours for the first fill; about 20 minutes per rotation thereafter.

**Who must be able.** One adult to DEMONSTRATED. **Every adult and every child over eight must be
able to state where the water is and that Grade A is not for the toilet** — the age-appropriate
competency, and the one that gets tested in a real outage.

---

## 2.12 Module `WTR-2` — Boil water safely

> **Tier 1 — LIFE SUPPORT. Life-critical: the pass level is CAN TEACH IT.**

**Objective.** Bring four liters to a rolling boil for the correct time for the household's
altitude, cool it covered, store it covered and correct the flat taste — outdoors or on a
ventilated balcony, with CO alarms installed and tested first.

**Chapters.** `02 §2.5` · `04` (CO, fire, and the outdoor/ventilated-balcony rule) · `11` (fuel).

**Prerequisite — hard gate.** **`CO-1` must be complete before this drill runs.** No combustion
anywhere in this program happens before CO alarms are installed and tested.

**Drill — four liters, timed, outdoors.** Forty-five minutes.

1. **State the household's altitude** and therefore the time: **1 minute, or 3 minutes above
   5,000 ft.**
2. **Cloudy water?** Settle and filter through cloth, paper towel or coffee filter first.
3. **Set up outdoors or on a ventilated balcony.** Never indoors, never a garage, never a flooded
   basement, never a stairwell. State the reason aloud.
4. **Boil.** Rolling boil, full time, timed with a clock — not judged by eye.
5. **Cool covered**, naturally, off the heat, lid on.
6. **Store in a clean, covered, dated container.**
7. **Fix the taste** by pouring between two clean containers, or one pinch of salt per quart.
8. **Say the limits aloud:** boiling does not remove heavy metals, salts or most chemicals, and a
   local boil-water notice overrides these times.

**Observable pass criteria — all six:**

- The correct time is stated **before** the pot goes on and matches the household's altitude.
- The boil is a **rolling** boil, sustained for the full timed period, observed by the assessor.
- The pot is **outdoors or on a ventilated balcony**, and the household can state why indoors, a
  garage and a flooded basement are excluded.
- Water is cooled **covered** and stored in a **clean, covered, dated** container.
- The flat-taste correction is demonstrated.
- The household can state, unprompted, **two things boiling does not remove** and that a local
  notice overrides this document.

**Assessment.** By an adult who did not boil, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. Pass level: **CAN TEACH IT** — the assessor asks the household to
walk a second person through the procedure and marks whether the explanation is correct and
complete. A skill held in one head dies with that head.

**Realistic hours.** 45 minutes, plus the `CO-1` prerequisite if not already done.

**Who must be able.** Every adult to CAN TEACH IT. Children over eight must be able to state that
boiling happens outside and that the pot is hot.

---

## 2.13 Module `WTR-3` — Disinfect water with bleach

> **Tier 1 — LIFE SUPPORT. Life-critical: the pass level is CAN TEACH IT. This is the module where
> the two columns are the whole point.**

**Objective.** Correctly disinfect water with household chlorine bleach at the correct dose for the
bleach's actual concentration, for both clear and cloudy water, twice, unassisted, from the printed
tables in this document — and state why the 6% and 8.25% columns are not interchangeable.

**Chapters.** `02 §2.6`, especially the table at §2.6.2 · `02 §2.3.1` (container sanitising, a
different dose) · `10` (the printable water dose card).

**Drill — two batches, clear and cloudy, from the printed table only.** One hour.

1. **Read the bleach label out loud.** State the percentage. If it states none, that bottle is
   disqualified — say so and set it aside.
2. **Select the column.** 6% or 8.25%. Say which and why.
3. **Batch one — clear water, 1 gallon.** Look up the row. **8 drops for 6%, 6 drops for 8.25%.**
   Stir. Start a 30-minute timer.
4. **At 30 minutes, smell it.** Slight odour = done. No odour = repeat the dose, wait 15 minutes.
   Still nothing = **discard and find another source**, and say why.
5. **Batch two — cloudy or very cold water, 1 gallon.** **Double the dose** before anything else.
   Repeat the dose, stir, timer, smell test.
6. **State the sanitising dose separately** — one teaspoon per quart, for containers, poured out,
   never drunk — and confirm the household knows it is not the drinking dose.
7. **Recite the never-list:** no pool chlorine or calcium hypochlorite; no scented, splashless,
   color-safe or added-cleaner bleach; nothing without a stated percentage; no overdose "to be
   safe"; no bleach on chemically contaminated water; no bleach instead of boiling when boiling is
   possible; no drinking the solution.

**Observable pass criteria — all seven, no partial pass:**

- **Both batches dosed correctly, from the printed table, with the correct column for the actual
  bleach in the house.** An 8.25% bottle dosed at the 6% rate is an automatic fail.
- **The cloudy/cold batch is doubled**, and the household can state why.
- **30-minute contact time observed**, timed, not estimated.
- **The smell test is performed**, and the re-dose-then-discard rule stated correctly.
- The **container-sanitising dose is distinguished** from the drinking dose without prompting.
- **Five of the seven never-list items recited** unprompted; all seven recognized when read out.
- Performed **twice, unassisted** — the second run is the assessed one.

**Assessment.** By an adult who did not dose, or a neighbor/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. Pass level: **CAN TEACH IT**. The assessor deliberately hands over a
bottle of the *other* concentration for the second run and watches whether the household reads the
label before dosing.

**Realistic hours.** 1 hour for both batches; the timer does most of the waiting.

**Who must be able.** Every adult to CAN TEACH IT. **No child doses bleach.** Children over eight
are taught where the bleach is kept, that it is a poison, and to fetch an adult.

---

## 2.14 Module `WTR-4` — Find water inside the building

> **Tier 1 — LIFE SUPPORT. The module that converts "we have nothing" into "we have three days".**

**Objective.** Locate, access and correctly label the non-tap water sources inside the household's
own building — water heater and toilet tanks — with the caveats attached, and produce a written
list of what is a source and what is never a source.

**Chapters.** `02 §2.4` · `01 §1.2.1`–`§1.2.2` · `04` (sanitation, for the flush-water end use) ·
`10` (the water log).

**Drill — find, label, and list.** Ninety minutes.

1. **Find the water heater.** Photograph it. Note the fuel (electric or gas), and whether it serves
   this unit or the whole building — if it is a building system it is **not** yours to drain, and
   that gets written down.
2. **Locate the shut-offs** for the heater and for the unit's water main. Confirm with the landlord
   or super which is the unit valve. **Do not touch the building main or the sprinkler riser** —
   state this aloud.
3. **Check every toilet tank** for a chemical tablet. Any tank with one is struck off and labelled.
   Any without is a source — **tank only, never the bowl.**
4. **Walk the building's other options** and write them down: pool or spa (hygiene only), rain
   capture points, the tub. Note your floor and whether the building needs a booster pump.
5. **Write the never-list** in the household's own words: radiators and heating boilers, the toilet
   bowl, anything with fuel or chemicals in it, the building main.
6. **Label the sources physically** — a sticker or card on the heater cupboard and on each usable
   tank saying what it is and that it must be treated.
7. **Add the harvest volumes to the water card** as a one-time draw, separate from the stored
   buffer, so the household sees both numbers.

**Observable pass criteria — all six:**

- The water heater is **found, photographed, and its fuel type and ownership recorded.**
- The unit shut-off is located and physically demonstrated, and the household can state that the
  building main and sprinkler riser are never touched.
- **Every toilet tank is inspected** and every chemically treated tank is struck off and labelled.
- The never-list is written **in the household's own words**, including radiators/boilers and the
  bowl, and the household can state why each is excluded.
- Sources are **physically labelled** at the source, not only on a list.
- The harvest volume appears on the water card as a **one-time draw**, distinct from stored water.

**Assessment.** By an adult who did not do the walkthrough. Rated **NOT YET / DEMONSTRATED / CAN
TEACH IT**. Pass level: **DEMONSTRATED**, with the never-list at **CAN TEACH IT** — because the
never-list is the part that prevents harm, and it must survive the person who learned it.

**Realistic hours.** 1.5 hours including the landlord call.

**Who must be able.** One adult to DEMONSTRATED for the walkthrough. **Every adult to CAN TEACH IT
on the never-list** — radiators, the bowl, and anything chemical. Children over eight must be able
to point at the water heater cupboard and say "not that tap" if a stranger tells them to drink from
it.

---

## 2.15 Closing the water chapter

Three things should be true of a household that has finished this chapter.

**It knows its real number.** Not "two weeks of water" as a slogan, but a counted figure in gallons,
a date on every container, and a written trigger day at which the decision tree in doc 01 fires. A
household that knows it has eleven days is safer than one that believes it has thirty, because only
the first acts on day eight.

**It can make water safe four ways.** Boiling when there is fuel. Bleach when there is not — with
the right column. Filter-then-disinfect when both run short. SODIS when everything has run out and
the sun is out. Redundancy is the point: any single method fails at exactly the moment you need it.

**It has stopped spending drinking water on urine.** That one separation is worth more days of
supply than any purchase in this document, and it costs nothing but a decision made in advance.

The honest gap is stated where it belongs, at the top: **ninety days of stored water is not
achievable in most urban homes, and this program does not pretend otherwise.** What it gives you
is a counted buffer, the sources inside your own building, four treatment methods with their real
figures, and a rationing rule that makes the buffer last. If the water situation goes beyond that,
the answer is not a bigger drum. It is branch 2 or branch 3 of the decision you already signed.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on.
This is version 1.0, errata date 2026-11-02; corrections are recorded in the README and any
corrected figure is dated. Where EPA, CDC and Ready.gov differ — the altitude rule for boiling, and
the teaspoon-versus-drop expression of the bleach dose — both figures are printed above and the
conservative one is identified.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your
local emergency number. Follow your local health authority's guidance over anything in this guide.
Written for US households.*
