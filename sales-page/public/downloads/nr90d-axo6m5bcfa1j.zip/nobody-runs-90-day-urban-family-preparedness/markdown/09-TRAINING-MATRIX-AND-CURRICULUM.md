# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 09 — TRAINING MATRIX AND CURRICULUM

**Version 1.0 · Errata date 2026-11-02 · Written for households in the United States**

This is the spine of the program. Every other document is a chapter; this one is the
schedule, the standard, and the record. Nothing in it is new advice — every module below
points at a chapter you already have, and every hour in it is an hour you spend doing
something with your hands while another adult watches.

Thirty-nine modules. Six tiers, numbered 0 to 5. Twelve weeks on the calendar, and permission to take
fourteen. Each module closes on a **demonstration**, never on a reading. You can read this
whole program in a weekend and still be at NOT YET on all thirty-nine, and that is the point
of the design rather than a flaw in it.

---

## 9.1 How to read the matrix

Every module carries seven fields, and they mean the same thing in every tier:

- **Objective** — the one sentence that says what is true of the household when the module is done.
- **Chapters** — where the material is. `02 §2.6` means document 02, section 2.6. Documents
  00–08 are the chapters. Document 10 is the forms pack, 12 is this program's question bank and
  answer keys, 13 is the passport. Document 11 (sourcing, budget and fuel) is the chapter that
  covers buying, storing and fuelling; where a module's home chapter is doc 11, the module below
  says so and points at its section.
- **Drill** — the thing you do, and roughly how long the doing takes.
- **Pass** — the observable criteria. "Observable" is doing real work here: an assessor who was
  not in the room cannot award a rating on a description of a task.
- **Rating** — the level this module must reach: **DEMONSTRATED** or **CAN TEACH IT**. Two
  modules (`MED-5`, `FUE-1`) are written checks instead, at 10/10 with no partial pass.
- **Hours** — realistic contact time, not elapsed time. A 72-hour drill is four hours of work and
  seventy-two hours of living.
- **Who must be able** — the person or persons who must reach the rating, and what children over
  eight are expected to know. Capability, never fear.

**Tier is the gate. Week is the calendar.** A module's tier decides which award it unlocks; its
week decides when the household does it. They are not the same axis, and doc 00 §0.4 — the
calendar of record — runs two Tier 2 modules (`FIR-1`, `CLO-1`) in week 8 and two Tier 3 modules
(`SEC-3`, `SEC-4`) in week 10. That is deliberate scheduling, not a numbering error.

---

## 9.2 The assessment model

**Three ratings.** There are no others, and there is no percentage anywhere in this program.

- **NOT YET** — not done, or done once with help.
- **DEMONSTRATED** — done unassisted, to the module's pass criteria, observed by someone else.
- **CAN TEACH IT** — done unassisted *and* taught to another household member who then did it
  themselves. Life-critical skills need this level, because a skill that lives in one head dies
  if that head is injured.

**Who assesses.** By default, an adult who did not perform the task. In a single-adult household,
a neighbour or a CERT contact may witness and initial. If nobody at all is available, score
yourself, date it, and write *self-assessed* next to your initials — a self-assessed line is worth
less and pretending otherwise would be dishonest.

**The household rating is the lowest individual rating.** One adult who cannot restate the three
branches means the household has not passed the module, because that adult is the one who will be
making the call on the day.

**Children eight and over** are rated on age-appropriate competencies — fetching help, the door
script, the rally point, the water station, carrying their own bag. A child is never rated on
whether they were frightened.

**The two written checks.** `MED-5` and `FUE-1` are closed-book, ten questions, **10 out of 10, no
partial pass**, each answer with a one-line reason. Nine is a fail and a re-teach. No adult is
exempted, and nobody takes it open-book "because they wrote it". The question bank and the answer
keys are in doc 12.

---

## 9.3 The six tiers and their gates

**TIER 0 — BASELINE (week 0).** Four modules: the roster, the medical and device inventory, the
documents and cash, the decision card and the meeting. *Gate:* the scorecard in doc 00 §0.5 is
scored and dated, the decision card is signed by every adult, and the household meeting is
minuted. Tier 0 is not preparation for the program; it is the program's floor, and everything
after it is built on facts about your own household that only you can write down.

**TIER 1 — LIFE SUPPORT (weeks 1–4).** Ten modules: water stored, boiled, dosed and found; food
bought, cooked and kept safe; sanitation built and run; and `CO-1`, the CO alarms, which is a
prerequisite for every flame in the rest of the program rather than a topic. *Gate:* all ten at
their stated rating, with `WTR-3` and `FOD-2` at CAN TEACH IT and every adult able to say where
the water is and that Grade A is not for the toilet.

**TIER 2 — HEALTH, WARMTH AND CLOTHING (weeks 4–7).** Eleven modules: the medicine kit and the
continuity plan, rehydration by sachet only, wound care, the "do not do this" list, first aid that
matters here, one warm room, heat illness, fire and CO, fuel safety, and dressing the slowest
member for freezing conditions in five minutes. *Gate:* all eleven at their stated rating, `MED-5`
and `FUE-1` at 10/10 by every adult, and `MED-2` closed — because a household with an unlisted
refrigerated medicine has not finished Tier 2, whatever else it has done.

**TIER GATE — `DRILL-1`, the 72-hour no-utilities drill (end of week 7).** Not a Tier. A gate that
sits between Tier 2 and Tier 3 and is passed by running the drill and by nothing else. It moved
here from week 4 for one reason: it used to run before the medication list existed and before a
single CO alarm was on a wall. For an elder on cardiac, seizure or insulin medication, or a
household with oxygen in it, that is the most foreseeable harm in the entire product. **It runs
only when Tier 0 and Tier 2 are closed, and it is abandoned rather than pushed through if any
exclusion below applies.** The full safety protocol is §9.4.

**TIER 3 — SHELTER, SECURITY AND COMMUNITY (weeks 8–10).** Six modules: shelter and building
reality, high-rise reality, the security assessment, the door protocol, mutual aid, and the legal
position. *Gate:* all six at their stated rating, with the seal-a-room step and the door protocol
at CAN TEACH IT and `SEC-4`'s dated legal record in the folder. Nothing in this tier is a build
specification, and the module texts say so out loud.

**TIER 4 — MOBILITY AND MOVEMENT (week 11).** Four modules: the bags, the mobility plan for the
slowest member, the timed assisted evacuation drill, and rally points and comms. *Gate:* all four
at their stated rating, with `MOV-2` and `MOV-3` at CAN TEACH IT by two adults — two, because one
is a single point of failure. This tier is insurance on a decision you expect *not* to make; the
default in this program is to stay.

**TIER 5 — INTEGRATION (week 12).** Three modules: the full 72-hour simulation run as an
assessment, the debrief, and morale. *Gate:* `INT-1` passed, and `INT-2` closed — every failure
logged and either fixed or **consciously accepted in writing**.

### The awards

- **STAGE 1 — FOUNDATION:** all Tier 0 and Tier 1 modules DEMONSTRATED.
- **STAGE 2 — OPERATIONAL:** adds Tier 2 and Tier 3, with life-critical items at CAN TEACH IT.
- **STAGE 3 — HOUSEHOLD READY:** all six tiers, `INT-1` passed, debrief closed.

These are **stage names, not credentials**. There are no seals, no crests, no "certified" badges
and no issuing body. The certificate in doc 13 states in its own body text that the assessor is a
household member with no independent qualification, that it is not an accredited qualification,
that it confers no legal, medical or employment status, and that it certifies only that the named
household demonstrated the listed competencies on the listed dates. The value is the signed
competency log, not the paper. Nothing in this program, and nothing in its listing, may say "get
certified".

---

## 9.4 The drill safety protocol — printed with the drill, read before it

`DRILL-1` and `INT-1` both run against this list. Every line is a stop condition, not advice.

1. **Pre-drill medical screen.** Exclude any household with a member on mains-powered equipment —
   oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair — or on cardiac, seizure
   or insulin medication not yet covered by `BAS-2` and `MED-2`. **Oxygen in the house plus any
   open flame is a fire death.**
2. **CO alarms installed and tested first** (`CO-1`). No alarm, no drill.
3. **Season gate.** No drill in a cold snap or a heat wave. Above 90 °F a fan *raises* body
   temperature (doc 04 §4.3.1).
4. **Fridge and freezer plan.** Use the exact figures in doc 03 §3.7. The drill will destroy
   $100–300 of food if unplanned. Cook the thawing food first.
5. **Water heater:** shut the power or gas before draining; never drain a shared building system.
6. **Elevators:** nobody runs the drill while anyone may be in the lift.
7. **Unit breaker only** — never the building main, never the sprinkler riser. Confirm the valve is
   a unit valve, notify the landlord or super, and never touch gas or relight a pilot as a drill.
8. **No candles. LED only.** Adult supervision for young children around the bucket toilet and any
   flame.
9. **Abort rule and a named outside check-in person.** Anyone says stop, it stops, no discussion
   and no disappointment. The outside person is told when the drill starts and when it ends.

---

## 9.5 The thirty-nine modules

### TIER 0 — BASELINE

#### `BAS-1` — Household roster and vulnerability map
**Objective.** A one-page roster of every person in the household and every person who visits daily, with what each can and cannot do on their worst day — who cannot walk far, cannot lift, cannot hear, cannot see well in the dark, or cannot be left alone.
**Chapters.** `00 §0.2` · `00 §0.5` · `08 §8.1` · `01 §1.9.1` · `10`.
**Drill.** Two hours. Fill the roster from the household's own knowledge, then walk the flat with the person whose limits you are least sure about and correct the page in their hearing.
**Pass.** Every member and every daily visitor is listed with a named limit and a named workaround; the slowest member is identified **as a person, by name**; the roster states which member cannot be left alone and for how long; the hearing and night-vision limits are recorded because they change the door protocol and the fire plan; and every adult has read the page and can name the slowest member without looking.
**Rating.** DEMONSTRATED by every adult. CAN TEACH IT for the adult who maintains the roster.
**Hours.** 1.5.
**Who must be able.** Every adult to DEMONSTRATED. Children over eight are told, in their own words, who in the house needs help first and whom to fetch.

#### `BAS-2` — Medical and device inventory
**Objective.** Every medication, dose, prescriber and refill date written down, **and** every mains-powered or refrigerated device identified with its runtime, because in an outage the device is the emergency, not the pills.
**Chapters.** `06 §6.1` · `06 §6.2` · `05 §5.1` · `01 §1.9.1` · `10`.
**Drill.** Two and a half hours. Photograph every label; write the list in one sitting with the pill boxes in front of you; then find every device, write down what powers it and for how long, and put the list in the kit and the go-bag.
**Pass.** Every medication is listed with dose, prescriber and refill date; every device is listed with its power source and its runtime on battery or on nothing; the oxygen concentrator, home dialysis, infusion pump, CPAP, powered chair and insulin are explicitly checked for — present or absent, both recorded; the list is photographed, copied, and in two places; and the household can state, unprompted, that this list is what excludes it from `DRILL-1` if any of those devices is in the house.
**Rating.** DEMONSTRATED by every adult who can read the list. CAN TEACH IT for the carer.
**Hours.** 2.5.
**Who must be able.** Every adult to DEMONSTRATED; the designated carer to CAN TEACH IT. Children over eight must know where the list is and that they never move the medicine box.

#### `BAS-3` — Documents, contact card, cash
**Objective.** Copies of the documents that are hard to replace, an ICE card on paper for every member, and cash in the house for the hours when cards do not work.
**Chapters.** `00 §0.6` · `01 §1.10` · `08 §8.5.2` · `10`.
**Drill.** Two hours, plus a trip to a photocopier. Copy the documents, build the ICE card per person, put the out-of-area contact on every card by hand, and put a small amount of cash somewhere named and known to two adults.
**Pass.** Documents are copied and stored in two separate places, one of them off-site or digital; every member including each child carries an ICE card with the out-of-area contact and the two rally points; the cards are **paper**, not a phone; two adults can state where the cash is and what it is for; and the household states, unprompted, that the reason for paper is that a dead battery has no contacts in it.
**Rating.** DEMONSTRATED by every adult.
**Hours.** 2.
**Who must be able.** Every adult to DEMONSTRATED. Children over eight carry their own card and can show it and read the contact's name.

#### `BAS-4` — Family decision card and household meeting
**Objective.** A signed, dated, one-page decision card covering all three branches, and a household meeting in which every adult can state, in their own words, what each branch means and who decides.
**Chapters.** `01 §1.5`–`§1.10` · `00 §0.5` · `00 §0.6` · `10` · `07 §7.3`.
**Drill.** Ninety minutes, once, with every adult present and phones down.
**Pass.** A completed one-page card exists, in ink, dated; all three branches are written in the household's own words, not copied from the book; at least two named triggers per branch, drawn from `01 §1.9`; a named branch-2 destination and a named branch-3 destination, each with a phone number; a named decider and a named alternate decider; every adult has signed and can restate the three branches without reading them.
**Rating.** DEMONSTRATED by every adult; the household rating is the lowest individual rating.
**Hours.** 2, including the calls.
**Who must be able.** Every adult, including the restatement. Children eight and over are told their two jobs and must be able to state them.

### TIER 1 — LIFE SUPPORT

#### `WTR-1` — Store a 14-day buffer
**Objective.** Fill, date, log and rotate a 14-day Grade A drinking-water buffer at ¾ gallon per person per day, plus whatever Grade B the household can hold, and produce a one-page water card stating the real number.
**Chapters.** `02 §2.1`–`§2.3` · `02 §2.9.1` · `01 §1.9.2` · `10`.
**Drill.** Two hours for the first fill, plus one rotation.
**Pass.** Grade A stored equals or exceeds ¾ gal × household size × 14 days, counted not estimated; every container carries a fill date written on it; the water log is filled in; the water card states the real days of supply as a number, not "about two weeks"; the card names the branch-2 trigger in the household's own words; a rotation date is in the calendar within six months.
**Rating.** DEMONSTRATED, checked by physically inspecting containers rather than by asking.
**Hours.** 2 for the first fill; about 20 minutes per rotation.
**Who must be able.** One adult to DEMONSTRATED. Every adult and every child over eight must be able to state where the water is and that Grade A is not for the toilet.

#### `WTR-2` — Boil water safely
**Objective.** Bring four litres to a rolling boil for the correct time for the household's altitude, cool it covered, store it covered and correct the flat taste — outdoors or on a ventilated balcony only.
**Chapters.** `02 §2.5` · `04` (CO, fire, and the outdoor rule) · `11` (fuel).
**Drill.** Forty-five minutes, timed, outdoors.
**Pass.** The correct time is stated before the pot goes on and matches the household's altitude; the boil is a rolling boil sustained for the full timed period, observed; the pot is outdoors or on a ventilated balcony and the household can state why indoors, a garage and a flooded basement are excluded; water is cooled covered and stored covered and dated; the flat-taste correction is demonstrated; the household states, unprompted, two things boiling does not remove and that a local advisory overrides the page.
**Rating.** CAN TEACH IT.
**Hours.** 0.75, plus the `CO-1` prerequisite if not already done.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must state that boiling happens outside and that the pot is hot.

#### `WTR-3` — Disinfect water with bleach
**Objective.** Dose water correctly for the bleach's actual concentration, for clear and for cloudy water, twice, unassisted, from the printed table only.
**Chapters.** `02 §2.6`, especially the table at §2.6.2 · `02 §2.3.1` (a different dose) · `10`.
**Drill.** One hour, two batches, clear and cloudy.
**Pass.** Both batches dosed correctly from the printed table with the correct column for the bleach in the house — an 8.25% bottle dosed at the 6% rate is an automatic fail; the cloudy or cold batch is doubled and the household says why; 30-minute contact time is timed, not estimated; the smell test is performed and the re-dose-then-discard rule stated; the container-sanitising dose is distinguished from the drinking dose without prompting; five of the seven never-list items are recited unprompted and all seven recognised when read out; performed twice, unassisted.
**Rating.** CAN TEACH IT, and the assessor hands over the *other* concentration for the second run.
**Hours.** 1.
**Who must be able.** Every adult to CAN TEACH IT. **No child doses bleach.** Children over eight are taught where it is kept, that it is a poison, and to fetch an adult.

#### `WTR-4` — Find water inside the building
**Objective.** Locate, access and label the non-tap water sources inside the household's own building — water heater and toilet tanks — with the caveats attached, and write down what is a source and what is never a source.
**Chapters.** `02 §2.4` · `01 §1.2.1`–`§1.2.2` · `04` (sanitation, for the flush-water end use) · `10`.
**Drill.** Ninety minutes: find, photograph, label, list.
**Pass.** The water heater is found, photographed, and its fuel type and ownership recorded; the unit shut-off is located and physically demonstrated, and the household states that the building main and sprinkler riser are never touched; every toilet tank is inspected and every chemically treated tank is struck off and labelled; the never-list is in the household's own words, including radiators and boilers and the bowl, with a reason for each; sources are labelled **at the source**; the harvest volume appears on the water card as a one-time draw.
**Rating.** DEMONSTRATED, with the never-list at CAN TEACH IT.
**Hours.** 1.5, including the landlord call.
**Who must be able.** One adult to DEMONSTRATED. Every adult to CAN TEACH IT on the never-list. Children over eight must be able to point at the water heater cupboard and say "not that tap".

#### `FOD-1` — Build the pantry
**Objective.** Calculate the household's real daily and 90-day calorie requirement person by person from the federal table, build and count a pantry meeting **30 days at that rate**, display the gap to 90, and put the days-of-supply trigger on the pantry door.
**Chapters.** `03 §3.2`–`§3.6` · `03 §3.9` for any special diet · `10` · `11` · `01 §1.9`.
**Drill.** Three hours, plus the shopping.
**Pass.** A written per-person calorie figure exists for every member, taken from the table and not from a flat 2,000; the 90-day requirement is calculated and displayed; Layer 1 exists and is verified by inspection to need no cooking, no water and no refrigeration; Layer 2 is counted, not estimated, and meets 30 days; every oil container carries a purchase date and the six-month rotation is in the calendar; the pantry card is on the door and states total calories, days of supply, the gap to 90 and the trigger in the household's own words.
**Rating.** DEMONSTRATED.
**Hours.** 3, plus shopping.
**Who must be able.** One adult to DEMONSTRATED. Every adult must state the household total, the days of supply and the trigger.

#### `FOD-2` — Cook with no power
**Objective.** Produce one hot meal with no mains power, **outdoors or on a ventilated balcony only**, with CO alarms installed and tested first, and state aloud every place the stove may never go.
**Chapters.** `03 §3.8` · `04` (CO and fire rules in full) · `11` · `00 §0.4` · `FUE-1`.
**Drill.** Ninety minutes, one hot meal, outside, timed.
**Pass.** Cooking happens outdoors or on a ventilated balcony — **any indoor cooking is an automatic fail of the module, not a deduction**; the full exclusion list is recited unprompted, including the 20-foot generator rule and "never a garage even with the doors open"; a hot meal is produced for every member with any special-diet portion correct; the one-pot, one-boil method is used and explained; extinguishing is demonstrated, the extinguisher located and PASS recited; the stove is never left unattended, demonstrated rather than stated.
**Rating.** CAN TEACH IT.
**Hours.** 1.5, plus the three prerequisite modules.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must state that the stove lives outside and that they never touch it.

#### `FOD-3` — Keep food safe with no fridge
**Objective.** Recite the FDA time-and-temperature figures from memory, apply them to a real fridge and freezer, make and defend the discard decision on a real item, and state the ice-crystal refreeze rule.
**Chapters.** `03 §3.7` · `04` (flood and sanitation, for disposal) · `06` (refrigerated medication) · `10`.
**Drill.** One hour, with the fridge door open and a thermometer in your hand. Run it in week 1, before the 72-hour drill.
**Pass.** All five FDA figures recited from memory with no prompting — 4 h, 48 h, 24 h, 40 °F and the 4-hour cooler point; both appliance thermometers present and working, verified by the assessor; a written "cook the thawing food first" plan exists for this household's own freezer; the discard decision is made correctly on a presented item and the household states that it is not negotiable; the refreeze rule is stated in both forms, including "you cannot rely on appearance or odour"; the household states, unprompted, that food above 40 °F is discarded.
**Rating.** CAN TEACH IT.
**Hours.** 1.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must know the number 40 and that food that has been warm is not eaten.

#### `SAN-1` — Emergency sanitation: the kit, the handwash, and who decides disposal
**Objective.** Assemble the federal-list sanitation supplies, demonstrate the 20-second handwash standard, state the legality position correctly, and have a named authority and a written trigger.
**Chapters.** `04 §4.6` · `02` · `01 §1.9.3` · `10`.
**Drill.** One hour, plus the call.
**Pass.** The kit is laid out and the gaps written down, with sanitizer at 60% alcohol or more; a 20-second handwash is demonstrated with soap and safe water and the station is sited where the hands are, with a decided runoff destination; the household states, unprompted, that this program prints no disposal rule because disposal is jurisdictional and that asking the local health department is the household's job; the authority is named and the answer is written on the card **with a date** — a blank card is a fail; the trigger is written and signed, names an observable condition, and the household can state that it fires branch 2 or branch 3.
**Rating.** CAN TEACH IT.
**Hours.** 1, plus the call. Run it in week 4, before the 72-hour drill.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must wash their hands properly, unassisted, and fetch an adult rather than handle waste.

#### `SAN-2` — Handwash and dish station, used for a week
**Objective.** Run a handwash station and a dish station for seven consecutive days, with a log, and demonstrate the clean-and-dry rule.
**Chapters.** `04 §4.6.2`–`§4.6.4` · `02` · `10`.
**Drill.** One hour to set up, seven days to run, half an hour to review.
**Pass.** Seven consecutive days logged with key-time ticks and measured water use, and both stations still standing and in use at the end of the week — not packed away; the dish rule is demonstrated, including "let dry completely before reuse"; the sanitizer limits are stated correctly; the household can state its measured hygiene water use per day, which is the number doc 02's buffer has to cover.
**Rating.** CAN TEACH IT.
**Hours.** 1 setup and review, plus seven days of running.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must use the station unassisted for the full week — which is the point of a week rather than an afternoon.

#### `CO-1` — Install and test CO alarms
**Objective.** Carbon monoxide alarms installed where they will wake a sleeping person, tested out loud, and the household able to say why this module precedes every flame in the program.
**Chapters.** `04 §4.2` · `04 §4.2.3` · `04 §4.1.3` · `10`.
**Drill.** One hour. Mount the alarms, press test on each in front of a second adult, note the expiry date on each unit, and rehearse the "the whole household has the flu" rule — because that is what CO poisoning looks like.
**Pass.** At least one alarm audible from the sleeping area and one on each floor the household uses, all tested in front of the assessor; every expiry date written on the log; the household states, unprompted, that no fuel is burned indoors, in a garage, or in a flooded basement, and recites the 20-foot rule for a generator; the "flu" rule is stated — headache, nausea and drowsiness in more than one person at once means get out and call, not sleep it off; and every adult can say that this module is a prerequisite for `FOD-2`, `WTH-1` and `DRILL-1`.
**Rating.** DEMONSTRATED by every adult; CAN TEACH IT for one adult.
**Hours.** 1.
**Who must be able.** Every adult to DEMONSTRATED. Children over eight must know what the alarm sounds like and that they leave the building and stay out.

### TIER 2 — HEALTH, WARMTH AND CLOTHING

#### `MED-1` — Build the medicine kit
**Objective.** Assemble a medicine kit that matches the sourced categories, date and rotate it, and produce the written medication list that makes the kit usable by someone else.
**Chapters.** `06 §6.1` · `05 §5.1` · `10`.
**Drill.** One hour: the box, the dates, the list.
**Pass.** The kit contains the sourced categories and every missing item is written down with a reason; every box is dated and the rotation order is visible; the kit is locked and out of a child's reach; the medication list is complete, photographed and copied to kit and go-bag; the household states, unprompted, that no dose is written in this program and the label is the authority.
**Rating.** DEMONSTRATED by every adult; two adults to CAN TEACH IT on the rotation rule.
**Hours.** 1, plus the list.
**Who must be able.** Every adult to DEMONSTRATED. Children over eight must know the box is not theirs and never open it.

#### `MED-2` — Medication and device continuity
**Objective.** A written continuity plan built around power and refrigeration, with the three conversations had and their answers recorded.
**Chapters.** `06 §6.2` · `04 §4.2` · `04 §4.3` · `08` · `10`.
**Drill.** Two hours, plus the calls: provider, pharmacy, and the supplier or utility.
**Pass.** A written device and medicine list with hour 4, hour 24 and hour 72 answers exists; the provider's answers are written down, including how long the medicine tolerates heat; the pharmacy and supplier calls are made and the supplier's emergency number is on the ICE card; the one-page refrigeration plan exists with a named checker and the power-off time rule; the no-stopping, no-halving rule is recited unprompted.
**Rating.** CAN TEACH IT — a household that cannot answer "what happens at hour 24" has not passed.
**Hours.** 2, plus the calls.
**Who must be able.** Every adult to CAN TEACH IT on the rule and the plan's location; the designated carer to CAN TEACH IT on the whole page.

#### `MED-3` — Rehydration by sachet
**Objective.** State the hard rule, mix a sachet exactly as the packet says, and name the signs that mean hospital instead.
**Chapters.** `06 §6.3` · `02` · `04 §4.6` · `10`.
**Drill.** One hour: one sachet, one packet, one refusal.
**Pass.** The rule is recited verbatim; the sachet is mixed exactly to the packet's stated volume with named clean water, not estimated; the prevention-versus-treatment distinction is stated correctly; the five go-now signs are named and the "sachets plus a route to care" sentence is used; the household states, unprompted, that running out means going, not improvising — and that this program contains **no home ratio, by design**.
**Rating.** CAN TEACH IT.
**Hours.** 1.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must fetch an adult and never mix or give a drink to a person who is confused or very sleepy.

#### `MED-4` — Wound care and infection signs
**Objective.** Clean a wound correctly with soap and clean water, state the infection signs unprompted, and state the escalation rule without being prompted.
**Chapters.** `05 §5.8` · `05 §5.1` · `02` · `04 §4.6.7` · `10`.
**Drill.** One hour, with a real minor wound or a marked stand-in.
**Pass.** The wound is washed with soap and clean water with the water source named; the infection signs are recited unprompted, local and systemic, including new confusion in an elder; the escalation sentence is stated verbatim and "immediate" is defined as today; the household names the four things not printed here and who to ask instead, rather than inventing them; a daily wound check with a written log is scheduled and owned by a named person.
**Rating.** CAN TEACH IT.
**Hours.** 1.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must fetch an adult, must not touch a bleeding wound, and must be able to say where the kit is.

#### `MED-5` — The "do not do this" list
**Objective.** Answer all ten statements correctly and give the one-line reason for each.
**Chapters.** `06 §6.5` · `02` · `03` · `05 §5.8` · `10`.
**Drill.** Read §6.5.2 once, close the book, take the check. **Nine out of ten is a fail and a re-teach.**
**Pass.** 10 out of 10, closed book, by every adult, each with a one-line reason — and the reason must be the real one (a poisoning risk, a narrow margin, a permanent side effect), not a restatement of the statement.
**Rating.** 10/10, no partial pass. There is no CAN TEACH IT tier on this one.
**Hours.** 1.
**Who must be able.** Every adult to 10/10. Children over eight must say three sentences unprompted: *never drink bleach; honey is not for babies; never stop or change someone's medicine.*

#### `MED-6` — First aid that matters for this household
**Objective.** Recognise and act on the four things most likely to kill a member of this household — heavy bleeding, choking, anaphylaxis and stroke — and reduce the household's fall risk by walking the flat in the dark.
**Chapters.** `05 §5.2` · `05 §5.3` · `05 §5.4` · `05 §5.5` · `05 §5.6` · `05 §5.10` · `10`.
**Drill.** Two and a half hours: the four sentences, the four searches, and the dark walk.
**Pass.** All four recognition sets are recited unprompted with the key words present, by every adult, and a hesitation on the anaphylaxis or stroke set is a re-teach, not a pass; all four items are found in the dark in under two minutes and the auto-injector's label is read aloud by an adult who has held the trainer; the choking role-play distinguishes the two states correctly and the household states that the technique and the infant method come from a course; the falls walkthrough is completed in the dark with the person at risk and the fixes written down with a named owner; the ten-second brief is delivered by every adult without reading it.
**Rating.** CAN TEACH IT on the four recognition sets.
**Hours.** 2.5.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must say the address and the emergency number out loud, unlock the door for help, fetch the kit, and stay with a hurt person and shout for help.

#### `WTH-1` — Warmth without utilities
**Objective.** Establish one warm room, prove it is the right room, and recite the never-indoors list unprompted.
**Chapters.** `04 §4.1` · `04 §4.2.2` · `04 §4.2.3` · `03` · `10`.
**Drill.** Two hours, run **before** the heating fails.
**Pass.** The chosen room meets the criteria and the choice is explained, including the room rejected and why; the room is furnished for 72 hours and verified by walking it; drafts are physically stopped, demonstrated not described; the never-indoors list is recited unprompted and the household states that nothing that burns runs indoors; the CO alarm is present, tested and audible from the sleeping area.
**Rating.** CAN TEACH IT.
**Hours.** 2.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must state that the stove and the generator stay outside, that they never touch either, and must know the warm room by name.

#### `WTH-2` — Heat illness and the heat-wave plan
**Objective.** Recite the 103 °F rule and the "no fluids" rule, state the fan rule correctly, and produce a written heat-wave plan.
**Chapters.** `04 §4.3` · `05` · `06` · `10`.
**Drill.** Two hours, indoors, in ordinary weather. Never in a heat wave.
**Pass.** The 103 °F rule, the "no fluids" rule and the skin-sign correction are recited correctly and unprompted; the fan rule is stated both ways with the substitutes named; a written one-page heat-wave plan exists with a named cooling centre and a travel method; the medication rule is stated and the at-risk members are named, not described generically; and the household states that an elder's "I'm fine" is not an assessment — you look.
**Rating.** CAN TEACH IT; a hesitation on the 103 °F or the "no fluids" rule is a re-teach, not a pass.
**Hours.** 2.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must fetch an adult if someone is confused or has stopped sweating, and must never give a drink to someone who is confused.

#### `FIR-1` — Fire and CO
**Objective.** Locate and identify the extinguisher, demonstrate PASS, and recite every "never" — with the honest statement of what this program does not print about fire.
**Chapters.** `04 §4.2.2` · `04 §4.2.5` · `04 §4.1.3` · `05 §5.7` · `10`.
**Drill.** Ninety minutes. Find the extinguisher and read its label aloud; walk the two exits with every member; recite PASS and the never-list; then state which fire questions this program will not answer and who to ask — the local fire service's non-emergency line, on a named day.
**Pass.** The extinguisher is located, its label read aloud, and its gauge checked and dated on the log; **PASS** is recited and the sweep demonstrated in the air, never on a live fire; the two ways out of the flat are walked with every member and the stair route named; the never-list is recited unprompted — no candles, no indoor combustion, no water on a grease fire, no re-entry into a burning building for any reason, no relighting a pilot as a drill; the household states, unprompted, that no extinguisher clearance, burn treatment or backfeed procedure is printed here and names who to ask instead; and the call to the fire service non-emergency line is made or dated into the calendar.
**Rating.** CAN TEACH IT.
**Hours.** 1.5.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must know the two ways out, the meeting place outside, and that they never go back inside.

#### `FUE-1` — Fuel safety
**Objective.** State and apply the household's fuel rules — where fuel may never be stored, what may never run indoors, and how much is too much — and pass the written check 10/10.
**Chapters.** `04 §4.1.3` · `04 §4.2.2` · `03 §3.8` · `02 §2.5` · `10` · `11 §11.7`. **The home chapter for this module is doc 11 — §11.7 covers fuel: what may never be stored in the dwelling, what may never run indoors, and the honest position on quantities.** It prints no gallon figure, no clearance measurement and no kerosene grade — those wait for a verified source, and §11.7.1 says why.
**Drill.** Two hours. Walk the flat and the storage areas and write down, room by room, what is stored where; then recite the rules and take the check closed-book.
**Pass.** 10 out of 10 on the written check, closed book, by every adult, with a one-line reason per answer; plus the walk: no gasoline in the dwelling, nothing in a stairwell or common area, nothing within 20 feet of a generator running, nothing in a milk jug or an unlabelled container, no propane cylinder indoors, no unvented kerosene heater where the lease or the law forbids it, and no fuel stored near a water heater or a pilot light.
**Rating.** 10/10 written check, no partial pass — the same standard as `MED-5`.
**Hours.** 2.
**Who must be able.** Every adult to 10/10. Children over eight must state that fuel and the generator live outside and that they never touch either.

#### `CLO-1` — Dress the slowest member for 0 °C in five minutes
**Objective.** Dress the household's slowest member for freezing conditions, in five minutes, in the dark, from what is in the house — then do it for every member.
**Chapters.** `04 §4.5` · `11` · `10`.
**Drill.** One hour. Five minutes, lights out, timer running.
**Pass.** The slowest member is fully dressed for 0 °C within five minutes, in the dark, from what is in the house, timed — missing the time is a fail, not a partial; every member is dressed to the same standard in the same session and the clothing store is labelled per person with a reserved dry change; the three layering rules and the elder-specific points are stated unprompted; footwear is by every bed, verified by walking the bedrooms.
**Rating.** CAN TEACH IT — dress a second person while explaining the layering.
**Hours.** 1.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must dress themselves to the same standard in the dark and know where their own labelled clothing is.

### TIER GATE — `DRILL-1`

#### `DRILL-1` — The 72-hour no-utilities drill
**Objective.** Live 72 hours on stored water, stored food, no mains power and the household's own sanitation, and come out of it with a written list of what broke — run only when Tier 0 and Tier 2 are closed.
**Chapters.** `00 §0.4` · `09 §9.4` (the full safety protocol, printed above) · `03 §3.7` · `04 §4.2.3` · `06 §6.2` · `02 §2.9` · `10`.
**Drill.** Four hours of work inside 72 hours of elapsed time: the pre-drill screen and brief, the shut-down, the daily checks, the abort decision points, and the debrief. Every line of §9.4 is read aloud before the drill starts and the outside check-in person is named in writing.
**Pass.** The pre-drill medical screen is completed and signed, and the drill **does not run** if any exclusion applies — a correctly abandoned drill passes this module and a drill run over an exclusion fails it; CO alarms were tested on the day; the unit breaker was used and the building main and sprinkler riser were not touched, with the landlord notified; the water heater was shut off before any draining and no shared system was drained; nobody was in the lift, no candles were lit, and the fridge plan was executed with the thawing food cooked first; the abort rule was stated by every adult before the start; 72 hours were completed with the daily checks logged; and the debrief page lists every failure by name.
**Rating.** DEMONSTRATED by the household, with the abort decision attributed to a named person. There is no CAN TEACH IT requirement: the drill is a household event, not a skill one adult holds.
**Hours.** 4 contact hours, plus 72 hours elapsed.
**Who must be able.** Every adult to DEMONSTRATED on the protocol and the abort rule; the named decider must be able to state, unprompted, the two conditions under which they will call it off. Children over eight know the drill is happening, know the LED light is theirs, and know they never touch the stove.

### TIER 3 — SHELTER, SECURITY AND COMMUNITY

#### `SHE-1` — Shelter and building reality
**Objective.** Board and seal one opening, demonstrate sealing a room against an airborne hazard, state the shelter and pet facts, and know what the building does to your heat.
**Chapters.** `04 §4.4` · `07` · `08` · `10`.
**Drill.** Three hours: close a hole, seal a room, make three calls.
**Pass.** The opening is closed in two layers with the perimeter sealed and one window in that room left operable; the seal-a-room step is completed and timed, ventilation shut down and the three abandon triggers stated; the household states, unprompted, that no board-up or seal-a-room dimension is printed here and names who to ask instead; the shelter facts are correct and both pet answers are written down naming real people or places — shelters take **service animals only**; the three calls or lookups are done with results on the card.
**Rating.** CAN TEACH IT on the seal-a-room step.
**Hours.** 3, plus the calls.
**Who must be able.** Every adult to CAN TEACH IT on the seal-a-room step. Children over eight must know which room the household seals and be able to go there and stay there when told.

#### `SHE-2` — Above the sixth floor
**Objective.** State what fails first in a tall building, produce a written water-carrying and waste plan for your floor, and record the landlord conversation.
**Chapters.** `04 §4.4.5` · `02` · `07` · `08` · `10`.
**Drill.** Two hours, on foot: the building audit.
**Pass.** The building audit is written down — floor, water source, booster pump or tank, what the generator actually powers, stair count, bin location; the household states, unprompted, that above roughly six floors the taps die with the power and says how many days of water it has upstairs right now; a written carrying plan exists naming who carries and what happens when they cannot; a written waste plan exists naming the authority asked and the trigger to leave; the landlord conversation is recorded — number, generator scope, pump responsibility, waste question in writing.
**Rating.** CAN TEACH IT.
**Hours.** 2.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight must know the stair route down and the meeting place outside.

#### `SEC-1` — The security assessment
**Objective.** Complete a two-time-of-day walkthrough of your own home, score it on the 12-line instrument, and make contact with the local crime-prevention unit and, if renting, the landlord.
**Chapters.** `07 §7.1`–`§7.2` · `01 §1.2.6` · `10` · `04`.
**Drill.** Daylight walk with the score sheet; dark walk with a torch and the same sheet; then the calls.
**Pass.** A completed score sheet with a total, dated; the two walks on different days; a **named** person or unit at the police department spoken to, with the date and what they said on the sheet; if renting, a dated written list of building faults submitted. A sheet filled in from the armchair in one sitting does not pass — the dark walk is the whole drill.
**Rating.** CAN TEACH IT for one adult; DEMONSTRATED for every other adult.
**Hours.** 3.
**Who must be able.** One adult to CAN TEACH IT. Every other adult to DEMONSTRATED, including the one who thinks this is obvious. Children over eight point at the answer-door and say who may open it.

#### `SEC-2` — The door protocol
**Objective.** Write the household's four-part door protocol, teach the child's script and the elder's script, and role-play both until each is delivered without prompting.
**Chapters.** `07 §7.3` · `10` · `04` · `12`.
**Drill.** The ten-minute role-play, four ways: adult answering an adult; child answering an adult; elder answering an adult; and the caller who will not leave.
**Pass.** The child delivers all three lines unprompted through a closed door, to an adult they do not know is acting, and then walks away from the door — and can state the neighbour's door and the "never in trouble" rule in their own words; the elder delivers lines one and two unprompted and defers the decision to a phone call; every adult states the four parts — who answers, from where, with whom present, what they say — without reading them. Reading aloud from the card does not pass for an adult.
**Rating.** CAN TEACH IT by every adult.
**Hours.** 2, plus ten minutes at every re-score.
**Who must be able.** Every adult to CAN TEACH IT. Every child over eight to DEMONSTRATED on the three lines. Every elder to DEMONSTRATED on lines one and two.

#### `SEC-3` — Mutual aid, and CERT
**Objective.** Name three neighbours, record what each can do and what you can do for them, hold one real conversation, and register for a FEMA independent-study course or a local CERT class.
**Chapters.** `07 §7.4` · `01 §1.2.6` · `10` · `05 §5.10`.
**Drill.** The conversation. Three of them, or one if you live in a detached house with one neighbour — in which case the third name comes from the wider block, a faith group, a building committee, or the CERT class itself.
**Pass.** Three named neighbours on the worksheet, each with a capability, a reciprocal contribution and a phones-down contact method, and at least one conversation that actually happened, evidenced by a name, a date and something the neighbour told you that you did not know before; plus a dated registration for IS-317.A or a local CERT class, or a written note that no local class exists and when you will re-check.
**Rating.** CAN TEACH IT for one adult; DEMONSTRATED for every other adult.
**Hours.** 4 (two for the conversations, two for the course).
**Who must be able.** One adult to CAN TEACH IT — meaning one other household has been brought into the conversation. Every adult to DEMONSTRATED. Children over eight know the neighbour's door.

#### `SEC-4` — Legal reality
**Objective.** Establish the household's legal position on the questions that affect it — weapons law, storage and transport law, and the sanitation and waste rules doc 04 depends on — by asking the three named authorities and writing the answers down.
**Chapters.** `07 §7.5` · `01 §1.5` · `04 §4.6` · `SOURCES.md`.
**Drill.** Three questions, three authorities, written answers with dates. Then a household meeting at which the answers are read aloud to every adult.
**Pass.** A dated written record of (a) the state attorney general's published guidance, or a note that it does not cover the question, (b) the local police non-emergency answer on possession, storage and transport where you live, and (c) the local rule on emergency waste disposal; plus a signed line in the meeting minutes confirming every adult has heard the answers. "I looked it up once" does not pass — the record is the demonstration, and it is re-dated annually.
**Rating.** DEMONSTRATED only. This is an administrative module and there is no CAN TEACH IT requirement.
**Hours.** 2.
**Who must be able.** Every adult to DEMONSTRATED. No child is involved in this module, and no child is told anything about weapons by this program.

### TIER 4 — MOBILITY AND MOVEMENT

#### `MOV-1` — Per-person bags
**Objective.** Build one bag per person from the federal baseline, using the household's own four-column worksheet, and prove that every bag can be lifted by its named carrier.
**Chapters.** `08 §8.2` · `03` · `02` · `06 §6.1`–`§6.2` · `10`.
**Drill.** Pack, weigh, and lift. Every bag on the floor, every named carrier picking theirs up and walking it to the door and back. Then a second lift by whoever would carry it if that person were injured.
**Pass.** One completed worksheet per person with all four columns filled and a check date; every bag lifted and carried to the door by its named carrier; the elder's bag containing the medication list in original labelled containers and a written clinician number; the child's bag containing the rally point card and no item that requires a decision. A bag that is packed but not liftable by its carrier fails, and so does a worksheet with "whoever is nearest" in the carrier column.
**Rating.** CAN TEACH IT by every adult.
**Hours.** 3.
**Who must be able.** Every adult to CAN TEACH IT — able to pack any bag in the house from the worksheet. Children over eight to DEMONSTRATED on their own bag. An elder is not required to carry their own bag; the plan names who does.

#### `MOV-2` — The mobility plan
**Objective.** Produce a one-page mobility plan for the household's slowest member, and for each subsequent member, naming the route, two lifters, a measured time, a script and a stop rule — and make the equipment calls.
**Chapters.** `08 §8.1`–`§8.3` · `07 §7.4` · `04` · `06 §6.2` · `10`.
**Drill.** Walk the route, slowly, narrating it aloud, with the person being carried if they are willing. No timing yet.
**Pass.** A completed one-page plan with a named route, two named lifters with separate jobs, a measured time with a date, the doubled time, a written script and a written stop rule; plus the equipment calls made and written up, or a dated note that the household has no such equipment. "We'd manage" does not pass — the page must name people.
**Rating.** CAN TEACH IT by two adults, because one is a single point of failure.
**Hours.** 3, plus the calls.
**Who must be able.** Two adults to CAN TEACH IT. Every other adult to DEMONSTRATED on the route and the script. Children over eight can state the route in their own words.

#### `MOV-3` — The timed assisted evacuation drill
**Objective.** Run the assisted evacuation drill, timed, to rally point one, at the pace of the slowest member, and produce a written time, a written doubled time and a written judgement about whether that is fast enough.
**Chapters.** `08 §8.3`–`§8.4` · `08 §8.5` · `01` · `10`.
**Drill.** The full sequence in §8.4.2, twice in daylight, then once after dark. Abandoned and re-run if any rule in §8.4.1 is broken.
**Pass.** Two clean daytime runs and one night run, each with a recorded time; the **last** person — not the first — timed to the rally point; a written doubled time; a written answer to the "is this fast enough" question; a debrief note with exactly one change made between runs. A run in which anyone was hurried does not count, and a household reporting a fast time with a distressed slow mover has failed the module regardless of the clock.
**Rating.** CAN TEACH IT.
**Hours.** 4 across the three runs and the debriefs.
**Who must be able.** Every adult to CAN TEACH IT — every adult must be able to run the drill with a different adult carrying. Children over eight to DEMONSTRATED: they walk the route, carry their bag, arrive at the rally point.

#### `MOV-4` — Rendezvous and comms
**Objective.** Name two rally points, name and brief an out-of-area contact, write the phones-down plan on paper for every member, and name a destination in each of the three tiers.
**Chapters.** `08 §8.5` · `01 §1.5` · `10` · `04`.
**Drill.** A separation drill: the household leaves by two different routes, meets at rally point one, then walks to rally point two. Then the out-of-area contact is called, from a phone with the number read off paper.
**Pass.** Two named rally points on every card in every bag; an out-of-area contact who has been called and who can state the household's names and rally points back to you; a paper comms card carried by every member including the child; a named destination in all three tiers, with the tier-two destination confirmed by the person who lives there. A tier-two destination that has not been asked does not pass.
**Rating.** CAN TEACH IT.
**Hours.** 3.
**Who must be able.** Every adult to CAN TEACH IT. Children over eight to DEMONSTRATED: they can name both rally points, show their card, and state the rule that nobody goes back inside.

### TIER 5 — INTEGRATION

#### `INT-1` — The full 72-hour simulation, run as an assessment
**Objective.** Run the whole program for 72 hours as one event — water, food, warmth, sanitation, medicine, security and the decision card — and be assessed on it rather than coached through it.
**Chapters.** `00 §0.4` · `00 §0.5` · `09 §9.4` · `08 §8.4` · `02 §2.9` · `06 §6.2` · `10` · `12`.
**Drill.** Six contact hours inside 72 elapsed: the brief, the shut-down, two check-ins a day, and the close. No teaching during it. The assessor observes and writes.
**Pass.** Every line of §9.4 satisfied on the day; the household lives on stored water and stored food for 72 hours without mains power and without using Grade A water for the toilet; the warm room is used at least one night; sanitation is run with the named disposal route honoured; the medication plan is executed at hour 24 and the answer recorded; the door protocol is used on any real caller; the decision card is consulted at least once and the consultation is logged; every module's pass criteria that can be observed in the field are observed; and the household does not break its own rules even once — a single indoor flame or a single touch of the building main fails the module.
**Rating.** DEMONSTRATED by the household. Passing `INT-1` is the Stage 3 condition.
**Hours.** 6 contact hours, plus 72 hours elapsed.
**Who must be able.** Every adult to DEMONSTRATED on the protocol, the abort rule and their own role. Children over eight to DEMONSTRATED on their two jobs.

#### `INT-2` — The debrief
**Objective.** Log every failure from `INT-1` and from the whole program, and either fix it or consciously accept it in writing — because an unlogged failure is a failure that repeats.
**Chapters.** `00 §0.5` · `08 §8.4.3` · `09 §9.4` · `10` · `13`.
**Drill.** Two hours, one sitting, every adult present, with the drill log and the scorecard on the table.
**Pass.** Every failure from `INT-1` and `DRILL-1` is listed by name with a date; each one carries either a fix with an owner and a date, or a written acceptance that names the risk and who accepted it; the scorecard is re-scored and dated against the week-0 score; exactly one change is committed to for the next 30 days — not five; and every adult has read the page and signed it.
**Rating.** DEMONSTRATED. A closed debrief is the second Stage 3 condition.
**Hours.** 2.
**Who must be able.** Every adult to DEMONSTRATED, with the acceptance signed by the adult who will carry the risk.

#### `MOR-1` — Morale and mental health over 90 days
**Objective.** A written plan for the thing that actually breaks in a long outage — the people — covering keeping children occupied, the elder's purpose and dignity, and adult burnout.
**Chapters.** `00 §0.7` · `00 §0.2` · `04 §4.6.2` · `10`. **This module has no dedicated chapter in docs 00–08.** It is written from the day-1-to-90 timeline and the household facts already recorded; a short morale chapter is needed before this module is at full strength, and until then it is scoped to what those sections support.
**Drill.** Two hours, as a household, at the kitchen table. Write the plan; do not discuss it.
**Pass.** A one-page plan exists with a named activity store for the children that needs no power (and where it lives); the elder has a **named job in the household's plan**, written down and agreed with them, not assigned to them; a written rule for adult rest that names who takes over and when; a named person outside the household each adult can talk to, with a number; the signs of burnout and of withdrawal are written in the household's own words; and the plan states plainly that this program is not mental-health treatment and that crisis lines and clinicians are the answer for a person in crisis.
**Rating.** DEMONSTRATED by every adult.
**Hours.** 2.
**Who must be able.** Every adult to DEMONSTRATED. Children over eight are told what their job is and that the household's plan depends on them doing it — which is the morale intervention, not a chore.

---

## 9.6 The twelve-week calendar

The calendar of record is doc 00 §0.4, and it is reproduced here so the matrix and the schedule cannot drift apart. A week is **about five hours on the core path** (●) and up to seven on the full path (● plus ○). If a week goes badly, repeat it — the calendar is a sequence, not a deadline. **The tier is the gate, the week is the schedule:** a household that takes twenty weeks still earns the stage if the competencies are demonstrated.

| Week | Tier | Modules | Path | Hours |
|---|---|---|---|---|
| **0** | Baseline | `BAS-1` · `BAS-2` · `BAS-3` · `BAS-4` | ● | 8 |
| **1** | Life support | `WTR-1` · `CO-1` | ● | 3 |
| **2** | Life support | `WTR-2` · `WTR-3` | ● | 1.75 |
| **3** | Life support | `FOD-1` · `FOD-2` | ● | 4.5 |
| **4** | Life support | `FOD-3` · `SAN-1` · `SAN-2` | ● | 3 |
| **5** | Health and warmth | `MED-1` · `MED-2` · `WTR-4` | ● | 4.5 |
| **6** | Health and warmth | `MED-3` · `MED-4` · `MED-5` | ● | 3 |
| **7** | Health and warmth | `MED-6` · `WTH-1` · `FUE-1` | ● | 6.5 |
| **7 end** | **Gate** | **`DRILL-1`** — only with Tier 0 and Tier 2 closed | ● | 4 |
| **8** | Shelter and security | `WTH-2` · `FIR-1` · `CLO-1` | ● | 4.5 |
| **9** | Shelter and security | `SHE-1` · `SHE-2` · `SEC-1` · `SEC-2` | ● | 10 |
| **10** | Shelter and security | `SEC-3` · `SEC-4` (Stage 2 lands here) | ● | 6 |
| **11** | Mobility | `MOV-1` · `MOV-2` · `MOV-3` · `MOV-4` | ○ | 13 |
| **12** | Integration | `INT-1` · `INT-2` · `MOR-1` | ○ | 10 |

**Why the drill sits at week 7.** An earlier version ran it in week 4, before the medication list existed and before a single CO alarm was on a wall. For an elder on cardiac, seizure or insulin medication, or a household with oxygen in it, that is the most foreseeable harm in the program. It is now behind Tier 0 and Tier 2 as a hard gate, and it is abandoned rather than pushed through.

**Two weeks are not the calendar.** Nothing here is a race against a clock you control. If your household needs fourteen weeks, take fourteen.

---

## 9.7 The core path, honestly costed

The core path is the ● column: thirty-nine modules minus the seven that only matter if you leave, which is thirty-two modules and about **59 hours** from week 0 to the end of week 10. It reaches **Stage 2 — OPERATIONAL**, and it is the path a household with a job, a carer and a four-year-old should actually plan for.

The planning unit is the week, and it is honest only week by week. Here is the arithmetic, with nothing rounded in the household's favour:

| Week | Hours | Load |
|---|---|---|
| 0 — roster, inventory, documents, decision card | 8 | **Heaviest week in the program.** It cannot be compressed. Do it over two evenings. |
| 1 — water buffer, CO alarms | 3 | Light |
| 2 — boil, disinfect | 1.75 | Lightest week of the core path |
| 3 — pantry, no-power cooking | 4.5 | Moderate, and the shopping is on top |
| 4 — food safety, sanitation | 3 | Light |
| 5 — kit, continuity, water in the building | 4.5 | Moderate |
| 6 — rehydration, wound care, the "do not do this" list | 3 | Light |
| 7 — first aid, warm room, fuel check | 6.5 | Heavy — and the drill adds 4 hours at the end of it |
| 8 — heat illness, fire, clothing | 4.5 | Moderate |
| 9 — shelter, high-rise, security, door protocol | 10 | Heavy. The heaviest week after week 0. |
| 10 — mutual aid, legal | 6 | Heavy |

So the honest statement is this: **the core path averages about 5.3 hours a week** across weeks 0–10, and the full path about **6.8 hours a week** across twelve. Five of the eleven core weeks come in at three hours or under; four need four and a half to six and a half; two need eight to ten. Nobody should plan the core path as an evening a week — the average is what a household has to find room for, and the heavy weeks are not negotiable.

If a household has a genuinely impossible week, the way through is to stretch the calendar rather than skip modules: weeks 0, 7 and 9 each become two weeks, and the program finishes in about fifteen weeks. **Nothing on the ● path may be dropped to save time** — every one of those thirty-two modules is a gate on Stage 2, and a household that skips `MED-2` because it was busy has skipped the module that keeps an elder's insulin cold.

What the core path deliberately leaves out is the mobility tier and the integration tier — thirteen and ten hours. They are the ○ column, they are insurance on a decision you expect not to make, and they are the difference between Stage 2 and Stage 3.

---

## 9.8 Total hours, stated honestly

| Tier | Modules | Hours |
|---|---|---|
| Tier 0 — Baseline | 4 | 8 |
| Tier 1 — Life support | 10 | 13.75 |
| Tier 2 — Health, warmth and clothing | 11 | 17 |
| Tier gate — `DRILL-1` | 1 | 4 |
| Tier 3 — Shelter, security, community | 6 | 16 |
| Tier 4 — Mobility | 4 | 13 |
| Tier 5 — Integration | 3 | 10 |
| **Total** | **39** | **≈ 82 hours** |

Plus **144 hours of elapsed drill time** — two 72-hour events that are lived rather than worked. The contact hours above are the hours somebody is doing something and somebody else is watching; the elapsed hours are the hours the household is simply living the plan, which is where the learning actually happens and is not something to bill as study time.

The other honest number: **a household that does Tier 0 and Tier 1 only** — fourteen modules, 21.75 hours, about four weeks — reaches **Stage 1**, and that is already more than most urban households in the country have done. Stage 1 is a real stopping point, not a failure to finish.

---

## 9.9 The modules not yet built, and where they live

Ten of the thirty-nine had no seven-field box in docs 00–08 and are written here for the first time: `BAS-1`, `BAS-2`, `BAS-3`, `CO-1`, `FIR-1`, `FUE-1`, `DRILL-1`, `INT-1`, `INT-2`, `MOR-1`. Three of them have partial material in the chapters already — `CO-1` is doc 04 §4.2.3, `FIR-1` is doc 04 §4.2.5 and §5.7, `DRILL-1` is doc 00 §0.4 and the protocol above. One of them has since found its home: **`FUE-1` now lives in doc 11** (sourcing, budget and fuel), which was written after this matrix. **`MOR-1`** (morale and mental health across 90 days) still has no chapter of its own — it draws on doc 00's day 1→90 timeline, doc 04's warmth and clothing material, and this document's own integration week. Both are marked in their own boxes, and neither invents a figure to cover the gap.

---

## 9.10 What this matrix is not

It is not a qualification, and it certifies nothing to anyone outside your front door. The assessor is a household member with no independent qualification. The Stage names are stage names. There is no seal, no crest, no badge and no issuing body, and nothing in this program or its listing may be sold as "getting certified".

It is also not a substitute for a course. Choking technique, CPR, the infant method, extinguisher use on a live fire, and anything to do with a person's airway are taught with a manikin and somebody watching your hands. This program tells you what to recognise and when to call; it does not teach you the physical skills, and the modules that touch them say so in their own text.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version 1.0, errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a source does not cover an item — extinguisher clearances, burn treatment specifics, backfeed procedure, fuel quantities, board-up dimensions, oxygen-cylinder transport, evacuation-chair specification, and the emergency-toilet disposal method — this document says so rather than supplying a number, and sends you to the local fire service's non-emergency line, the equipment supplier, the prescriber, the building manager, the local health department, 2-1-1, or Ready.gov's own pages.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
