# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 08 — SLOW MOVERS AND BUG-OUT

**Version 1.0 · Errata date 2026-11-02 · Written for households in the United States**

The title of this program is not a slogan. It is the plan.

Almost every evacuation guide assumes a fit adult who can carry forty pounds and walk out. That adult does not live
here. This household has an elder who cannot do stairs quickly, or a child who cannot walk a mile, or both, and the
household's real speed is the speed of its slowest member on its worst day. A plan built for the fastest person in the
house is a plan that fails on the first stairwell.

So this chapter is not about fleeing. **It is about the assisted move** — a short, pre-planned, rehearsed relocation
that the household does at walking pace, on purpose, with the slowest member setting the clock. It exists so that
leaving is a thing you have already done once, badly, in daylight, with everyone safe — rather than a thing you do for
the first time at 2 a.m. in a stairwell with smoke in it.

> **Read this before anything else in the chapter.** **The default in this program is to stay.** Doc 01's decision tree
> puts STAY AND HARDEN first, and it is the right answer for most urban households in most outages. Moving is what you
> do when a specific trigger fires — the building is unsafe, sanitation has become untenable, the temperature is
> beyond what the household can survive, or an official evacuation order has been given. **Nothing in this chapter is
> an argument for leaving early, and nothing in it should be read as one.** The bags, the plan, the drill and the rally
> points are all insurance on a decision you expect *not* to make.

Four modules close here — **`MOV-1`** the per-person bags, **`MOV-2`** the mobility plan, **`MOV-3`** the timed drill,
**`MOV-4`** rally points and comms.

---

## 8.1 The slowest member sets the clock

### 8.1.1 The arithmetic that changes everything

A household of five where four people can leave a second-floor flat in ninety seconds and one person needs eight
minutes has a **nine-minute** household, not a ninety-second one. Every number in a movement plan — how long to pack,
how long to reach the car, how long before the fire service arrives, how long the smoke takes to fill a stairwell —
has to be measured against nine minutes, not ninety seconds.

That is not pessimism. It is the only arithmetic that produces a plan which survives contact with a real stairwell.
And it has a second consequence that most guides miss: **the fastest people in the household are not spare capacity,
they are the lift.** Their job is not to carry the most; it is to make the slowest member's eight minutes as short and
as safe as it can be, and to do it in the order the plan says, not the order panic suggests.

### 8.1.2 Three honest constraints

**Stairs are the bottleneck.** Not distance, not traffic, not the weather. Stairs. If the household is above the ground
floor, the count of flights between the flat and the street is the single most important number in this chapter, and
§8.3.3 is about counting it and timing it.

**Equipment does not move itself.** A powered chair, a concentrator, a walker, a commode, an oxygen supply — each adds
a trip or a person or a minute. §8.3.4 is about the equipment question, and about what this program will not tell you.

**A bad night is not a normal night.** The drill in §8.4 is run in daylight, in good weather, with everyone healthy.
The real event will not be. A plan that only works on a good day is a plan with a known failure date, and knowing the
date is better than not knowing it.

### 8.1.3 What the sources actually support

Ready.gov's *Evacuation* page is the honest backbone of this chapter, and it says less than most guides pretend. It
tells households to "build a go-bag with all the essentials you might need, so you don't need to scramble in an
evacuation situation"; to "assemble supplies that are ready for evacuation"; to prepare a "go-bag you can carry when
you evacuate on foot or public transportation"; to keep a "portable emergency kit in the car"; to be "familiar with
alternate routes and other means of transportation out of your area"; and to remember that "your evacuation route may
be on foot depending on the type of disaster." It also says, plainly, that if you need a place to stay that accepts
pets, you should identify it in advance, because "most public shelters allow only service animals"
(https://www.ready.gov/evacuation).

What it does not do — and this matters for every page that follows — is break any of that down by age or disability.
There is no federal "elder go-bag," no federal "child go-bag," and no federal assisted-evacuation procedure. Where a
guide gives you one, it is that guide's own invention. This chapter tells you which parts are sourced and which parts
are the team's worksheets, on every page, because a household making a plan for a person who cannot walk should know
exactly whose judgement it is trusting.

---

## 8.2 Module `MOV-1` — per-person bags, as planning worksheets

### 8.2.1 The honest position on per-person bags

**No federal source differentiates a go-bag by person.** Ready.gov publishes one general kit list
(https://www.ready.gov/kit) and one general instruction to build a go-bag. It does not publish an elder version, a
child version, or a version for a person with a disability. Any product that presents such a list as official is
making it up.

So this program does the honest thing: it reproduces the federal list as the **baseline**, and then gives you
**planning worksheets** — clearly labelled as the team's own adaptation — for allocating that baseline across the
people in your household. The worksheets are a way of thinking, not a standard. If your household's version differs
from ours, your household is probably right.

### 8.2.2 The federal baseline, reproduced

This is the Ready.gov kit list, and it is the adult baseline for every bag in the house. Water — one gallon per person
per day for several days, for drinking and sanitation. Food — at least a several-day supply of non-perishable food.
A battery-powered or hand-crank radio, and a NOAA Weather Radio with tone alert. A flashlight. A first aid kit. Extra
batteries. A whistle. A dust mask. Moist towelettes, garbage bags and plastic ties, for personal sanitation. A wrench
or pliers to turn off utilities. A manual can opener. Local maps. A cell phone with chargers and a backup battery.
Prescription medications. Non-prescription medications — pain relievers, anti-diarrhoeal, antacids, laxatives. Pet food
and extra water.

Note what is *not* on it: no knife specification, no weapon, no fire-starting kit, no cordage, no "tactical" anything.
The federal list is a list for surviving a bad week indoors or in a shelter, not a list for living off the land, and
this program does not add to it. If a household wants to add items, that is the household's call — but it should know
it is adding, not completing.

### 8.2.3 The worksheet method — four columns, filled in by the household

Each person gets one worksheet (doc 10 carries the blank). Four columns, and the fourth is the one that turns a list
into a plan:

1. **Item.** Drawn from the federal baseline, plus whatever the household decides it needs for that specific person.
2. **Who carries it.** A named person. Not "whoever." If the answer is "the person it belongs to," write that, because
   for a child or an elder the honest answer is usually somebody else.
3. **Weight, and whether that carrier can actually carry it.** A bag that is packed and cannot be lifted by its named
   carrier is not a bag, it is a box.
4. **Where it lives, and when it was last checked.** A date. A bag checked once in 2024 is a bag of expired
   medication and flat batteries.

**The rule that makes the worksheet work: total weight is a household problem, not a per-person one.** The adult
baseline is a full kit per person and it is heavy. In a household where one person cannot carry anything, the other
adults are carrying for two. That is the arithmetic, and it is better to discover it on a worksheet in November than
on a stairwell in January.

### 8.2.4 The three worksheets — adult, child, elder

**These are the team's planning worksheets, not an official list.** They exist because a household with three kinds of
person in it needs three kinds of thinking, not because any authority publishes three lists.

**The adult worksheet** is the federal baseline, carried by the adult, plus one addition that this program insists on:
**the adult's bag carries the documents and the cash** (doc 10's ICE card, copies, and enough cash for a night —
because cards fail when the network does). And one subtraction worth considering: in a household where an adult is
carrying for an elder, that adult's bag should be the *lightest* version of the baseline, not the fullest, because
their hands are needed for a person.

**The child's worksheet** is small, light, and mostly about identity rather than supplies. A child can carry a few
pounds and no more, and should not be asked to carry their own water for three days. What the child's bag should carry
is: a whistle, a torch, a comfort item, a written card with their name, the household's out-of-area contact, and the
two rally point addresses — and **nothing that requires the child to make a decision.** The rest of the child's share
is carried by an adult, and the worksheet should say which adult, by name.

**The elder's worksheet** is the one that is genuinely different, and the difference is medical. It carries the
person's own medication list and a several-day supply of what they take, in the original labelled containers, with the
prescriber's name on it — because a shelter, a pharmacy, or an emergency department will need to know what this person
takes, and a bag of loose tablets answers no questions. It carries hearing aids and spare batteries, glasses and a
spare pair, dentures and their case, a mobility aid if it folds, and a written one-page medical summary. And it carries
**a phone number for the person's own clinician**, written on paper.

What the elder's worksheet deliberately does **not** do is specify how to transport oxygen, a concentrator, a powered
chair, or any other piece of durable medical equipment. That material was not retrievable from an authoritative source
during the research for this program, and §8.3.4 explains what to do instead — which is a phone call, not a guess.

### 8.2.5 The module, stated as a module

**Objective.** Build one bag per person from the federal baseline, using the household's own four-column worksheet, and
prove that every bag can be lifted by its named carrier.

**Chapters.** `08 §8.2` · `03` (what food actually goes in, and how much) · `02` (water quantities) · `06 §6.1–6.2`
(the medicine that goes in the elder's bag) · `10` (blank worksheets).

**Drill.** Pack, weigh, and lift. Every bag on the floor, every named carrier picking theirs up and walking it to the
door and back. Then a second lift by whoever would carry it if that person were injured.

**Observable pass criteria.** One completed worksheet per person, each with all four columns filled and a check date;
every bag lifted and carried to the door by its named carrier; the elder's bag containing the medication list in
original labelled containers and a written clinician number; the child's bag containing the rally point card and no
item that requires a decision. **A bag that is packed but not liftable by its carrier fails**, and so does a worksheet
with "whoever is nearest" in the carrier column.

**Assessment.** By an adult who did not pack the bag, or a neighbour/CERT witness. Rated **NOT YET / DEMONSTRATED /
CAN TEACH IT**. **Hours.** 3.

**Who must be able.** Every adult to CAN TEACH IT — able to pack any bag in the house from the worksheet, not just
their own. Children over eight to DEMONSTRATED on their own bag: they can say what is in it, carry it, and name the
adult who carries the rest. An elder is not required to carry their own bag; the plan names who does.

---

## 8.3 Module `MOV-2` — the mobility plan

### 8.3.1 What a mobility plan is, and what it is not

A mobility plan is a single page that answers four questions: **how does the slowest person leave the building, who
lifts them, how long does it take, and where does everyone go.** That is the whole document. If it does not fit on one
page and cannot be read aloud in ninety seconds, it will not be used.

It is not a route map. It is not a vehicle plan. It is not a medical plan. Those exist elsewhere or not at all, and
this page is the one that has to work in a corridor with the lights out.

### 8.3.2 What this chapter will not print, and why

**No oxygen-cylinder transport procedure. No evacuation-chair specification. No wheelchair route design.** All three
were looked for during the research for this program and none could be retrieved from an authoritative source. The
relevant federal pages on evacuating people with disabilities exist in site navigation but the content was not
successfully retrieved, and this program's rule is that it does not publish a procedure it cannot cite.

That is a real gap and this chapter says so rather than filling it. What it gives instead is **the questions to ask
the people who own the answer**, in §8.3.4, and the instruction to ask them this week rather than on the night.

### 8.3.3 The plan page — who lifts, and how long it takes

Fill this in for the slowest member, then for the next slowest, until everyone is covered. Doc 10 carries the blank.

**The route.** Which door out of the flat, which stairwell, how many flights, which door to the street, which side of
the building. Written as a sequence of named things, not a diagram: *front door → left stairwell → three flights →
lobby → service door on the north side → the tree outside the laundrette.* A named landmark is better than a direction,
because in smoke or dark a direction is not usable and a landmark is.

**Who lifts.** Name **two** people, and their jobs separately. One person lifts and steers; one person goes ahead and
clears the route and holds doors. That split matters more than strength: a single carrier on a stairwell has no hand
free for a door, and a door that has to be opened costs more time than the lift does. If the household has only one
adult who can lift, write that down as a **known single point of failure** and decide now what happens if that adult
is the one who is hurt — a neighbour's name goes in that space, which is why §7.4 is a prerequisite for this module.

**How long it takes.** Not an estimate. A measured number, from the drill in §8.4, written on the page with the date it
was measured. Then double it, and write the doubled number underneath, because the real event will be at night, in bad
weather, with a frightened child, and the doubled number is the one to plan against.

**What the slowest member is told.** A short script, in the same spirit as the door script: *we are going out by the
left stairs; I will carry you; you do not need to do anything except hold on and keep your head down.* A person being
carried who does not know what is happening will fight the lift, and a person fighting a lift on a stairwell is how
both people fall. The script is part of the plan, not a nicety.

**The stop rule.** The conditions under which the household stops and goes back — a blocked stairwell, smoke on the
route, a member who cannot continue. Written down in advance, because the decision to turn around is much harder to
make in the moment than the decision to start.

### 8.3.4 The equipment question — a phone call, not a guess

If anyone in the household uses oxygen, a concentrator, a powered chair, a hoist, or any other piece of durable medical
equipment, this program cannot tell you how to move it, and will not pretend to. What it can tell you is who to ask,
and that the asking should happen while the phones work.

**Call the equipment supplier.** Ask, in these words: *"If we had to leave the building in an emergency, what is the
procedure for this equipment, what does it weigh, how many people does it take, and is there a portable version we
should have?"* Write the answers on the mobility page, with the date and the name of the person who told you.

**Call the prescriber or the clinic** for the same person, and ask what happens if the equipment is unavailable for
twelve hours. That is a medical question and it belongs to a clinician.

**Call the building manager**, if you rent or live in a multi-unit building, and ask what the building's own emergency
plan says about residents who need assistance leaving. Many buildings have one, few residents have read it, and the
answer is sometimes better than anything the household would have devised.

**And tell the fire service, before you need them.** Many departments keep a voluntary register of residents who would
need help evacuating, and the non-emergency line is where to ask whether yours does. This is the same call as doc 07
§7.2.4, and it is the single highest-value thing a household with a slow mover can do that costs nothing.

### 8.3.5 The module, stated as a module

**Objective.** Produce a one-page mobility plan for the household's slowest member, and for each subsequent member,
naming the route, two lifters, a measured time, a script, and a stop rule — and make the equipment calls.

**Chapters.** `08 §8.1–8.3` · `07 §7.4` (the neighbour who becomes the second lifter) · `04` (fire escape routes) ·
`06 §6.2` (device continuity) · `10` (the blank plan page).

**Drill.** Walk the route, slowly, narrating it aloud, with the person being carried if they are willing. No timing
yet — this is the walk where you discover the door that sticks and the turn that is too tight.

**Observable pass criteria.** A completed one-page plan with a named route, **two named lifters with separate jobs**, a
measured time with a date, the doubled time, a written script, and a written stop rule. **Plus** the equipment calls
made and written up, or a dated note that the household has no such equipment. **"We'd manage" does not pass** — the
page must name people.

**Assessment.** By an adult who did not write the plan, or a neighbour/CERT witness. Rated **NOT YET / DEMONSTRATED /
CAN TEACH IT**; life-critical, so CAN TEACH IT is the standard for at least one adult. **Hours.** 3, plus the calls.

**Who must be able.** Two adults to CAN TEACH IT — two, because one is a single point of failure. Every other adult to
DEMONSTRATED on the route and the script. Children over eight can state the route in their own words and know they are
not the lifter.

---

## 8.4 Module `MOV-3` — the timed drill

### 8.4.1 The rules of the drill, before the clock

The drill is timed, and the time is **information, not a target.** That distinction is the whole module. A household
that treats the clock as a target will rush the slowest member, and a rushed lift on a stairwell is the exact injury
this entire chapter exists to prevent. A fall on the stairs during a drill would be a worse outcome than a slow
evacuation during a real event.

So, five rules, and they are absolute:

1. **Nobody is rushed, ever.** The clock starts when the household decides to go and stops when the last person is at
   the rally point. If anyone is hurried, the drill is void and you run it again next week.
2. **The slowest member sets the pace**, and everyone else matches it. No one overtakes on the stairs.
3. **The drill is abandoned, not pushed through**, if anyone is unwell, if the weather is bad, if the stairwell is
   wet, or if anyone becomes distressed. Abandoning a drill is a pass, not a failure — it means the household
   recognised a limit.
4. **It is run in daylight, in good weather, first.** The night version comes only after two clean daytime runs.
5. **Nothing is carried that is not on a worksheet.** No improvised loads, no "let's see if we can also take."

### 8.4.2 The drill, minute by minute

**Before you start.** Everyone in shoes. Everyone knows it is a drill. The slowest member knows they will be carried or
assisted and has agreed. The route is the one on the plan page. One person holds the clock and does not lift. One
person has the phone and the ICE card.

**Minute 0 — the call.** The adult in charge says the same sentence the household will hear in a real event: *"We're
going out. Left stairs. Everyone to the front of the building."* The same words every time, so that in a real event the
words are already familiar. The clock starts.

**Minutes 0–2 — the bags.** Each named carrier picks up their own bag. The child picks up theirs. The adult carrying
for the elder picks up the elder's. Nobody goes back for anything. If a bag is missing, it is left — the drill is
testing the plan, not the packing, and a household that stops for a bag has learned something worth writing down.

**Minutes 2 onwards — the lift and the route.** The two lifters take their positions. The script is said out loud to
the person being carried. The route is walked at the pace of the slowest member, with the second lifter ahead, clearing
and holding. The clock-holder walks behind and says nothing except a safety word if something is wrong.

**The stairwell.** This is where the time goes and where the plan is tested. Count the flights out loud on the first
run, because the count is a number the household will remember and the plan needs it. Note where the handrail changes
sides, where the door sticks, where the landing is too small to turn.

**The exit and the rally point.** Out of the building, to **rally point one** (§8.5), and the clock stops when the last
person arrives — not when the first one does. That is the number that matters and the only number written on the plan.

**Afterwards — the debrief, which is the point.** Ten minutes, everyone sitting down, three questions. What was slower
than we thought? What did we have to improvise? What would have hurt someone? Then one change, made before the next
run, and only one — a household that changes five things at once learns nothing about which one worked.

### 8.4.3 Reading the number honestly

Write the time on the plan page with the date. Then write the doubled time beside it. Then answer one question in
writing: **is this number compatible with the hazards we actually face?** For a fire in the building, the answer may be
no, and the honest response is not to train harder — it is to move the sleeping arrangements, or to move the household,
or to accept in writing that the risk is real and unfixable where you live. For a slow-building hazard — a flood
warning, a heat wave, a utility failure with a day's notice — almost any number is compatible, because the household
will start hours before it needs to.

That comparison is the real output of the drill. Not a time. A judgement, written down, about whether this household
can leave this building fast enough for the hazards it actually faces.

### 8.4.4 The module, stated as a module

**Objective.** Run the assisted evacuation drill, timed, to rally point one, at the pace of the slowest member, and
produce a written time, a written doubled time, and a written judgement about whether that is fast enough.

**Chapters.** `08 §8.3–8.4` · `08 §8.5` (the rally point) · `01` (the hazards being judged against) · `10` (the drill
log).

**Drill.** The full sequence in §8.4.2, twice in daylight, then once after dark. Abandoned and re-run if any rule in
§8.4.1 is broken.

**Observable pass criteria.** Two clean daytime runs and one night run, each with a recorded time; the last person —
not the first — timed to the rally point; a written doubled time; a written answer to the "is this fast enough"
question; and a debrief note with exactly one change made between runs. **A run in which anyone was hurried does not
count**, and a household that reports a fast time with a distressed slow mover has failed the module regardless of the
clock.

**Assessment.** By an adult who did not run the drill, or a neighbour/CERT witness who watched it. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**; life-critical. **Hours.** 4 across the three runs and the debriefs.

**Who must be able.** Every adult to CAN TEACH IT — every adult must be able to run the drill with a different adult
carrying. Children over eight to DEMONSTRATED: they walk the route, they carry their bag, they arrive at the rally
point, and they do not go back. An elder is rated on the script and on knowing what is happening, not on speed.

---

## 8.5 Module `MOV-4` — rally points, comms, and the destination tier

### 8.5.1 Two rally points, and why two

**Rally point one** is close: the front of the building, the tree on the corner, the far side of the street. Somewhere
the household can be standing together within a minute of leaving, and somewhere that is not the building's own
doorway — because the doorway is where everyone else will be, and it is the one place that is guaranteed to be crowded
and in the way of the fire service.

**Rally point two** is further: the corner shop, the school gate, the library, the bus stop two blocks away. It is used
when rally point one is unusable — because the incident is at the building, because the wind is blowing the wrong way,
because the household has been separated and the first point is not safe to wait at.

Both are written on the child's card, on the fridge-door card, and in every bag. Both are named as **places**, not
addresses, because a nine-year-old can find "the tree outside the laundrette" and cannot use a postcode.

**The rule that makes them work: the household goes to the point and stays there.** The instinct after a separation is
to search, and searching is how people are lost. The plan is that whoever gets out goes to point one, waits, and if
point one is unusable, goes to point two. The person who is missing knows that too, which is the entire reason the
child's card exists.

### 8.5.2 The out-of-area contact

One person, outside the area, who is not affected by whatever is happening, and whose number every member of the
household has **on paper**. The reason it is out-of-area is that local networks fail first and local people are
affected by the same event. The reason it is on paper is that a phone with a dead battery has no contacts in it.

The contact has one job: to be the place where the household reports in, so that a separated member can call one number
and hear "your mother is at the school, she is fine." Give that person the household's names, the two rally points, and
a note of anyone's medical needs. Doc 10 carries the ICE card.

### 8.5.3 When the phones fail

Phones fail in four different ways, and the plan needs an answer for each.

**No power.** Charging is the problem, not the phone. A charged power bank in every bag, and one in the car, checked on
the same date as the bags. This is the failure mode the household can actually fix in advance, so fix it.

**No signal.** Networks congest and towers lose power. The answer is text messages before voice calls — a text is a few
bytes and gets through when a call cannot — and the answer is patience, because a message can be delivered hours later
and the sender will not know. Send the plan, not the panic: *"we are fine, going to point two, will try again at 6."*

**A dead battery and no charger.** The answer is paper: the ICE card, the rally points, and the out-of-area number,
written down and carried, not stored. This is the only comms method in this chapter that never fails, and it costs
nothing.

**A household that is separated.** The answer is the rally point, and the answer is that nobody searches. One adult may
go to the second point to check; nobody goes back into a building, ever, for any reason, and that rule is taught to
children in exactly those words.

### 8.5.4 The destination tier — where you would actually go

If the household leaves for more than an hour, it needs somewhere to be. This program ranks destinations in three
tiers, and the household should have a named option in each.

**Tier one — somewhere staffed, and official.** A public shelter, a cooling or heating centre, or a disaster assistance
point. In the United States, **2-1-1** is the number that tells you where these are, and it is the number to call
before you drive. Two facts the household must know in advance: **most public shelters accept service animals only**,
so a pet needs a separate plan (Ready.gov, https://www.ready.gov/evacuation); and a shelter is not a hotel — it is a
cot in a hall, and an elder who cannot sleep on a cot should know that before arriving.

**Tier two — somewhere known, and private.** A relative or friend with power, water, and a ground-floor entrance,
who has **already agreed** to take the whole household, including the slow mover and the equipment. "Already agreed"
is the operative phrase: a destination that has not been asked is not a destination, it is a hope. Ask this week, and
ask specifically whether the entrance has steps and whether there is a bed the elder can get out of.

**Tier three — staying put, properly.** This is the tier most households will actually use, and it is not a failure.
Staying means doc 04's warm room, doc 02's water, doc 03's food, and doc 07's door. The reason to name it as a tier is
that a household which has decided in advance to stay does not panic on day three and make a bad decision at speed.

**The trigger that moves a household from tier three to tier one or two is in doc 01's decision tree**, and it is
pre-signed on the decision card. It is not a judgement call made at 2 a.m.

### 8.5.5 The module, stated as a module

**Objective.** Name two rally points, name and brief an out-of-area contact, write the phones-down plan on paper for
every member, and name a destination in each of the three tiers.

**Chapters.** `08 §8.5` · `01 §1.5` (the decision tree) and `01 §1.10` (the pre-signed card) · `10` (ICE card, rally point cards) ·
`04` (what "staying put" actually requires).

**Drill.** A separation drill: the household leaves by two different routes, meets at rally point one, then walks to
rally point two. Then the out-of-area contact is called, from a phone with the number read off paper, and told the
plan. Then the shelter question — call 2-1-1 and ask where the nearest cooling or heating centre is, and whether it
accepts a pet.

**Observable pass criteria.** Two named rally points on every card in every bag; an out-of-area contact who has been
called and who can state the household's names and rally points back to you; a paper comms card carried by every
member including the child; and a named destination in all three tiers, with the tier-two destination **confirmed by
the person who lives there**. **A tier-two destination that has not been asked does not pass.**

**Assessment.** By an adult who did not make the calls, or a neighbour/CERT witness. Rated **NOT YET / DEMONSTRATED /
CAN TEACH IT**. **Hours.** 3.

**Who must be able.** Every adult to CAN TEACH IT. Children over eight to DEMONSTRATED: they can name both rally
points, show their card, and state the rule that nobody goes back inside. An elder is rated on carrying the card and
on knowing the out-of-area contact's name.

---

## 8.6 Closing the chapter

**What this chapter gives you is a number.** Not a route, not a bag list, not a destination — a number, measured on a
stairwell, at the pace of the slowest member of your household, on a day when nobody was hurt. Everything else in the
chapter exists to make that number usable: bags that can be lifted by the people named to lift them, a one-page plan
with two lifters and a script and a stop rule, two rally points a child can find, a paper comms card that works when
the phone does not, and a destination in each of three tiers with the second one already agreed by the person who
lives there.

You also know what this chapter would not do. It will not tell you how to transport an oxygen cylinder, specify an
evacuation chair, or design a wheelchair route, because no authoritative source for any of those was retrievable and
this program does not publish a procedure it cannot cite. It gives you the four calls that get you the real answer —
the equipment supplier, the prescriber, the building manager, and the fire service's non-emergency line — and it tells
you to make them while the phones work. And it does not present an "elder go-bag" or a "child go-bag" as official,
because no federal source differentiates bags by person; the worksheets here are the team's own adaptation of the
federal list, labelled as such on every page.

**And the sentence that keeps the chapter honest, which is the one to say out loud at the household meeting:** *we are
planning to stay, and this plan is what makes staying safe — because a household that can leave in a measured way
never has to leave in a panic.*

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version 1.0,
errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a source does
not cover an item — per-person go-bag differentiation, oxygen-cylinder transport, evacuation-chair specification,
wheelchair route planning, assisted-evacuation procedure for people with disabilities, and any specific shelter's
intake rules — this document says so rather than supplying a procedure, and sends you to the equipment supplier, the
prescriber, the building manager, the local fire service's non-emergency line, 2-1-1, or Ready.gov's own pages.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
