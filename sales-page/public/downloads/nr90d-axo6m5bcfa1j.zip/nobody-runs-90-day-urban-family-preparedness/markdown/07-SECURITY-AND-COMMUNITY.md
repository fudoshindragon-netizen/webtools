# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 07 — SECURITY AND COMMUNITY

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

Most preparedness books put a photograph of a shotgun on this chapter. This one does not, and the reason is not
squeamishness — it is that the photograph is a lie about what keeps a household safe in a long outage.

Security in a 90-day utility failure is **not a fortification problem.** It is a lighting problem, a sightline
problem, a door that answers safely, and a set of neighbours who know your name. Those four things are cheap, legal
everywhere, work when the power is out, and do not endanger the four-year-old in the back bedroom or the
eighty-year-old who cannot see well enough to identify a face at the peephole.

> **The rule this chapter is built on.** **This document contains no build specifications.** No door-hardening
> detail, no lock ratings, no window film, no alarm wiring, no "safe room" construction. That material was not
> retrieved from any authoritative source during the research for this program, and this program does not fill a gap
> in its sources with general knowledge. What you get instead is an **assessment**: a walkthrough you score,
> questions you ask the people whose job it is to know, and a door protocol you rehearse until a child can do it
> without thinking.

Four modules close here — **`SEC-1`** the assessment, **`SEC-2`** the door protocol, **`SEC-3`** mutual aid and CERT,
**`SEC-4`** legal reality. None is finished by reading this page.

---

## 7.1 What security actually is, in an outage

### 7.1.1 The thing that changes when the lights go out

In an ordinary week, most of a city's informal security is provided by other people being around — the dog walker, the
delivery van, the neighbour's porch light, the fact that a street of nine occupied houses is a bad place to be
conspicuous. A long outage does not create criminals. It removes the **ambient witnesses** and it removes the
**light**, and those two removals do most of the work that a household will later blame on "the situation."

That reframing tells you where to spend effort. If the risk is ambient-witness loss, the highest-value countermeasure
is **restoring the appearance of ordinary occupation and ordinary neighbourliness** — lights where there were lights,
people visible where people were visible. If the risk were armed intruders, the countermeasure would be hardware and
this chapter would look completely different. It does not, because the evidence does not support that framing, and
because this household has an elder and a small child in it, which makes hardware a net risk rather than a net
benefit.

### 7.1.2 Layers, in the order they pay

Five layers, from the street inward. Each is cheaper and more effective than the one inside it, and each is useless if
the one outside it is neglected.

1. **The street and the approach** — what a person across the road can see, and what they conclude about whether
   anyone is home and whether anyone is watching.
2. **The building and the shared entrance** — frontage and gate for a house; lobby, intercom, stairwell, corridor for
   an apartment. This layer belongs partly to a landlord and partly to a building full of neighbours, which is why it
   is the layer most often left undone.
3. **The door** — the one control point a household genuinely owns. Not its construction. Its **protocol**.
4. **The people inside** — who answers, from where, with whom present, and what they say.
5. **The people outside who know you** — neighbours, the building committee, the CERT contact, the nurse two doors
   down. This is the layer that keeps working when the phone does not.

Most households jump straight to layer three and buy something. Work from layer one outward: layer one costs nothing,
layer five costs one awkward conversation, and layer three — done as protocol rather than carpentry — costs a Saturday
afternoon of rehearsal.

### 7.1.3 What this chapter will not do

- **It will not tell you how to reinforce a door or a window.** Not because you should not, but because no
  authoritative source retrieved for this program specifies it, and a specification invented by a book is worse than
  none. §7.2.4 sends you to the people who do know.
- **It will not discuss weapons** — not tactics, not storage, not construction, not "what if." §7.5 explains why.
- **It will not tell you to form a patrol or a watch.** A neighbourhood that organises into something resembling an
  armed patrol in a disaster has created a legal problem, a liability problem, and a target, in that order.
- **It will not promise that any of this prevents a determined intruder.** Nothing in a book does. It makes the
  household a worse target than the one next door, and makes the people inside calm enough to think — and calm is the
  actual product here.

---

## 7.2 Module `SEC-1` — the security assessment

### 7.2.1 What this module is

`SEC-1` is a **walkthrough you score**, followed by **one phone call**. No shopping list, no build, no tool.

It is an assessment rather than a build because of honesty. The research behind this program found **no retrievable
federal page on residential target-hardening**, and the program's rule is that an uncited number does not get printed.
What the research did find, and what can be cited, is **CERT** — which FEMA describes as educating volunteers "about
disaster preparedness for the hazards that may occur where they live" and training them in "basic disaster response
skills" through "a consistent, nationwide approach to volunteer training and organization that professional responders
can rely on" (https://www.ready.gov/cert). That is a real, free, legitimate route to neighbourhood competence, and
§7.4.4 covers it. What CERT is not is a door-hardening specification, and this module does not pretend otherwise.

### 7.2.2 The walkthrough — how to do it properly

Do this **twice**, on two days, at two times: once in daylight, once after dark. The daylight walk is about what is
visible. The dark walk is about what is *not* visible, and it is the one that will surprise you.

Start **across the street**, not at your own front door. Stand where a stranger would stand. This is the most
important instruction in the module: a household that starts at its own threshold can only see its own threshold, and
the whole point of layer one is what the approach looks like from outside.

**Layer one — the approach.** Can I tell from here whether anyone is home? What tells me — a light, a car, a curtain,
a dog? If the answer is "nothing," the house reads as empty, and an empty house in a dark street is the one that gets
looked at. Is there anywhere a person could stand unobserved from the windows — a hedge, a parked van, a recessed
doorway, a bin store? Is the street lit, and by anything that will still work on day three?

**Layer two — the building or the block.** If you rent, this layer is not yours to change, which is exactly why you
must document it: the lobby light out since March, the dead intercom, the stairwell door that does not latch, the fire
door propped with a brick. Write them down with dates. A landlord's obligation to maintain a building is real, and a
dated written list is the difference between a complaint and a record. If you own, this is the layer where the
crime-prevention unit's advice will be specific and cheap.

**Layer three — the door, as a control point.** Not "how strong is it," but "what happens at it." Which door does the
household actually use? Does everyone know which one is the answer-door? Can you see who is there before you open it —
and can you see them **at night**, which is a different question? Is a second adult within earshot at the times
someone might knock? This is the layer this chapter works on, and §7.3 is the whole of the answer.

**Layer four — the people.** Who in this household would answer the door if it were knocked on right now? The
nine-year-old? The eighty-two-year-old? Would either open it? Has anyone ever told them, in words they could repeat,
what to do instead? Most households discover here that the honest answer is "the child probably would, because that is
what we do in normal life," and that discovery is the actual value of the walkthrough.

**Layer five — the people outside.** How many people within a hundred metres of your door do you know by name? How
many would recognise your child? How many would notice a van sitting outside for two hours? For most urban households
the number is zero or one. §7.4 is about changing it, because it is the cheapest security measure in this program and
the only one that still works when the lines are down.

### 7.2.3 Scoring it — the honest instrument

Score each line **0, 1, or 2.** Zero means not true at all. One means partly true, or true some of the time. Two means
true and demonstrable to a visitor.

| # | Statement | Score |
|---|---|---|
| 1 | Standing across the street in daylight, I can tell that someone is home. | 0 / 1 / 2 |
| 2 | Standing across the street after dark, I can tell that someone is home. | 0 / 1 / 2 |
| 3 | The approach to my door has no place where a person could stand unobserved from my windows. | 0 / 1 / 2 |
| 4 | There is a light at the answer-door that works without mains power. | 0 / 1 / 2 |
| 5 | I can identify a person at the door, at night, before opening it. | 0 / 1 / 2 |
| 6 | Everyone in the household knows which door is the answer-door. | 0 / 1 / 2 |
| 7 | No one opens the door to an unexpected caller without the protocol in §7.3. | 0 / 1 / 2 |
| 8 | A second adult can hear the answer-door from somewhere in the home. | 0 / 1 / 2 |
| 9 | Every fault on the shared entrance is written down, with a date, and reported. | 0 / 1 / 2 |
| 10 | I can name three neighbours and say which one has medical training. | 0 / 1 / 2 |
| 11 | At least one neighbour would notice if something were wrong at my home. | 0 / 1 / 2 |
| 12 | I have spoken to my local crime-prevention unit, or have the number and a date to call. | 0 / 1 / 2 |

**Total out of 24.** There is no pass mark, and this program will not invent one, because the instrument is not
validated and pretending otherwise would be exactly the fabricated authority this book exists to avoid. The score is
for **comparison with yourself**: score now, do the four modules, score again in six weeks, see which lines moved. A
line that stays at zero across two scorings is one you have consciously accepted — write down that you accepted it,
and why. Line 12 at zero is the only one this chapter will nag about, because it costs one call.

### 7.2.4 The phone call — the part most households never make

Nearly every police department in the United States has, or can route you to, a **crime-prevention unit** or a
community-policing officer whose remit includes advice about residents' own property. It is free, it is not an
emergency line, and the person on the other end has seen your street and can tell you things no book can.

**Use the non-emergency number, not 911.** Look it up on your local department's own website rather than from a search
result, and write it on the ICE card in doc 10. Ask these five questions, in this order, and write the answers down:

1. "I'm doing a security assessment of my home at [address]. Is there an officer or unit who does residential security
   surveys, and how do I request one?"
2. "What do you most commonly see go wrong on streets like mine — the specific things, not the general advice?"
3. "Are there physical measures you'd advise **against** for a home with a young child and an elderly resident?" This
   matters more than it looks. Well-meant hardware — bars, secondary locks an elder cannot operate, anything that
   turns a bedroom into a room you cannot get out of — kills people in fires. A fire you cannot escape is a likelier
   cause of death in an outage than an intruder, and a crime-prevention officer will tell you so.
4. "Is there a neighbourhood watch, block group, or community meeting in my area, and who runs it?"
5. "If I rent, is there anything the landlord is required to maintain here that I should be reporting?"

Then the second call: **your landlord or building manager**, if you rent — the layer-two list, with dates, in writing.
You are not being difficult; you are creating the record that matters if the shared entrance is the thing that fails.
And the third: **your insurer**, if you have one. Many homeowner and renter policies include loss-prevention advice,
and some discount for it.

### 7.2.5 The module, stated as a module

**Objective.** Complete a two-time-of-day security walkthrough of your own home, score it on the 12-line instrument,
and make contact with the local crime-prevention unit and, if renting, the landlord.

**Chapters.** `07 §7.1–7.2` · `01 §1.2.6` · `10` (ICE card, where the non-emergency number goes) · `04` (fire escape
routes, which constrain every security decision).

**Drill.** Daylight walk with the score sheet; dark walk with a torch and the same sheet. Then the calls.

**Observable pass criteria.** A completed score sheet with a total, dated; the two walks on different days; a **named**
person or unit at the police department spoken to, with the date and what they said on the sheet; and, if renting, a
dated written list of building faults submitted. A sheet filled in from the armchair in one sitting does not pass —
the dark walk is the whole drill.

**Assessment.** By an adult who did not do the walkthrough, or a neighbour or CERT contact who walks it with you.
Rated **NOT YET / DEMONSTRATED / CAN TEACH IT**. `SEC-1` can reach CAN TEACH IT, because you can walk a neighbour's
home with them and score it. **Hours.** 3 (two walks, then the calls).

**Who must be able.** One adult to CAN TEACH IT. **Every other adult to DEMONSTRATED**, including the one who thinks
this is obvious — the person who thinks it is obvious is usually the person who opens the door. **Children over
eight** are not asked to score the home; they point at the answer-door and say who may open it (§7.3.4).

---

## 7.3 Module `SEC-2` — the door protocol

### 7.3.1 The rule, and why it is a rule

The single most useful security sentence in this program: **the household decides, in advance and out loud, who
answers the door, from where, with whom present, and what they say — and then rehearses it until nobody has to
think.**

It must be rehearsed rather than understood because a knock at the door is a **social** event, and social events run
on reflex. The reflex of a polite adult is to open the door. The reflex of a child told "don't open the door" is to
open it and explain that they are not supposed to. The reflex of an elder is to be helpful to whoever is standing
there, because that is what forty years of being a decent person taught them. No amount of reading changes a reflex.
Repetition does. So the protocol has four parts, and every household fills all four in:

- **Who answers.** One named adult at any given time of day. Not "whoever is nearest."
- **From where.** With the door **closed and locked**, through the door, or at a window or viewer — never with the
  door open and a foot in it.
- **With whom present.** A second adult within earshot for any unexpected caller, or the answerer does not engage
  beyond the script. For a household with one adult in it during the day, that means the shortest script and no
  opening of the door at all.
- **What they say.** A short, non-escalating, repeatable line — different for a child, an elder, an adult.

> **The one thing every version has in common: it never explains, never apologises twice, and never says who is or is
> not inside the house.** "I can't help you" is a complete sentence. "My husband's in the shower" is an invitation to
> wait.

### 7.3.2 The child's script

For a child old enough to be alone in a room for ten minutes — roughly eight and up, and you know your own child.
Written to be said **through a closed, locked door**, from a spot the child has been shown, and it has exactly three
lines, because a child under stress can hold three and not five.

Teach it by doing it. Stand on the landing. You knock. The child says line one. You say something difficult — "I'm
here about the water, can you open up?" — and the child says line two. You say something friendly — "your mum asked me
to drop this off" — and the child says line three. Then swap, so they hear it from the other side.

**Line one — the answer.** *"I'm not allowed to open the door. I'll get a grown-up."*

**Line two — if they keep talking.** *"I can't help you. Someone will come."*

**Line three — the exit.** *"I'm going to get a grown-up now."* Then the child **walks away from the door** to the
nearest adult, or the phone, or the neighbour's, whichever the household decided in advance.

Three things the script deliberately does. **It does not say the child is alone** — "I'll get a grown-up" is true
whether there are four adults in the house or none, and it removes the child from the category of easy target without
a single lie. **It does not ask the caller anything** — no "who is it?" through a door with no viewer the child can
use; a child is not equipped to evaluate an answer, and a child who asks is a child in a conversation. **It does not
require the child to be brave** — the last line is an instruction to leave, which is the easiest thing on the list and
the thing that works.

**What the child must also know, in their own words, unprompted:** the answer-door; the spot to stand, out of the line
of the door; the neighbour's door they may go to; and that **they will never be in trouble for not opening the door** —
not if the caller was legitimate, not if it was a delivery, not if it was someone they know. That last is not
sentiment. A child who fears a telling-off will open the door, and the fear of trouble is a more reliable door-opener
than any stranger.

### 7.3.3 The elder's script

For an older adult who may be alone in the house during the day, written differently on purpose, because the threat is
different. An elder is not usually targeted by a stranger who wants to force a door. An elder is targeted by a
**conversation** — the person who claims to be from the water company, who says a neighbour sent them, who is
plausible and slightly urgent and knows the name of the street.

So the elder's script rests on one principle: **no decision at the door, ever.** Not about money, not about letting
someone in to check a pipe, not about signing anything, and not about whether the person is telling the truth. The
decision is deferred, always, to a phone call.

**Line one.** *"I don't open the door to anyone I'm not expecting. Please leave a note."*

**Line two — if they say it's urgent, or official, or about the water.** *"Then ring the number on my bill. I don't do
business at the door."*

**Line three — if they will not go.** *"I'm closing the door now and calling my family."* Then close it, lock it, and
make the call — to the adult named on the household contact card, whether or not anything is actually wrong.

And the standing rule that goes with it, worth more than the script: **the household's real utility company does not
need to come inside today.** If water or power needs attention in an outage, the household rings the number printed on
its own bill and asks. A person at the door is not that call. In a long outage, a plausible person at the door claiming
to be from the utility is one of the most predictable things that will happen to an elder alone in a dark building, and
the answer is not suspicion — it is **deferral**, which is easier to sustain, because it lets the elder stay polite,
which is what the elder wants to be.

**Write the script down, in large print, and tape it inside the hall cupboard or beside the door — not on the outside
of the door.** An elder under pressure will not recall a paragraph. An elder will read a card with three lines. Doc 10
carries the large-print version.

### 7.3.4 The adult script, and the rehearsal

The adult version is the same four parts with more judgement allowed.

**Answer with the door closed and locked.** Use the viewer if there is one; if there is not, and you cannot identify
the caller, you are not obliged to open the door to find out — ask them to state their business through it, which is
what any reasonable person does in a dark building.

**One question, one answer, no negotiation.** *"Can I help you?"* is a complete opening. If the answer is "I need to
come in," the answer is *"I'm not letting anyone in tonight. Leave a note or come back in daylight."* If it is
genuinely an emergency — someone hurt in the street, a fire in the building — that is what the emergency number is
for, and calling it is faster and better than opening the door.

**Never let the conversation move you.** A person who wants you to open the door will try to move the conversation to a
place where opening it is the polite thing to do. You do not have to follow. *"I'm not opening the door"* repeated in
the same tone, three times, ends almost every encounter, and ends it without an insult.

**Do not open the door to a stranger while holding a child.** One arm full, one decision compromised. Hand the child to
the second adult, or do not answer.

**The rehearsal.** Once, before the drill in doc 08, and again at the six-month re-score. Ten minutes. One adult
knocks, one adult answers, one child answers, and — if the elder is willing — the elder answers. The person knocking
should be **difficult on purpose**: plausible, friendly, slightly urgent, using the household's own names, because that
is what the real version sounds like. Nobody is corrected in the moment; you talk afterwards, and run it again next
week.

**The line that goes on the fridge door, beside the household decision card:** *we do not open the door to people we
are not expecting, and nobody is in trouble for that.*

### 7.3.5 The module, stated as a module

**Objective.** Write the household's four-part door protocol, teach the child's script and the elder's script, and
role-play both until each is delivered without prompting.

**Chapters.** `07 §7.3` · `10` (large-print scripts, fridge-door card) · `04` (the answer-door must never be a door
the household needs for fire escape — see §7.2.4, question 3) · `12` (the knowledge check).

**Drill.** The ten-minute role-play, four ways: adult answering an adult; child answering an adult; elder answering an
adult; and the caller who will not leave.

**Observable pass criteria.** **The child delivers all three lines, unprompted, through a closed door, to an adult they
do not know is acting, and then walks away from the door** — and can state the neighbour's door and the "never in
trouble" rule in their own words. **The elder delivers lines one and two unprompted and defers the decision to a phone
call.** **Every adult states the four parts** — who answers, from where, with whom present, what they say — without
reading them. Reading aloud from the card does **not** pass for an adult; the card is for the elder under stress, not
for the rehearsal.

**Assessment.** By an adult who did not write the protocol, or a neighbour/CERT witness. Rated **NOT YET /
DEMONSTRATED / CAN TEACH IT**. The child is rated on **capability, not fear** — "can they do it," not "do they
understand the danger." **Hours.** 2, plus ten minutes at every re-score.

**Who must be able.** Every adult to CAN TEACH IT. Every child over eight to DEMONSTRATED on the three lines. Every
elder to DEMONSTRATED on lines one and two — and if an elder cannot, for reasons of cognition or hearing, then the
protocol changes: that elder does not answer the door at all, and someone else does, or nobody does.

---

## 7.4 Module `SEC-3` — mutual aid, and CERT

### 7.4.1 Why this is the highest-return security action available

If this chapter had to keep one page and burn the rest, it would keep this one.

The research behind this program records, as clearly-labelled editorial judgement rather than citation, that **mutual
aid is the highest-return investment a household can make** — specifically that a household should know **three
neighbours by name** and know **which one has medical training.** It outranks everything else structurally: every
other layer in §7.1.2 depends on someone noticing. A light depends on someone seeing it. A door protocol depends on
someone being home. A call to the police depends on a phone that works and a response that comes. A neighbour is the
only security asset in this program already standing on the other side of your wall, needing no power, no signal, and
no money.

Three names. Not a network, not a group chat, not a plan — three names. That is the whole ask, and it is small enough
that there is no excuse for not having done it, which is exactly why this module puts a date on it.

### 7.4.2 The three names, and what to write beside each

Use the mutual-aid worksheet in doc 10. For each of the three:

- **Name, and the door** — not "the woman in 4B," but the name and which door.
- **What they can do that you cannot.** Medical training is the one the research names and the one to ask about
  directly. But it may be that one is home all day, one has a car, one has a landline, one has a key to the shared
  basement, one is a retired building engineer who knows where the risers are.
- **What you can do that they cannot.** Mutual aid that flows one way is charity, and charity does not get offered at
  2 a.m. Write down what you bring — a car, a spare phone battery, a working landline, someone who can lift, someone
  calm with a confused elder, a second pair of hands.
- **How to reach them when the phones are down.** A knock pattern, a note under a door, a signal agreed in advance.
  This line turns a name into an asset.
- **What they need to know about your household before they need to know it.** That the elder in 3A has dementia and
  may not recognise a rescuer. That a child has been told to come to their door. That someone uses oxygen and the
  equipment is heavy. This is what lets a neighbour help instead of hinder, and it is given in peacetime, voluntarily,
  by the household — never collected by anyone.

### 7.4.3 The conversation, which is the hard part

Most people who read this far will not have the conversation, and the reason is not laziness. It is that knocking on a
neighbour's door to say "I've been thinking about emergencies, could we swap numbers" feels strange in a building
where people have exchanged nods for six years.

So do it in a shape that is already normal — **the thing you already need.** *"I'm putting together a list of numbers
for our building in case the power goes out — can I put yours on it, and is there anything I should know about your
flat?"* That is not a strange request. It is what a competent neighbour does, and it gives the other person a reason to
say yes that is not about fear.

Ask the medical question directly and without drama: *"Is there anyone in your flat with medical training? I'm asking
everyone — it's the one thing I'd want to know in a building like ours."* People are flattered by being asked, not
offended, and the ones who say no often name the one who would know. Then write it down, and **give them yours in
return**, on paper, because the entire point is the day the phone does not work.

### 7.4.4 CERT, and the free FEMA courses

The legitimate, sourced, free route to neighbourhood competence in the United States is **CERT — Community Emergency
Response Team**, run through FEMA and delivered locally by a sponsoring agency. FEMA's own description, quoted in
§7.2.1, is that CERT "educates volunteers about disaster preparedness for the hazards that may occur where they live"
and trains them in "basic disaster response skills" through a "consistent, nationwide approach to volunteer training
and organization that professional responders can rely on" (https://www.ready.gov/cert).

Three things make CERT the right recommendation here, and most of what is sold as "tactical training" the wrong one.
**It is free** — the independent-study courses are free and self-paced online, and the local class, where one exists,
is typically free as well. **It is taught by people whose job is disaster response**, and it teaches you to support
professional responders rather than replace them; a CERT-trained neighbour knows how to shut off a gas meter, do a
light search of a damaged building, and — crucially — **how not to become a second casualty**, which is the failure
mode of every self-appointed rescuer. And **it puts you in a room with the other people who did it**: the course is the
excuse, the room is the asset, and the person you sit next to is the person who will be on your street in the outage.

**The entry point** is **IS-317.A, *Introduction to Community Emergency Response Team (CERTs)***, on FEMA's
independent-study site at `training.fema.gov` (https://training.fema.gov/is/courseoverview.aspx?code=IS-317). A second
course worth the hour is **IS-22, *Community Preparedness: Implementing Simple Activities for Everyone***. To find a
local class, search "CERT" plus your city or county, or start from the Ready.gov CERT page and follow the link to local
programs — CERT is delivered locally through a sponsoring agency, usually a fire department or office of emergency
management.

**Two honest caveats.** This program does not claim a specific free Red Cross course exists, because the research could
not retrieve the relevant pages and this book does not print what it cannot cite; if your local Red Cross offers
first-aid training, that is a fine thing to take, and verify it yourself. And **CERT is not a security course** — it
will not teach you to defend a building, and it is not meant to. It teaches you to be useful and to be safe, which is
what this household actually needs.

### 7.4.5 What mutual aid is not

**It is not a patrol.** A group of neighbours walking the block at night with torches, in a city, in a disaster, is not
a security measure. It is a group of people with no legal authority, no training, no insurance, and no ability to tell
a resident from an intruder, moving through a dark street where the police are already stretched. It creates
confrontations that would not otherwise have happened, it creates liability for everyone in it, and in some
jurisdictions it creates criminal exposure. **This program does not recommend it and does not describe it.**

**It is not a group chat that becomes a rumour engine.** A building chat circulating unverified claims about who is
"casing" the building does more harm than the thing it worries about, because it turns neighbours into suspects. If
something is genuinely wrong, the route is the non-emergency number, then the landlord, then the block meeting.

**It is not a debt, and it is not a substitute for the professionals.** You are not building a network to call in; you
are building the ordinary reciprocity that makes a building function. And in a genuine emergency — a fire, a medical
emergency, a crime in progress — the emergency number is dialled first, not after the group chat.

### 7.4.6 The module, stated as a module

**Objective.** Name three neighbours, record what each can do and what you can do for them, hold one real
conversation, and register for a FEMA independent-study course or a local CERT class.

**Chapters.** `07 §7.4` · `01 §1.2.6` · `10` (mutual-aid worksheet) · `05 §5.10` (what a neighbour with medical
training is actually useful for).

**Drill.** The conversation. Three of them, or one if you live in a detached house with one neighbour — in which case
the third name comes from the wider block, a faith group, a building committee, or the CERT class itself.

**Observable pass criteria.** **Three named neighbours on the worksheet, each with a capability, a reciprocal
contribution, and a phones-down contact method — and at least one conversation that actually happened**, evidenced by a
name, a date, and something the neighbour told you that you did not know before. A worksheet filled in from memory of
faces in the corridor does not pass. **Plus** a dated registration for IS-317.A or a local CERT class, or a written
note that no local class exists and when you will re-check.

**Assessment.** By an adult who did not hold the conversations, or a CERT contact. Rated **NOT YET / DEMONSTRATED /
CAN TEACH IT**. CAN TEACH IT here means you have brought one other household into the conversation — that is what
teaching mutual aid looks like. **Hours.** 4 (two for the conversations, two for the FEMA course).

**Who must be able.** One adult to CAN TEACH IT. Every adult to DEMONSTRATED, because the person who has not met the
neighbours is the person who will be home when it matters. **Children over eight** know the neighbour's door and the
neighbour's name — the child's version of this module, and it pairs with §7.3.2.

---

## 7.5 Module `SEC-4` — legal reality, and why deterrence comes first

### 7.5.1 Why this chapter contains no weapons content, and never will

Nothing here covers weapons, and nothing ever will. This section explains why, because a
buyer who expected a chapter on armed defence and finds this instead deserves a straight answer
rather than a silent omission.

**First, there is no authoritative free source for it.** The research found no federal, state, or reputable non-profit
source publishing weapons tactics or construction for civilian households, and this program's rule is that where a
source does not cover an item, the document says so rather than supplying a technique from general knowledge. That rule
has already cost this book a rehydration formula and a burns specification. It costs it this too, and the rule is worth
more than the chapter.

**Second, the law varies so much that any specific instruction would be wrong somewhere** — and wrong in a way that
creates criminal liability for the reader. §7.5.2 sets out how.

**Third — and this matters most for the household this program is written for — there is a four-year-old and an
eighty-year-old in it.** The research records, as editorial judgement, that households with young children and elderly
members with cognitive decline should treat an unsecured firearm as a **child-safety problem first.** That is not a
debating position. It is the observation that the most likely person to be hurt by a weapon in this specific home is
somebody in this specific home, and a preparedness program that increases the risk to its own readers has failed at the
first task.

### 7.5.2 Why the law varies, at the level a book can honestly state it

Nothing in this program can tell a household what is legal where they live, and any product that claims to is
guessing. What this section can do is tell you **how many separate bodies of law there are**, so you know what to ask
about — and then who to ask.

- **It varies by country, state, county, and city.** Not just by state. A city ordinance can prohibit what the state
  permits, and the reverse.
- **Purchase, possession, storage, transport, and use are five different bodies of law.** A lawful purchase can be an
  unlawful carry. A lawful carry can be an unlawful use. A lawful use in one room can be unlawful in the same room if
  the household's storage did not meet a separate standard.
- **The categories differ.** Firearms, knives, batons, chemical sprays and "self-defence" devices are each regulated
  separately, and a device sold freely in one jurisdiction is a prohibited weapon in another — including items sold as
  keyrings and marketed as defensive.
- **The rules change**, sometimes annually, and a book's errata date is not a legal update service.
- **Use-of-force law is its own subject**, and it is not intuitive. The question a court asks is not "was I frightened"
  but whether the force was proportionate and necessary in the circumstances — fact-specific, jurisdiction-specific,
  and decided by people who were not there.
- **Booby traps and improvised devices are illegal in most jurisdictions**, endanger household members and responders,
  and are permanently out of scope. There is no version of this a household with children should ever consider.

**Who to ask, in this order:** your **state attorney general's office** (most publish plain-language guides to state
law), your **local police non-emergency line** (the same call as §7.2.4 — ask what is legal to possess and how it must
be stored and transported where you live), and **a licensed attorney in your state** if the answer will affect a
purchase or a household decision. Write the answers down and date them, because the answer has a shelf life.

### 7.5.3 Deterrence and less-than-lethal come first

Every credible preparedness framework puts **deterrence before defence**, and the research behind this program records
it as editorial judgement rather than citation — so treat it as judgement, and notice how well it lines up with the
rest of this chapter.

Deterrence is the set of things that make your home a worse target than the alternative, and every one of them is in
§7.1.2: **light where there was light, a building that looks occupied and watched, a door that answers calmly and does
not open, neighbours who would notice, and a household that does not advertise what it has.** None of that needs a
weapon, all of it is legal everywhere, and all of it works whether or not anyone inside is willing to use force.

**Less-than-lethal** measures — better lighting, a louder voice, a locked door, a phone call, a neighbour, leaving the
room, leaving the building — are the correct first answer in almost every circumstance a household will actually face,
and they carry no legal exposure and no risk to the child in the back bedroom. The preparedness genre teaches people to
skip to the last resort, and the last resort is where people get hurt and where people get charged.

**And the honest sentence this program will print, because it is the one that keeps a household safe:** *in a disaster,
the most likely danger to your household is the hazard that caused the disaster, the fire you light to stay warm, the
fall down the dark stairs, and the illness you cannot treat — not a stranger at the door. Security is a real concern
and it is the fourth or fifth one down the list.*

### 7.5.4 If the household already owns something

This program takes no position on ownership, which is a lawful personal choice in most of the United States and a
matter for the household and its own legal advice. But for a household with children and an elder with cognitive
decline, the research's responsible sequence is worth stating plainly.

**Training and legal compliance first** — formal safety training, and knowledge of local law on storage and transport,
before anything else is considered. **Secure storage, away from children and away from household members with cognitive
impairment** — and the reason is not abstract: an elder with dementia who finds an object and does not recognise it is
a foreseeable death, and a child who finds one is the leading category of household firearm injury. **And a plan for
the household member who should not have access**, written down and agreed by every adult.

This program gives no handling instruction, no storage configuration, and no use instruction. If a household wants
that, it goes to a certified instructor in its own state, and takes the safety course before it takes anything else.

### 7.5.5 The module, stated as a module

**Objective.** Establish the household's legal position on the questions that actually affect it — weapons law,
storage and transport law, and the sanitation and waste rules doc 04 depends on — by asking the three named authorities
and writing the answers down with dates.

**Chapters.** `07 §7.5` · `01 §1.5` (the three-branch decision tree, where the security trigger fires; triggers in §1.9) · `04 §4.9` (waste
and its legal endgame, which varies by locality in exactly the same way) · `SOURCES.md`.

**Drill.** Three questions, three authorities, written answers with dates. Then a household meeting at which the answers
are read aloud to every adult, so nobody is operating on an assumption.

**Observable pass criteria.** A dated written record of (a) the state attorney general's published guidance, or a note
that it does not cover the question, (b) the local police non-emergency answer on possession, storage and transport
where you live, and (c) the local rule on emergency waste disposal. Plus a signed line in the household meeting minutes
confirming every adult has heard the answers. **"I looked it up once" does not pass** — the record is the demonstration,
and it is re-dated annually.

**Assessment.** By an adult who did not make the calls, or a neighbour/CERT witness. Rated **NOT YET / DEMONSTRATED**.
There is no CAN TEACH IT requirement here; this is an administrative module and the demonstration is the dated record.
**Hours.** 2 (the calls, then the meeting).

**Who must be able.** Every adult to DEMONSTRATED. No child is involved in this module, and no child is told anything
about weapons by this program — a child's security education here is §7.3.2, the door script and the neighbour's name,
and that is all it should be.

---

## 7.6 Closing the chapter

**What this chapter gives you is a walkthrough, a script, three names, and a phone number.** You know that security in
a long outage is layers arranged from the street inward, that the layers that pay are lighting, sightlines, a door that
answers safely and neighbours who know you — and that the layer most households buy first is the layer that matters
least. You know the assessment is scored and dated, that the dark walk is the one that surprises you, and that the call
to the crime-prevention unit is free and almost never made. You know the four parts of the door protocol, you have the
child's three lines and the elder's three lines, and you know the rule that makes the child's version work: **nobody is
in trouble for not opening the door.** You know that three named neighbours outrank every piece of hardware in this
book, that CERT is the free and legitimate route to competence, and that a neighbourhood patrol is not mutual aid. And
you know why the weapons chapter does not exist — because the law varies to the point where any instruction would be
wrong somewhere, because there is no source this program will print from, and because the household this is written for
has a small child and an elder in it.

**What this chapter deliberately does not give you is a specification.** No door-hardening detail, no lock ratings, no
window treatment, no alarm wiring, no safe-room construction, no weapons content of any kind, and no patrol structure.
Each of those is either unsourced or outside what this program will publish, and the honest alternative is a scored
assessment and three phone calls — which is what §7.2 and §7.5 actually are.

**And the summary sentence for the whole chapter, which is the one to teach a second adult:** *the door does not open,
the neighbours know your name, and nobody in this house is in trouble for either.*

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is version 1.0,
errata date 2026-11-02; corrections are recorded in the README and any corrected figure is dated. Where a source does
not cover an item — residential target-hardening specifications, lock and door ratings, alarm systems, safe-room
construction, assisted-evacuation hardware, weapons law in any specific jurisdiction, and any Red Cross course
offering — this document says so rather than supplying a specification, and sends you to the police crime-prevention
unit, the state attorney general, a licensed attorney in your state, your landlord, or FEMA's own course pages.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
