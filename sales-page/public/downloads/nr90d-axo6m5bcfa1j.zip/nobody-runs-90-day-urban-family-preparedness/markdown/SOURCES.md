# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## SOURCES

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

Every URL below was retrieved and read on **2026-10-30**, from a free, public government, university or
non-governmental source. Page "last updated" dates are noted where the page displayed one.

**How to read the flags.** **[V]** — the figure or rule is stated in the source, was read in it, and may
be printed as fact. **[U]** — the item is *not* covered by any source retrieved; the program prints the
procedure or the mechanism instead of a number, and says so. Where two sources disagree, both figures
are printed in the chapter and the conservative planning number is named.

**What this list is not.** It is not a bibliography of everything on the subject. It is the exact set of
pages the program's numbers came from, so that a reader — or a reviewer — can check any figure in the
book against the page it came from. If a figure in a chapter is not traceable to a line here, that is an
errata and should be reported.

---

## 1. Water

1. **Ready.gov (U.S. DHS/FEMA) — *Water*** (last updated 02/22/2021). https://www.ready.gov/water —
   1 gal/person/day; ¾ gal drinking fluid; hot weather can double the need; container sanitation;
   boiling 1 minute; bleach at 5.25–6.0% as ⅛ tsp per gallon with 30 minutes' contact; iodine not
   recommended; rotate self-filled water every six months. **[V]**
2. **U.S. EPA — *Emergency Disinfection of Drinking Water***.
   https://www.epa.gov/ground-water-and-drinking-water/emergency-disinfection-drinking-water — boil
   1 minute, **3 minutes above 5,000 ft**; full bleach dose table for 6% and 8.25% bleach; double for
   cloudy or cold water; 30-minute contact with a 15-minute re-dose; bleach under one year old;
   boiling and disinfection do not remove chemicals. **[V]**
3. **CDC — *How to Make Water Safe in an Emergency*** (page date 19 Sept 2024).
   https://www.cdc.gov/water-emergency/about/index.html — boil 1 minute, **3 minutes above 6,500 ft**;
   CDC bleach tables for 5–9% bleach; filter pore sizes (0.3 µm bacteria, 1 µm parasites); filters do
   not remove viruses; UV; **SODIS 6 hours sunny / 2 days cloudy**; iodine caution in pregnancy and
   thyroid disease; never radiator or boiler water; cannot fix fuel or chemical contamination. **[V]**
4. **CDC — *How to Create an Emergency Water Supply***.
   https://www.cdc.gov/water-emergency/about/how-to-create-and-store-an-emergency-water-supply.html —
   3-day supply minimum; "at least 1 gallon of water per person, per day for 3 days"; "try to store a
   2-week supply if possible"; replace every six months. **[V]**
5. **CDC — *How to Find Clean Water in an Emergency***.
   https://www.cdc.gov/water-emergency/about/how-to-find-clean-water-in-an-emergency.html — water
   heater tank; toilet tank (not bowl), untreated and clear; pools and spas for hygiene only, never
   drinking; shut off the main valve; rainwater listed. **[V]**
6. **CDC — *Drinking Water Advisories: An Overview***.
   https://www.cdc.gov/water-emergency/about/drinking-water-advisories-an-overview.html — boil-water
   advisory framing. **[V]** on the framing; operational detail was not extracted (**[U]**).

## 2. Food

7. **U.S. FDA — *Food and Water Safety During Power Outages and Floods***.
   https://www.fda.gov/food/buy-store-serve-safe-food/food-and-water-safety-during-power-outages-and-floods
   — **4 hours** in a refrigerator; **48 hours** in a full freezer, **24 hours** in a half-full one;
   the 40 °F refreeze rule; the ice-crystal rule; flood-contact discards; damaged-can discards;
   appliance thermometers. **[V]**
8. **Ready.gov — *Food***. https://www.ready.gov/food — stock foods needing no refrigeration, cooking,
   water or special preparation; ready-to-eat canned items; a manual can opener; pasteurised
   non-perishable milk; infant food; "use ready-to-feed formula… bottled water or boiled water as a
   last resort"; bacteria grow rapidly between 40 °F and 140 °F. **[V]**
9. **Ready.gov — *Build A Kit***. https://www.ready.gov/kit — the federal supply list; several days of
   food; 1 gal/person/day of water; sanitation supplies; prescription and non-prescription medicines.
   **[V]**
10. **Virginia Cooperative Extension — *Food Storage Guidelines for Consumers*, publication 348-960**.
    https://www.pubs.ext.vt.edu/348/348-960/348-960.html — shelf lives for white rice (2 y), brown
    rice (1 y), pasta (2 y), vegetable oil (6 mo), dry milk (1 y), canned vegetables (2–5 y), canned
    meat (2–5 y), honey (2 y), sugar ("indefinitely"). **Dry beans and oats are not in that table and
    no figure is printed for them. [V] / [U]**

## 3. Heat, carbon monoxide and fire

11. **CDC — *Carbon Monoxide (CO) Poisoning Basics***. https://www.cdc.gov/carbon-monoxide/index.html
    (and https://www.cdc.gov/carbon-monoxide/about/index.html) — more than **400** deaths a year from
    unintentional CO poisoning not linked to fires, more than **100,000** emergency-department visits,
    more than **14,000** hospitalisations; the symptom list; sleeping people die before they have
    symptoms; detectors near every sleeping area and replaced every 5 years; **generators outdoors more
    than 20 feet from windows, doors and vents**; **never indoors or in a garage, even with doors and
    windows open**; never charcoal indoors; never a camp stove or flameless chemical heater indoors;
    never heat with a gas oven; do not burn in an unvented stove or fireplace. **[V]**
12. **CDC — *About Heat and Your Health***. https://www.cdc.gov/extreme-heat/prevention/index.html —
    overheating symptoms; **fans only below 90 °F**; cooling centres via 2-1-1; hydration and urine
    colour; high-risk groups; medicines in heat; "don't stop or change your medicines." **[V]**
13. **CDC/NIOSH — *Heat Stress and Workers***. https://www.cdc.gov/niosh/topics/heatstress/ — named
    heat illnesses: heat stroke, heat exhaustion, rhabdomyolysis, cramps, rash. **[V]**
14. **NOAA / National Weather Service — *Heat Cramps, Exhaustion, Stroke***.
    https://www.weather.gov/safety/heat-illness — the full symptom table and first aid for all three
    stages; body temperature **above 103 °F**; "Call 911… Delay can be fatal"; "Do NOT give fluids" in
    the stroke case. **[V]**
15. **Ready.gov — *Power Outages***. https://www.ready.gov/power-outages — generators outdoors only,
    away from windows; do not use a gas stove or oven to heat; keep fridges and freezers closed;
    alternate plans for refrigerated medicines and power-dependent devices; community heating and
    cooling locations. **[V]**
16. **NFPA 30 (*Flammable and Combustible Liquids Code*), NFPA 30A (*Code for Motor Fuel Dispensing
    Facilities and Repair Garages*) and NFPA 70 (*National Electrical Code*)** — **paywalled, not
    retrieved.** Named in this program only to identify the standards that govern residential fuel
    storage and electrical work. **No figure is quoted from them anywhere in the book. [U]**

## 4. Sanitation and hygiene

17. **CDC — *Guidelines for Personal Hygiene During an Emergency***.
    https://www.cdc.gov/water-emergency/safety/guidelines-for-personal-hygiene-during-an-emergency.html
    — 20-second handwashing; handwashing during a boil-water advisory; a temporary handwashing station
    built from a large water jug; sanitiser at 60% alcohol or more; wound cleaning and infection red
    flags; diaper-change risk. **[V]**
18. **CDC — *What You Can Do to Prevent Diarrheal Illness After a Disaster***.
    https://www.cdc.gov/water-emergency/safety/index.html — handwashing, safe water, clean food-prep
    surfaces, flood-water hygiene, oral rehydration salts, and "visit the nearest health facility".
    **[V]**
19. **CDC — *About Global Water, Sanitation, and Hygiene (WASH)***.
    https://www.cdc.gov/global-water-sanitation-hygiene/about/index.html — retrieved, and it contains
    **no** emergency-latrine construction guidance. Recorded here so that the absence is documented.
    **[U]**

## 5. Medicine

20. **U.S. FDA — *Don't Be Tempted to Use Expired Medicines***.
    https://www.fda.gov/drugs/special-features/dont-be-tempted-use-expired-medicines — expired products
    may be less effective or risky; chemical change; bacterial growth risk; storage to preserve shelf
    life. **[V]** on the principle; per-category shelf lives were **not** retrieved (**[U]**).
21. **WHO — *Oral rehydration salts* (publication page)**.
    https://www.who.int/publications/i/item/oral-rehydration-salts — "In most cases, death is caused by
    dehydration." **[V]**
22. **WHO / UNICEF — *Oral Rehydration Salts: Production of the New ORS* (WHO/FCH/CAH/06.1)** — full
    per-litre grams, per-sachet weights, mmol/L, 245 mOsm/L, packet instructions, 24-hour discard, and
    the prevention-versus-treatment distinction. Item page:
    https://www.who.int/publications/i/item/WHO-FCH-CAH-06.1 · PDF:
    https://iris.who.int/server/api/core/bitstreams/e52f1746-cf33-4a63-9f97-4c0bfaaeb230/content
    **[V] on the sachet; [U] on any household salt/sugar ratio — the program prints none and says why.**
23. **NCCIH (NIH) — *Ginger: Usefulness and Safety***. https://www.nccih.nih.gov/health/ginger —
    evidence quality; pregnancy nausea; motion sickness mostly negative; menstrual cramps; knee
    osteoarthritis poor quality; side effects. **[V]**
24. **NCCIH — *Chamomile: Usefulness and Safety***. https://www.nccih.nih.gov/health/chamomile — "not
    produced sufficient reliable evidence to rate clinical usefulness"; safety and anaphylaxis caution.
    **[V]**
25. **NCCIH — *Peppermint Oil: Usefulness and Safety***. https://www.nccih.nih.gov/health/peppermint-oil
    — peppermint leaf: not enough evidence; enteric-coated oil for IBS: small research plus a 2021 ACG
    guideline recommendation. **[V]**
26. **NCCIH — *Colloidal Silver***. https://www.nccih.nih.gov/health/colloidal-silver — serious side
    effects, argyria; nasal-spray studies showed no meaningful improvement. **[V]**
27. **CDC — *Potassium Iodide (KI)***.
    https://www.cdc.gov/radiation-emergencies/treatment/potassium-iodide.html — only on official
    instruction; only for people under 40 and for pregnant or breastfeeding women; protects only the
    thyroid, and only against radioactive iodine; never use table salt; FDA-approved products only.
    **[V]**
28. **CDC — *Botulism Prevention*** (infant botulism and honey under 12 months).
    https://www.cdc.gov/botulism/prevention/index.html — "honey is not safe for infants"; "Do not feed
    honey to a child who is younger than 1 year old"; the honey-pacifier warning. **[V]**

## 6. Nutrition and calorie figures

29. **USDA & HHS — *Dietary Guidelines for Americans, 2020–2025***, Appendix 2, Tables A2-1, A2-2 and
    A2-3 — calorie needs by age, sex and activity level; the sedentary definition; pregnancy and
    lactation deltas; toddlers 12–23 months. PDF:
    https://www.dietaryguidelines.gov/sites/default/files/2021-03/Dietary_Guidelines_for_Americans_2020-2025.pdf
    **[V]** — this is the source of the program's 2,000 kcal/person/day planning figure and the stated
    reasoning behind it.

## 7. Security, mobility and training

30. **Ready.gov — *Community Emergency Response Team (CERT)***. https://www.ready.gov/cert — CERT
    educates volunteers in basic disaster response skills within a nationwide approach responders can
    rely on. **[V]**
31. **Ready.gov — *Evacuation***. https://www.ready.gov/evacuation — go-bag; on-foot and public-transport
    go-bag; car kit; alternate routes; the route may be on foot; shelters and service animals. **[V]**
32. **Ready.gov — *People with Disabilities***. https://www.ready.gov/disability — accessible-transport
    planning, voluntary needs registries, power-dependent medical equipment, assistive-technology
    evacuation, communication cards, service-animal planning. **[V]**
33. **FEMA NDEMU Independent Study — IS-317.A, *Introduction to Community Emergency Response Team
    (CERTs)***. https://training.fema.gov/is/courseoverview.aspx?code=IS-317 — confirmed live, title
    captured. **[V]**
34. **FEMA NDEMU Independent Study — IS-22, *Community Preparedness: Implementing Simple Activities for
    Everyone***. https://training.fema.gov/is/courseoverview.aspx?code=IS-22 — confirmed live. **[V]**
35. **FEMA NDEMU Independent Study — IS-315**.
    https://training.fema.gov/is/courseoverview.aspx?code=IS-315 — page reached; course title not
    captured, so no title is printed in the program. **[U]**

## 8. Fuel and flammable liquids

**The fuel chapter (doc 11) is written from CDC's carbon-monoxide guidance plus the physical properties
of the fuels. It carries no gallon figure, no shelf life, no clearance distance, no container standard
number and no specification number, because none of those could be verified from a free source.**

36. **CDC — *Carbon Monoxide (CO) Poisoning Basics*** — see entry 11. This is the source for the only
    two fuel figures printed anywhere in the program: the generator distance (more than **20 feet**
    from windows, doors and vents) and the never-indoors rule (never indoors or in a garage, even with
    the doors and windows open), plus the prohibition on camp stoves, flameless chemical heaters and gas
    ovens used for heat. **[V]**
37. **NFPA 30 / NFPA 30A** — see entry 16. **Paywalled and not retrieved.** The consequence is printed
    in doc 11 §11.7.1: no gallon figure appears, and the reader is sent to their fire marshal's
    non-emergency line and then to their landlord.
38. **Not retrieved, and therefore not cited:** the fuel-container standards commonly referenced for
    portable containers (child resistance and the UL family), the kerosene heater-fuel specification,
    and any CPSC or NFPA page stating a space-heater clearance. The CPSC safety-education paths tried
    returned "Page not found" on 2026-10-30; the site itself was up. **No standard number and no
    clearance distance is printed anywhere in this program. [U]**

## 9. Sourcing, budget and unit cost

**There is no citation here, and that is the honest entry.** No consumer-finance or university
Extension cost-comparison study was retrieved for this program. Doc 11 §11.2 is therefore labelled
throughout as **general guidance, not sourced fact**, and it prints **no price**. The unit-cost method
in §11.5 is arithmetic the reader performs on their own receipt, not a claim about what anything costs.

39. **Not retrieved, and not quoted:** the USDA Food Plans (Thrifty and Low-Cost). `fns.usda.gov`
    returned "Access Denied" to both the browser and direct requests on 2026-10-30. **No Food Plan cost
    or quantity is printed anywhere in this program. [U]**

---

## 10. Sources deliberately not used

Recorded so that a reader does not wonder why an obvious name is missing:

- **American Red Cross** — every page attempted returned "Access Denied" on 2026-10-30. No Red Cross
  course, page or figure is cited anywhere in this program.
- **FEMA P-320 (safe rooms)** — not retrieved. No safe-room specification appears.
- **CDC burns guidance (`cdc.gov/burns`)** — returned "Page Not Found". Burn care is limited to general
  first aid labelled as such, and the program does not cite a source for it.
- **Sphere Standards, Minnesota Department of Health, WEDC technical notes, `rehydrate.org`** — blocked
  (403, 404 or a bot challenge). No emergency-latrine construction method, no waste volume per person
  per day, and no disposal rule is printed; the program says the household must ask its local health
  department.
- **OSHA (`osha.gov`)** — blocked by the CDN. Nothing in the program depends on an OSHA citation.

---

## 11. What remains unverified, and what the program prints instead

| Topic | Status | What the book does |
|---|---|---|
| Residential fuel-storage limits (gasoline, propane) | **Open — paywalled** | No figure. Fire marshal, then landlord, then a dated written answer (doc 11 §11.7.1). |
| Fuel shelf lives, with or without stabiliser | **Open** | No figure. Rotation discipline and the mechanism of degradation (doc 11 §11.8, §11.9, §11.11). |
| Fuel-container standards; kerosene specification | **Open** | No number. "A container sold for fuel, cap and spout intact"; "kerosene sold for the purpose" (doc 11 §11.8, §11.9). |
| Space-heater clearances; propane limits in a dwelling | **Open** | No distance. The appliance's own label and manual, or do not run it (doc 11 §11.9). |
| CO ppm thresholds and exposure tables | **Deliberately not printed** | "The alarm sounds → everyone outside → call from outside" (doc 11 §11.13). |
| Household oral-rehydration salt/sugar ratio | **Open — refused** | Sachets only. No ratio is printed, and doc 06 says why. |
| Per-category medicine shelf life; the FDA shelf-life-extension programme | **Open** | "Check the expiry date, rotate, store cool and dry per the label." |
| Burn care detail | **Open** | General first aid only, labelled as such. |
| Emergency-toilet construction; waste volume; disposal legality | **Open** | No method, no volume, no rule. Local health department. |
| Dishwashing and laundry ratios; menstrual and diaper management | **Open** | No ratios, no methods invented. |
| Retailer cost comparisons; USDA Food Plans | **Open — no study / blocked** | General guidance only, with "check locally" on every line and no prices. |
| Saline nasal rinse, steam, willow bark | **Open** | Presented as folklore, unrated, never as a treatment. |

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
