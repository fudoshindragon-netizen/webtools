# NOBODY RUNS — The 90-Day Urban Family Preparedness Program

## Document 11 — SOURCING, BUDGET AND FUEL

**Version 1.0 · Errata date: 2026-11-02 · Written for households in the United States**

Two chapters share this document, and they look unrelated until you have done both.

The first is **money**. Not how to spend more of it — how to stop paying twice. The household that
fills a spare-room shelf with military-surplus kit in one weekend has usually bought a fraction of
the calories, a fraction of the water capacity and none of the rotation discipline that a hundred
dollars spent properly would have bought. This chapter is the store map, the three budget phases,
and one piece of arithmetic — cost per unit of the thing you actually need — that turns every later
shopping trip into a measurement instead of a guess.

The second is **fuel**, and it is here because fuel is where a preparedness purchase turns into a
fire that kills the neighbours. This document prints **no gallon figure, no clearance distance, no
kerosene grade specification and no shelf-life in months**, and §11.7 explains exactly why. What it
prints instead is the one default that protects an apartment household, the two phone calls that
replace a number, and the CDC's own two sentences about generators, which are the only fuel figures
in this program that a free public source actually states.

It closes with module **`FUE-1`**, which is a **10 out of 10 written check with no partial pass** —
the second of the program's two, alongside `MED-5`.

> **The sourcing rule.** This chapter contains **no price presented as a fact**. Prices move weekly
> and differ by postcode, and a stale price printed as current is a lie told to somebody who is
> about to make a decision with it. What this chapter teaches is the **method** — cost per 1,000
> calories, per gallon of water capacity, per hour of light, per person-day — so that the number you
> act on is the one on the shelf in front of you. Where a figure appears at all it is either
> arithmetic on inputs marked *illustrative*, or a **band** with a **date** attached.

---

## 11.1 The thesis: consumables at unit cost, rotated — not gear

Nearly every preparedness list you can buy is a list of **things** — a knife, a radio, a filter, a bag.
Things are satisfying to buy, they photograph well, and they are the smallest part of what carries a
household through ninety days in a flat. What carries you is **consumables**: calories, water capacity,
bleach, batteries, soap, medication, the fuel for whatever cooks. Consumables have three properties
gear does not:

1. **They are used up, so they must be replaced, so they must be rotated.** Rotation is the skill. A
   stock you have not touched in a year is not a stock; it is a rumour with a receipt.
2. **They are bought repeatedly, so the unit price compounds.** A ten per cent better unit price on the
   food that is ninety per cent of your spend beats any single purchase in this program.
3. **They are cheap to start and cheap to abandon.** A household that discovers in week three that it
   cannot do this has spent a hundred dollars, not eight hundred.

So the thesis is deliberately unglamorous:

> **The cheapest path to ready is not surplus gear. It is consumables bought at unit cost, stored in
> the format your flat can actually hold, and rotated on a date.**

Three consequences follow. **Storage space is the binding constraint, not money** — in an apartment the
limit on the 90-day store is the cupboard, the top of the wardrobe, the space under the bed, not what
you can afford, and a 25 lb sack is the cheapest calories per pound available and the wrong purchase in
a flat with a humidity problem (§11.5.5). **The unit cost is the only number that survives the next
shopping trip**, because the shelf price is gone next month. And **the household's own dated record
beats any printed band** — which is why every phase in §11.4 has a spending cap rather than a price
list, and every line has a blank for what you actually paid and when. That record is the household's
real budget document, and it is the reason this chapter can be honest: the method does not depend on
knowing what your rice costs.

---

## 11.2 The store map — what each place is genuinely best for, and its trap

> **Labelled plainly: this section is general guidance, not sourced fact.** No consumer-finance or
> university-Extension cost-comparison study was retrieved for this program, and the brief says so in
> as many words. Local prices in this category commonly swing by more than fifty per cent between
> retailers in the same town. Treat every line as **"where to look first"**, with **"check locally"**
> attached, and print no price from it.

The point of the map is not that one store is cheap. It is that **each type of store is cheap for a
different thing, and expensive for everything else.** A household that shops one store for the whole
program pays a premium on most of the list and does not notice, because the premium is invisible
until it is measured per unit.

### 11.2.1 The map

| Store | Genuinely best for | Its trap |
|---|---|---|
| **Dollar / discount** | Batteries in small packs, matches, plastic sheeting, zip ties, duct tape, cleaning cloths, basic first-aid consumables. Low outlay on small quantities when you will not finish a multi-pack. | **Small packages are usually the worst unit cost in the store.** Cheapest per item, expensive per unit. Do not build a 90-day pantry here. |
| **Big-box / warehouse club** | Staples in bulk — rice, flour, oats, sugar, salt, oil, canned goods by the case, water by the pallet — plus the pharmacy counter. | A membership fee is a real cost to divide across what you actually buy, and **package sizes routinely exceed apartment storage**. The saving evaporates if half of it spoils. |
| **Discount tool / hardware** | Hand tools, tarps, rope, gloves, buckets, hose clamps, plumbing fittings, extension cords, propane fittings — anything that need not be excellent. | **The quality floor is real. Never cheap out on anything electrical or pressure-rated.** And the cheapest generator is false economy. |
| **Independent hardware** | Fasteners, gaskets, lamp oil and wicks, mantles, kerosene-heater parts, fuel-container spouts — **and advice**. | Higher prices on commodity goods. Use it for what you cannot identify anywhere else. |
| **Craft / fabric** | Sewing kits and thread, cotton fabric, beeswax, storage bins — and **children's no-power activity supplies**. | List price is high and **the coupon is the real price**. Many are closed one day a week (Sunday is common), which matters if the outage starts on a Saturday night. |
| **Thrift / estate sale** | Pressure canners and water-bath canners, cast iron, hand-crank tools, wool blankets, thermoses, sturdy furniture, books. **The best value in preparedness, and the channel most households never visit.** | **Inspect a pressure canner for gasket, gauge and rust** — a bad canner is a pressure vessel that fails. Skip any electrical item with a damaged cord. |
| **Restaurant supply** | Food-grade buckets with lids, hotel pans, cambros, commercial utensils, sheet pans, bulk spices — containers **in sizes that actually hold 25 lb of grain**. | Bulk sizes, some items commercial-only, not everything retail-packaged. Go with a list and a tape measure. |
| **Pharmacy counter** | The OTC core list in doc 06, and a prescription-refill conversation. Not a savings category — a **continuity** category (`MED-2`). | Buying a large bottle that expires before it is used, or a "family pack" only one member takes. **Check the expiry on the package, not the shelf label.** |
| **Online / subscription** | The odd item no local store carries, bulk shelf-stable food with postage included, replacement parts. | **Postage is part of the unit cost**, and a two-week delivery is useless in the week you needed it. Do not plan around delivery arriving during the event. |

### 11.2.2 The four traps worth a paragraph each

**Bleach.** Doc 02's disinfection dose depends on the **concentration printed on the bottle**, and
discount-store bleach is frequently weaker, differently labelled, scented, or has additives. Buy bleach
whose label states its percentage, and record that percentage on the bottle and in the water log. **A
weaker bleach dosed as if it were full strength is an under-dose you cannot see.**

**Batteries.** Cheaper cells have lower capacity and shorter shelf life, which matters in the one device
you are depending on. For smoke and CO alarms, follow the manufacturer's recommendation — do not
"upgrade" an alarm to a discount cell.

**The cheapest generator.** It is louder, thirstier, harder to start cold, and — the part that matters —
**more likely to be running in the wrong place at 2 a.m. because it would not start outdoors.**
11.13 is the placement rule, and a generator you cannot start is a generator somebody brings inside.

**Storage space.** Take the internal dimensions of your cupboard with you, in writing. A household that
arrives home with a case that does not fit has bought storage it does not own. Buy the case, decant it
into food-grade containers the day you get home, and date them.

**And the line households skip: children's no-power activity supplies.** In a three-day outage with no
screens, what degrades a household's decisions is not hunger — it is four bored children in a dark flat
with two frightened adults. Paper, pencils, card, glue, string, a deck of cards, a puzzle, a book of
things to make: it costs very little, takes no power, and buys the adults the attention the decisions
need. Doc 04 §4.1 is the warm room; this is the other half of living in it.

## 11.3 Why military surplus usually loses

Surplus is where a certain kind of household starts: the gear looks serious, it is genuinely durable,
and it is priced like a bargain. Some of it **is** a bargain. Most of it, for this program's household,
is a way of spending the budget on the wrong axis.

**Where surplus genuinely wins — and buy it:**

- **Wool and cold-weather layers.** Surplus wool is often better than new synthetic at the price, and
  wool still insulates when damp, which is the property that matters in a flat with no heat (doc 04
  §4.5).
- **Canvas** — tarps, bags, covers.
- **Metal ammo cans**, for one specific job: **dry storage** of items that must not get damp.
- **Mess kits and metal cups** — genuinely useful, genuinely cheap, and they do not care about heat.
- **Water bladders and sturdy packs**, if the household will actually carry them.
- **Entrenching tools** — a folding shovel is worth having for a car kit and for nothing else in an
  apartment.

That is a short list, and it is worth noticing how short it is.

**Where surplus loses, and why it loses on this program specifically:**

1. **Stock reliability.** Surplus is whatever was surplus *this month*. The household that builds a
   plan around one lot of surplus boots, one lot of surplus blankets, one size of surplus can cannot
   replace any of it in six months, and cannot tell a second adult "buy another of these". A plan
   that depends on a lucky lot is not a plan.
2. **Price per calorie.** Surplus has no food in it. It has no water capacity in it. The two things
   that are ninety per cent of a 90-day household's actual need are the two things surplus does not
   sell, and every dollar in a surplus parka is a dollar not in the pantry.
3. **Weight and bulk.** Military kit is designed to be carried by a fit adult with a vehicle behind
   him, and to be *heavy* — because heavy means durable in the field. In an apartment with a slow
   mover, weight is not a feature; it is the thing that stops the household moving at all, and it is
   the thing that fills the cupboard the food needed.
4. **It makes the household conspicuous.** This is the argument households resist and the one that
   matters most in a city. Olive-drab kit on a balcony, a surplus crate in a hallway, a jerry can by
   the door: in a normal week it is a hobby, and in a bad week it is an advertisement that this flat
   has stores. Doc 07's whole security position is **layered, quiet, and unremarkable** — surplus is
   the opposite of unremarkable, and no amount of it compensates for the fact that a neighbour who
   has never spoken to you now knows what you have.
5. **The accessories are where the money goes.** Surplus is priced to get you into a system, and the
   system's parts — pouches, mounts, straps, adapters, the correct-size anything — are priced as
   accessories. A household can spend a Phase 2 budget on pouches for a pack it did not need.
6. **No support, no warranty, no manual.** Often literally no manual. For anything with a moving part
   or a seal, that is a purchase you cannot maintain, and an item you cannot maintain is an item you
   will find broken on the day you need it.
7. **Chemical and electrical unknowns.** Surplus electrical gear, surplus heaters, surplus stoves and
   surplus fuel containers have unknown history. Doc 11's fuel rules and doc 04's CO rules both
   assume an appliance with a label and a manual. An unlabelled surplus heater is an appliance whose
   clearance, output and venting nobody can tell you, and §11.9 is a chapter about exactly why that
   is not a risk worth taking to save money.

**The rule this chapter draws:**

> **Buy surplus for wool, canvas and dry storage. Buy nothing else there. And never buy a surplus
> appliance that burns fuel.**

---

## 11.4 The three budget phases

**Read this before the lists.** The three phases are **cumulative spending caps**, not price lists.
Phase 1 is about a hundred dollars, Phase 2 brings the household to about three hundred dollars in
total, Phase 3 brings it to about seven hundred. Those are the household's own caps: the household
decides how much it can spend, and the phase tells it **what to buy first with that money**.

Two rules govern the order, and they are not negotiable:

1. **Life safety before comfort, and both before capability.** Alarms, water treatment and light come
   before any tool. A household with a filter and no CO alarm has bought the wrong thing first.
2. **The cheapest thing that removes a hazard, before the best thing that improves a day.** A ten-
   dollar battery light and a twenty-dollar alarm between them do more for a flat than a hundred
   dollars of anything else in this document.

Every line below has three blanks: **what you paid**, **where**, and **the date**. Fill them in. That
is the household's budget record, it is the only price data this program trusts, and it is what makes
the next trip measurable. `10 §10.8` is the inventory sheet those blanks belong to.

> **A note on the word "about".** A cap of "about a hundred dollars" is a target, not a receipt. If
> the household's local prices put Phase 1 at a hundred and thirty, that is not a failure of the
> plan; it is the plan meeting a real shelf. **Buy the list in order and stop when the money stops.**
> The phases are ordered so that stopping anywhere still leaves the household safer than it was.

### 11.4.1 Phase 1 — about $100, weeks 0 to 1: the hazards that kill first

This phase buys **nothing you will enjoy**. It buys the four things that turn a bad week into a
survivable one, in this order.

| # | Line | Why it is first | Buy / record |
|---|---|---|---|
| 1 | **CO alarm, battery or battery-backup, for each sleeping area** | CO kills sleeping people before they have symptoms (CDC). This is the program's first purchase and `CO-1` is a prerequisite for every flame in the rest of the book. | Qty ___ · paid ___ · where ___ · date ___ |
| 2 | **Water containers, food-grade, with lids** | Doc 02's planning figure is the household's own; the containers are the one-time cost. Two smaller containers beat one you cannot lift. | gal of capacity ___ · paid ___ · date ___ |
| 3 | **Disinfecting bleach, unscented, percentage on the label** | Doc 02's dosing needs the concentration. Record the percentage on the bottle. | % ___ · paid ___ · date ___ |
| 4 | **LED lights and batteries** — two per person plus one head torch | No candles, ever (doc 04 §4.2). Light is what stops a household making decisions in the dark. | count ___ · paid ___ · date ___ |
| 5 | **First-aid consumables to close the gaps in the existing kit** | Doc 05's kit list, minus whatever is already in the cupboard. Buy the gaps, not a new kit. | paid ___ · date ___ |
| 6 | **A week of no-cook food** — Layer 1 only, needs no cooking, no water, no fridge | If the power goes tonight, this is dinner. Doc 03 §3.4 and `10 §10.1.3`. | person-days ___ · paid ___ · date ___ |
| 7 | **Bucket, liners, cover material, soap** | The sanitation floor, doc 04 §4.6. | paid ___ · date ___ |

**What Phase 1 does not buy:** a generator, a filter, a stove, a knife, a pack, a radio, or anything
in a camouflage pattern. Every one of those is either in a later phase or in no phase at all.

**Phase 1's test.** At the end of Phase 1 the household can answer four questions without looking: where
the alarms are, how much water it holds and where, what is for dinner with no power, and where the
bucket is. If it cannot, the money was spent out of order.

### 11.4.2 Phase 2 — about $300 cumulative, weeks 2 to 4: calories, water, and the second alarm

Phase 2 is where the pantry starts and where the household's money starts compounding, because this
is the phase in which **bulk food at unit cost** enters the plan.

| # | Line | Why now | Buy / record |
|---|---|---|---|
| 8 | **Staples in bulk to build calories** — rice, oats, flour, oil, sugar, salt, canned goods by the case | This is the largest line in the whole program and the one where unit cost matters most (§11.5.1). Buy the format that fits the cupboard. | kcal bought ___ · paid ___ · $/1,000 kcal ___ · date ___ |
| 9 | **A second water container, and the means to treat water** — filter or the supplies for boiling and bleach dosing | Doc 02's store → harvest → treat → ration. Capacity without treatment is half a plan. | gal ___ · paid ___ · date ___ |
| 10 | **A second CO alarm and a smoke alarm if the flat has none** | Redundancy is the point of an alarm, not a luxury. | paid ___ · date ___ |
| 11 | **Fire extinguisher, and the `FIR-1` demonstration** | Locate it, know PASS, and know where the nearest exit is from the kitchen. | paid ___ · date ___ |
| 12 | **Handwashing station supplies** — jug with a spout, soap, paper towels, sanitizer at 60% alcohol or more | Doc 04 §4.6.2–4.6.3; the 20-second standard needs a station, not good intentions. | paid ___ · date ___ |
| 13 | **Tarps, tape, sheeting, zip ties, rope** | The warm room (doc 04 §4.1) and the seal-a-room (doc 04 §4.4.3) both need materials, and both need them before the night they are used. | paid ___ · date ___ |
| 14 | **Children's no-power activity supplies** | §11.2.2. Not a comfort item: it is the adults' attention, bought cheaply. | paid ___ · date ___ |
| 15 | **Medication and device stock, per `MED-1`/`MED-2`** | Doc 06. Buy the refill schedule, not a hoard; check expiry on the package. | days on hand ___ · paid ___ · date ___ |

**Phase 2's test.** The household can feed itself for **two weeks** from the cupboard without a shop,
treat its own water, wash hands at a station, and light two rooms. `FOD-1` and `WTR-1` are the
modules that close here.

### 11.4.3 Phase 3 — about $700 cumulative, weeks 5 to 8: the ninety days, and the durables

Phase 3 is where the store becomes a **90-day** store and where the durables that last a decade get
bought — from the channels in §11.2.6, at prices a new-goods store cannot match.

| # | Line | Why now | Buy / record |
|---|---|---|---|
| 16 | **Top the pantry up to the household's 90-day calorie target** | Doc 03's per-person table, times the household, times ninety. This is arithmetic, not a guess (§11.5.1). | target kcal ___ · bought ___ · $/person-day ___ |
| 17 | **Rotation containers** — food-grade buckets and lids, or the containers that fit the shelves | Decant on the day you get home and date every container. | paid ___ · date ___ |
| 18 | **Wool and cold-weather layers for every member** — thrift (§11.2.1) and surplus (§11.3) | Doc 04 §4.5, and `CLO-1`'s five-minute standard. Buy for the slowest member first. | paid ___ · date ___ |
| 19 | **Tools that earn their place** — can opener (manual), wrench for the utility shut-off, work gloves, a hand-crank or battery radio | Doc 00 §0.4 and the first-sixty-minutes card. | paid ___ · date ___ |
| 20 | **A battery or hand-crank radio, and spare batteries** | Information is a supply. | paid ___ · date ___ |
| 21 | **Documents and cash** — copies, a small cash reserve in mixed denominations | `BAS-3`, `BAS-4`. Card readers fail with the power. | paid ___ · date ___ |
| 22 | **Sewing kit and repair supplies** | The cheapest way to make durables last another decade. | paid ___ · date ___ |
| 23 | **Fuel — only if §11.7's two phone calls both come back yes** | Otherwise this line is **struck**, and the money goes to line 16. See §11.7.1. | permission: ___ / ___ · paid ___ · date ___ |

**Phase 3's test.** The household can state its calorie target and its water target, name where each
is stored, and show a rotation date on every container. That is `FOD-1` at CAN TEACH IT, and the
rotation discipline in §11.6.

### 11.4.4 What no phase buys, at any budget

- **A generator, unless the household has somewhere outdoors, more than twenty feet from windows,
  doors and vents, to run it** (§11.13). Without that place, a generator is a CO hazard with a receipt.
- **A weapon, or anything that only makes sense as one.** Doc 07 and the weapons statement in the
  README.
- **Anything that burns fuel and has no label, no manual and no clearance printed on it** (§11.3).
- **A subscription or a course that promises readiness.** This program is the course.
- **Bottled water as the *primary* store.** The container is a one-time cost and the water is not;
  §11.5.2 shows why bottled water loses to a reusable container after roughly fifteen gallons, which
  is under a week for a family of four.

---

## 11.5 The unit-cost method — the only purchasing skill that matters

**The problem, in one line:** a 25 lb bag of rice and a 2 lb bag cannot be compared by price, and
"cheapest per bag" is how households buy badly.

**The fix:** convert every purchase to a **cost per unit of the thing you actually need** — calories,
usable water capacity, hours of light, person-days. Four metrics, four formulas, and one discipline.

**The arithmetic, in order:**

1. **Total price ÷ units in the package = cost per unit.** Read the **net weight or count off the
   package**, not off the shelf label. Shelf labels are frequently wrong, and they are the number the
   store wants you to compare.
2. **Units per person-day × cost per unit = cost per person-day.** This is the number that answers
   "can we do ninety days?".
3. **Compare only like with like.** Cost per 1,000 kcal cannot be compared to cost per pound. Cost
   per hour of light cannot be compared to cost per battery. Mixing the two is how a household
   convinces itself it saved money.

### 11.5.1 Cost per 1,000 calories

**Formula:** `(price ÷ kcal in the package) × 1,000 = cost per 1,000 kcal`

**Worked example — arithmetic only. The inputs below are illustrative and are not quoted prices.**

> A 10 lb bag costs **$12**, and the label states **1,600 kcal per pound**.
>
> → kcal in the bag = 10 × 1,600 = **16,000 kcal**
> → $12 ÷ 16,000 = **$0.00075 per kcal** → × 1,000 = **$0.75 per 1,000 kcal**
>
> The same food in a **2 lb bag at $4**: 2 × 1,600 = 3,200 kcal → $4 ÷ 3,200 = **$1.25 per 1,000 kcal**.
>
> **The 10 lb bag is forty per cent cheaper per calorie, and it costs three times as much at the till.**

That single result is the whole lesson. It is also why the household's real constraint is **storage
space**, not price: the cheaper purchase is the one you may not have room to keep, and §11.5.5 gives
the rule for that case.

**Why this is the right metric for food.** Doc 03 establishes the household's per-person calorie
figure. Multiply the number of people by the number of days to get the household's target in
thousands of kcal, then multiply by the cost per 1,000 kcal:

> **target (in thousands of kcal) × cost per 1,000 kcal = the food cost of the whole store.**

For one adult over ninety days at the program's planning figure of 2,000 kcal/day that is 180,000
kcal — **180 × cost per 1,000 kcal**, with no further conversion. That is the number to write on the
pantry card.

**A band, not a price.** When the household has measured this two or three times, it will have its own
band: *"in our town, in this season, staples run us between X and Y per 1,000 kcal, and the cheap end
is the big bag at the warehouse club."* That sentence — with the month in it — is worth more than any
figure printed here, because it is the household's own observation and it is dated.

### 11.5.2 Cost per gallon of water capacity

**Formula:** `(container price + first fill/treatment cost) ÷ usable gallons = cost per gallon`

**Two things people forget, and both change the answer:**

1. **A "5-gallon" container does not hold five *usable* gallons** if you cannot lift it. A household
   with an elderly member has to divide the container before it divides the price: four 2-gallon
   containers that one person can carry beat one 8-gallon container that nobody can.
2. **The container is a one-time cost; the water is not.** Bottled water's per-gallon cost **recurs at
   every rotation**, and doc 02's rotation cycle means it recurs several times a year. A reusable
   container beats bottled water after roughly **fifteen gallons** — which is **under a week** for a
   family of four at the program's planning rate. That is the calculation that ends the bottled-water
   argument, and it is arithmetic, not opinion.

### 11.5.3 Cost per hour of light

**Formula:** `(device + batteries/charging) ÷ hours of usable light = cost per hour`

**The trap:** comparing **lumens to price** instead of **hours to price**. A cheap torch whose battery
dies in four hours is more expensive per hour than a good one with a rechargeable cell, and it fails
in the second hour of the night you need it.

**Count the consumable, not the torch.** Two rechargeable lights and a small solar or hand-crank
charger can beat a drawer of disposable-battery lights over a single long outage — but only if the
household actually charges them in the calm weeks. A rechargeable light that lives in a drawer
discharged is a plastic brick.

### 11.5.4 Cost per person-day of food

**Formula:** `(total food spend) ÷ (people × days covered) = cost per person-day`

**Worked example — again, arithmetic on illustrative inputs:** a household spends **$900** on a food
store that comes to **648,000 kcal**. At the program's worked household of four people, that store is
ninety days.
 4 × 90 = **360 person-days** → $900 ÷ 360 = **$2.50 per person-day**.

**Track this number across every trip.** It is the only figure that stays comparable when the basket
changes, and it answers the one question a household actually asks — *"can we afford 180 days instead
of 90?"* — without rebuilding the list: **double the person-days, double the cost.** At $2.50 a
person-day, a fourth person for another ninety days is 90 × $2.50, and now the household is doing
arithmetic instead of guessing.

### 11.5.5 The comparison discipline

- **Never compare across units.** Price per pound, per calorie and per person-day are three different
  questions with three different answers.
- **Write the unit cost on the package with a marker when you get it home.** The shelf price is gone
  next month. The unit cost written on the bag is what tells you whether the next trip was a good deal
  — and it is what a second adult can read without you.
- **Buy the format that matches your storage, then the cheapest per unit within it.** A 50 lb sack is
  the cheapest per calorie and the worst purchase in a flat with a humidity problem and no room to
  decant it. The correct answer there is the largest bag that fits the container you own, decanted the
  day it arrives, dated, and rotated.
- **Include the cost of getting it home.** Postage, a delivery fee, a membership, a taxi: all of it
  belongs in the numerator before you divide.

---

## 11.6 What to store, and the rotation that makes it a store

Doc 03 owns the calorie arithmetic; this section owns the **physical discipline**, which is where stores
quietly fail. Three layers, not interchangeable:

- **Layer 1 — no-cook, no-water, no-fridge.** Ready-to-eat items that need nothing. This covers the
  first 72 hours, it is eaten first, and it is the only layer that must be complete before any other
  layer is started.
- **Layer 2 — cooked from store.** The staples: rice, oats, flour, oil, pulses, canned goods. Where the
  calories and the unit-cost work live — and worthless without a way to cook (§11.7) or a no-fuel plan
  (doc 03 §3.8).
- **Layer 3 — the 90-day extension.** The same staples at volume, decanted, dated, rotated. This layer
  exists only if Phase 3 happened.

**Four rules that keep a store from becoming a rumour:**

1. **Date everything, on the container, the day it arrives.** A stock without a date is a rumour. If you
   decant, date the new container before you throw the old bag away.
2. **Rotate by eating.** The store is part of normal cooking, not a museum: oldest first, and the week's
   shopping goes behind the existing stock.
3. **Store cool, dark, dry, and off the floor.** Heat, light, damp and pests are the four ways a store
   dies. In a flat the worst places are the top of a boiler cupboard, a bathroom, and a sunny balcony.
4. **Count it quarterly, with a pen.** `10 §10.8` is the sheet. An uncounted store is always smaller
   than the household believes, and always at the worst possible moment.

**The rotation ladder for consumables:** water (doc 02's cycle) → food (oldest first) → bleach (check
the date; old bleach is weaker and doc 02's dose assumes its stated strength) → batteries (dated, used
in the least critical device first) → medication (expiry on the package, doc 06) → fuel (§11.12 — the
one ladder this chapter tells most households **not** to climb).

---

## 11.7 Fuel — the honest position, and the default

### 11.7.1 No gallon figure appears in this document, and that is deliberate

There is a legal maximum on how much gasoline a household may keep, it differs by state and by
building, and it is enforced by your **local fire marshal** — not by a website, and not by this book.

**This document prints no gallon figure for fuel storage, and here is the whole reason.** The
standards that govern residential fuel storage — **NFPA 30** (*Flammable and Combustible Liquids
Code*) and **NFPA 30A** — are **paywalled**. Their text was not read in the research behind this
program, and this program does not print a number it has not read. The figure that circulates most
widely online as "the household limit" is unverified here and is very likely **misapplied even where
the underlying number is real**: a quantity of that shape in NFPA 30 is tied to *storage cabinets,
fire areas and occupancies*, not a licence to keep it in a flat. Two further reasons it must not be
printed:

1. **It is edition-dependent.** NFPA revises on a three-to-five year cycle. A figure quoted from an
   older edition may not be the one your Authority Having Jurisdiction enforces today.
2. **The dwelling-unit case is the restrictive one.** Even where a code permits a quantity in a
   detached garage or shed, the quantity permitted **inside a dwelling unit** is typically far smaller,
   and frequently zero.

> **So the instruction is a procedure, not a number — and it is stronger than a number:**
>
> **Call your fire marshal's non-emergency line and ask what your household may store, and where.**
> Then **ask your landlord**, because many apartment and townhouse leases forbid storing gasoline or
> any flammable liquid inside the unit at all, and many municipal fire codes forbid it in multi-family
> buildings outright. **If either answer is "no", the answer is no.**

**The script, so nobody has to improvise it:**

> *"I live at [address], in a [apartment / rowhouse]. I'm not storing anything yet — I'm asking before
> I do. What does the fire code allow a household in this building to keep, and where may it be kept?
> Is there a limit on gasoline, on propane cylinders, or on kerosene heaters here?"*

Write both answers down, with the date and the name of whoever gave them, on the fuel line of
`10 §10.8`. A permission you cannot date is a permission you cannot rely on.

### 11.7.2 The default for an apartment: store no gasoline in the dwelling

Not "check your lease and see". **The default is no.**

Gasoline belongs in an **approved, listed container, outdoors or in a detached structure — never in a
living space, never in a basement, never under a stair, never in a stairwell or any common area, and
never near a water heater, furnace or pilot light.** Those are physical facts about vapour, not
regulatory claims, and they hold even where a code is silent.

In an apartment the third-party risk settles the argument. A fire that starts in a flat does not stop
at the flat: it takes the neighbours, the shared stair, and the building. That is the largest
liability anywhere in this program, and it is not a risk a household should take on to run a
generator for two days.

**And the arithmetic is unkind to the whole idea anyway.** §11.12 shows that fuel is the one store
that must be *rotated* rather than *kept*, that ethanol blends take on water and separate, and that
none of the storage lives are verified figures this program may print. A stock you cannot keep, cannot
date, and cannot legally place is not a stock. **Spend the fuel money on the alarm and the extension
cord instead** — that is the summary line of this chapter, and it is meant literally.

**Also never:** a propane cylinder indoors (including in a cupboard, a closet, a stairwell, or a
vehicle trunk in summer); an unvented kerosene heater in a flat whose lease forbids it; fuel in a milk
jug, a drink bottle, or any unlabelled container; fuel-soaked rags anywhere (spontaneous combustion);
oxygen and fuel stored together.

---

## 11.8 Gasoline

**Containers.** Use a container **sold for fuel**, with the cap and the flame-arrestor/spout it came
with. Never glass. Never a drink bottle, and never a repurposed milk jug — the failure mode is that
somebody in the household drinks it, and that is a real, recurring poisoning. **Never** store fuel in a
container that held something else, or in one whose label has gone. **Label every container in writing
with what is in it.** The child-resistant spout is a safety device, not an inconvenience: households
routinely defeat or discard them, and this document tells you not to.

*This program cites no standard number for fuel containers. The standards commonly cited were not read
in the research behind it, so no number is printed — only the rule above, which is the part that
matters at the shelf.*

**Shelf life, stabilizer, and ethanol — the mechanism, not a number.** No authoritative free source
stating a storage life for gasoline, with or without stabilizer, was retrieved for this program, so
**no month or year figure is printed.** What is true, and is chemistry rather than a citation:

- **Gasoline is a blend of hundreds of hydrocarbons and it degrades from the day it is refined.**
  Light ends evaporate; the remaining fractions oxidise into gums and varnishes that clog carburettors
  and injectors.
- **A stabilizer is an antioxidant.** It slows gum and varnish formation. It does **not** restore fuel
  that has already degraded, does **not** remove water, and does **not** stop ethanol absorbing water
  from the air.
- **Ethanol blends and phase separation.** Most U.S. pump gasoline contains ethanol, which is
  hygroscopic — it pulls moisture out of the air inside the container. Once saturated, the ethanol and
  water **separate and sink as a distinct layer**. That layer is ethanol-rich, corrosive, and will not
  burn properly; running an engine on it can destroy the engine. **Phase separation is not reversible
  by stabilizer or by shaking the can.** This is the strongest argument in the whole chapter for
  rotating fuel rather than stockpiling it.
- **The rule this program will defend without a number:** *treat stored gasoline as a rotating
  consumable, not a stockpile — date every container the day you fill it, use the oldest first, and
  never pour fuel you would not put in your own car into a generator you are depending on.*

**Vapour and ignition.** Gasoline vapour is **heavier than air** and pools at floor level, in pits, in
basements, and at the bottom of a garage; a leak at ankle height can reach an ignition source metres
away. It gives off ignitable vapour at any normal outdoor temperature. **A pilot light, a water-heater
burner, a furnace, a cigarette, a light switch, a garage-door opener, or a static spark from a nylon
jacket is enough.** Never fill a container sitting in a vehicle bed with a plastic liner, or on a
plastic surface — static accumulates and discharges at the filler neck. Never smoke, never use a
phone, never leave the nozzle unattended while filling. **A fuel smell indoors is an emergency, not a
nuisance:** ventilate, extinguish ignition sources, do not operate switches.

---

## 11.9 Kerosene

**Grade — why "heater grade" matters.** Buy **kerosene sold for the purpose**, for the heater you
actually own, and never "whatever is in the can". Lower-grade kerosene, diesel, jet fuel, or a
kerosene/gasoline mix will foul the wick, produce more soot and odour, and — the part that matters —
**can raise carbon monoxide output** in an appliance that was not designed for it. **The grade is a
combustion-safety property, not fussiness about smell.** That framing is what makes a household comply.

*This program quotes no sulphur limit and no specification number: the specification was not read in
the research behind it.*

**The blue-can convention.** Kerosene is conventionally sold and stored in a **blue** container;
gasoline in **red**; diesel in **yellow**. The convention exists because fuel containers look identical
in the dark, and because mis-fuelling a kerosene heater with gasoline has killed people. **The rule is
absolute: never put gasoline in a kerosene can, and never keep an unlabelled container.** If a
container's colour and label disagree with what is in it, empty it and mark it — do not "remember".
Kerosene is still a flammable liquid with a real flash point: **safer than gasoline, not safe.**

**Heater operation — the rules that actually kill people.** The carbon-monoxide mechanism behind these
rules is CDC's, and §11.13 quotes it.

1. **Never refuel a heater that is lit or still hot.** Fuel flashes when it hits the hot burner or the
   vapour finds the flame. Let it cool completely, refuel with ventilation, then relight.
2. **Never run a kerosene heater in a sealed room.** It consumes oxygen and produces CO and water
   vapour. It needs **a source of fresh air** — an opening to another room or a cracked window — every
   time, in every room, even in cold weather. This is the rule households break first, because the
   whole point was to keep the cold out.
3. **Never sleep in the same room as a running kerosene heater**, and never in a room with an infant
   or an elderly person who will not wake.
4. **Never move a lit heater.**
5. **Keep it clear of everything that can burn** — bedding, curtains, laundry on a drying rack,
   furniture. **This document prints no clearance distance in feet**, because no free authoritative
   source for one was retrieved and NFPA is paywalled. Instead: *the manufacturer's clearance is on the
   heater's label and in its manual — read it. If it is gone, keep the heater far enough from anything
   combustible that you would not be comfortable leaving a hot iron there.*
6. **A CO alarm is mandatory in any room with a kerosene heater** (§11.13).

**Storage life.** No authoritative free figure was retrieved, so **no year figure is printed.** Kerosene
is more storage-stable than gasoline — no light-end loss, no ethanol phase separation — but it absorbs
water and can grow microbial contamination over long periods. **Treat it as a rotating consumable on a
shorter cycle than the household expects.**

---

## 11.10 Propane

**Cylinders.** The common portable sizes are the **20 lb** exchange/refill cylinder used for grills and
the smaller **1 lb** disposable cylinders for camp stoves and small heaters. *No run-time or
capacity-to-BTU figure is printed here — no source for one was retrieved.*

A cylinder is a **pressure vessel**. Store it **upright**, valve protected, **out of the sun**, and
**never in a basement, cellar, or below-grade space** — propane is **heavier than air**, so a leak in a
basement fills it from the floor up, which is exactly where the water heater and furnace are. **Never
store a cylinder indoors, never in a vehicle trunk in summer, never near a heat source.** The legal
limit for cylinders kept in a dwelling varies by fire code and lease exactly as gasoline does, so
**ask your fire marshal** (§11.7.1) rather than trusting a number from the internet or from this book.

**The CO rule — CDC's own words.** CDC states plainly: **never use a portable gas camp stove indoors;
never heat your house with a gas oven; do not use portable flameless chemical heaters indoors; do not
cook or burn anything on a stove or fireplace that isn't vented.**

> **This program's rule, in one sentence:** an appliance designed for outdoor use — a camp stove, a
> patio heater, a turkey fryer, a portable grill, a generator — **is not an indoor appliance because it
> is cold outside.** "Outdoor-rated" means *designed to be used where the combustion products go
> outside*. Using it in a kitchen with the window open does not make it indoor-rated; it makes the room
> the combustion chamber.

**Leak checking.** **Soapy water on every joint, valve and hose connection. Bubbles mean a leak.** That
is the whole method. **Never use a flame to look for a propane leak** — you would be introducing an
ignition source into the exact place where gas is escaping. **If you smell gas:** no switches, no
flames, no phones; ventilate; shut the cylinder valve; get out; **call the fire department from
outside.**

---

## 11.11 Diesel

- **Diesel stores longer than gasoline** — far less volatile, so no light-end loss and no ethanol phase
  separation. It still degrades, absorbs water, and can grow microbial contamination ("diesel bug")
  over long storage. **No month or year figure is printed.**
- **Cold is the diesel problem, not age.** At low temperatures the wax in diesel crystallises and the
  fuel **gels**, blocking the filter. Winter-blend diesel is sold in cold markets for exactly this
  reason. A household storing summer diesel for a winter outage may have stored a fuel that will not
  flow when it is needed. **Buy winter blend if storing for winter, and store before the season, not
  during it.**
- **Stabilizer and biocide exist** and are sold for these two problems. *No efficacy claim is made
  here and no storage life is promised.*
- **Diesel is a combustible liquid, not a flammable one** — much harder to ignite than gasoline — but
  its vapour and mist are hazardous, and it is a skin and groundwater contaminant. Store it in a proper
  container, labelled, out of living space, and never in a container that ever held gasoline.

---

## 11.12 The rotation ladder

**Read this table as a set of questions to ask, not a shopping list.** Every "how much" cell is
deliberately a range or "check locally": the legal answer is local and the sensible answer is
household-specific. The middle column of most households' answer to the first row is **nothing**.

| Fuel | How much is sensible | Container | Where it may be kept | Rotation | **Never** |
|---|---|---|---|---|---|
| **Gasoline** | Enough to fill the car and run a generator for a few days — **not** a stockpile. **Legal maximum: ask your fire marshal** | Listed/approved fuel container, labelled, child-resistant spout intact | Outdoors or in a **detached** structure. **Never** in a dwelling unit, basement, or under a stair | Rotate continuously; date every can; oldest first. Stabilizer slows gum, does not stop water uptake | In a living space · in glass or a drink bottle · in a hot vehicle · near a pilot light · in a stairwell or common area · in a building whose lease forbids it |
| **Kerosene** | One heating season's use for the heater you actually own | **Blue** container, labelled, with the heater's own fuel | Cool, ventilated, away from living space; never below grade | Rotate before the season; **no printed year figure** | In a **red/gasoline** can · refuelling a hot heater · a sealed room · while sleeping |
| **Propane** | The cylinders your appliances need, plus one spare | Manufacturer cylinder, valve capped, **upright** | Outdoors, shaded, upright. **Never** in a basement or cellar. Limit in a dwelling: **ask your fire marshal** | No rotation needed; inspect hoses and regulators | Indoors · below grade · on its side · near heat · leak-checking with a flame · an outdoor appliance used indoors |
| **Diesel** | Vehicle tank plus a working reserve | Approved container, labelled | Outdoors or a detached structure; never living space | Before winter, winter blend; **no printed year figure** | Summer blend for a winter emergency · a container that ever held gasoline · in living space |
| **⚠️ What must never be stored at all** | — | — | — | — | **Gasoline in a dwelling unit or apartment** · **any fuel in an unlabelled or food/drink container** · **fuel-soaked rags** (spontaneous combustion) · **oxygen and fuel together** · **cylinders in a vehicle in summer** · **any fuel near a water heater, furnace, or pilot light** · **fuel in a basement, cellar, or under stairs** |

> **The one-line summary, and it is the chapter's conclusion:** *store less fuel than you think you
> need, in a container designed for it, outside your living space, and spend what you saved on a CO
> alarm and a proper extension cord instead.*

---

## 11.13 Carbon monoxide — the alarm, and the two sentences that matter

Doc 04 §4.2 owns the full CO chapter and `CO-1` owns the alarm. This section exists in doc 11 for one
reason: **every fuel decision in this document is a CO decision**, and a household that reads the fuel
chapter without the alarm chapter has read half of it.

**CDC's figures, quoted:** more than **400 Americans die each year from unintentional CO poisoning not
linked to fires**, more than **100,000** visit an emergency department, and more than **14,000** are
hospitalised. CO is "an odorless, colorless gas that **kills without warning**", and "people who are
sleeping… can die from CO poisoning before they have symptoms."

**The only two fuel figures in this program that a free public source states outright — CDC's, on
generators:**

> **"Operate your generator outdoors more than 20 feet from windows, doors, and vents."**
> **"Never use a generator inside your home or garage, even if doors and windows are open."**

**No ppm threshold and no exposure-time table appears anywhere in this document.** Alarm set-points are
built into listed devices and vary by model, a household cannot measure ppm anyway, and no source
retrieved for this program states one. The instruction is **"the alarm sounds → everyone outside → call
the fire department from outside"** — not a number.

**The "whole household has the flu" rule.** CO symptoms are headache, dizziness, weakness, upset
stomach, vomiting, chest pain and confusion — "often described as flu-like". **A whole household with
the flu during an outage, all at once, is a CO alarm until proven otherwise.** Get everyone outside and
call for help.

---

## 11.14 Module `FUE-1` — Fuel safety

> **Tier 2 — HEALTH, WARMTH AND CLOTHING. Pass level: 10 out of 10, no partial pass. Prerequisite:
> `CO-1` complete. Run against the §3.0 drill safety protocol.** This is the second of the program's
> two written checks, alongside `MED-5`.

**Objective.** Pass a closed-book ten-item check at **10/10** and complete a room-by-room storage walk
that produces a written record of what is stored where — including every place fuel may **not** be
stored. **Chapters.** `11` (this document, in full) · `04 §4.2` (CO and fire) · `03 §3.8` (cooking
without power) · `10 §10.8` (the inventory sheet).

**Drill — the storage walk, then the check.** About one hour, and the walk is done first.

1. **Walk every room, with a pen and `10 §10.8`.** Record, for each room: what is stored there, how
   much, and the date on the container. Record the **absences** too — "no fuel in the hall cupboard"
   is a finding, and it belongs in writing.
2. **Name every exclusion out loud, room by room:** no fuel in a stairwell or common area; no fuel in a
   basement, cellar, or under stairs; nothing near a water heater, furnace or pilot light; no propane
   cylinder indoors; no gasoline in the dwelling; no unlabelled or food/drink container anywhere; no
   fuel-soaked rags.
3. **Confirm the two phone calls** (§11.7.1) and write the answers down with the date and the name:
   fire marshal, then landlord. If either said no, the fuel line in `10 §10.8` is struck through, not
   left blank.
4. **Test the CO alarm** in front of the assessor, and state the generator rule in CDC's terms: more
   than **20 feet** from windows, doors and vents; **never** indoors or in a garage, even with the
   doors open.
5. **Sit the check, closed book, out loud, assessor reading.** Ten items. **10/10 or it is a re-teach.**

**Observable pass criteria — all five:** the **written room-by-room record exists and is dated**; the
**exclusion list is recited unprompted and matched to actual rooms**; the **two phone calls are recorded
with dates**, or the fuel line is struck; the **CO alarm is tested and audible**; the **check is 10/10
with a one-line reason given for each answer**. Nine is a fail, and a fail is a re-teach — not a
partial pass, and not a "we'll come back to it".

**Assessment.** By an adult who did not perform the walk. **Hours.** 1. **Who must be able.** Every
adult to 10/10. **Children over eight** must be able to say that the generator and the stove stay
outside, that they never touch either, and that they tell an adult if they smell gas.

**What the check refuses to ask.** No question in `FUE-1` asks for a gallon figure, a clearance
distance, a kerosene grade, a shelf life or a ppm threshold, because this program does not print any of
them. Question 8 of the check asks **what this module refuses to print, and why** — and the answer is
the answer to this whole chapter: *because the standards are paywalled, the widely quoted number is
edition-dependent and misapplied to dwellings, and a number nobody verified is worse than a blank,
because a blank sends you to the fire marshal.*

---

## 11.15 What this chapter refuses to print, and where to get it instead

| Not printed | Why | Where the answer actually is |
|---|---|---|
| **A gallon limit for gasoline or propane in a dwelling** | NFPA 30 / 30A are paywalled and were not read; the online figure is edition-dependent and misapplied to dwellings | **Your fire marshal's non-emergency line, then your landlord.** §11.7.1 |
| **Any shelf life in months or years for gasoline, kerosene or diesel** | No authoritative free source retrieved | Rotate instead of storing: date every container, oldest first. §11.8, §11.9, §11.11 |
| **A heater clearance distance in feet** | No free authoritative source retrieved; CPSC pages were unavailable and NFPA is paywalled | **The heater's own label and manual.** If both are gone, do not run it. §11.9 |
| **A kerosene specification or sulphur limit** | The specification was not read | **Buy kerosene sold for heaters, for the appliance you own.** §11.9 |
| **A fuel-container standard number** | Not read | **A container sold for fuel, cap and spout intact.** §11.8 |
| **A CO ppm threshold or exposure table** | No source states one; households cannot measure ppm | **The alarm sounds → out → call from outside.** §11.13 |
| **Any price, anywhere** | Prices move weekly and differ by postcode; a stale price is a lie with a date on it | **The shelf, and your own dated record.** §11.4, §11.5 |

---

## 11.16 The chapter in one page

**On money.** Buy consumables at unit cost, in the format your flat can hold, and rotate them by
eating. Convert every purchase to cost per 1,000 calories, per gallon of capacity, per hour of light and
per person-day, and write the result on the package. Use the store map for what each place is genuinely
cheap for and know its trap; buy wool, canvas and dry storage at surplus and nothing else there. Spend
in three phases — the hazards that kill first, then the calories and the water, then the ninety days and
the durables — and stop when the money stops, because the order is what protects you, not the total.

**On fuel.** For an apartment the default is **store no gasoline in the dwelling** — not "check your
lease", not "a little in the cupboard". Call the fire marshal, then the landlord, and write both answers
down. Store less fuel than you think you need, in a container designed for it, outside your living
space, and rotate rather than stockpile, because ethanol blends take on water and separate. Never run a
generator anywhere but outdoors, more than twenty feet from windows, doors and vents — never indoors,
never in a garage, not even with the doors open. And spend what the fuel would have cost on a CO alarm,
which is the purchase that keeps the household alive in exactly the week the fuel was for.

---

### Refund and errata

If this program is not what you expected, ask for a refund through the channel you bought it on. This is
version 1.0, errata date **2026-11-02**; corrections are recorded in `CUSTOMER_README.md` and any
corrected figure is dated. Where a source does not cover an item — the residential fuel-storage limit,
fuel shelf lives, container standards, heater clearances, propane limits in a dwelling, CO thresholds,
and every price in the book — this document says so rather than supplying a number, and sends you to the
authority who does have it. **Two corrections are already recorded in the README:** the program's load
statement (now about 82 hours, or about 59 on the core path) and the removal of fuel figures that an
earlier draft printed without a verified source.

---

*Preparedness education only — not medical, legal or tactical advice. In an emergency call your local emergency
number. Follow your local health authority's guidance over anything in this guide. Written for US households.*
